// SPDX-License-Identifier: LicenseRef-Proprietary
// Copyright (C) 2026 Danial Rostamani. All rights reserved. See LICENSE.
// luci-app-singbox - shared helpers

import { readfile, writefile, rename, stat, mkdir, popen, access, unlink } from 'fs';
import { cursor } from 'uci';

export const PKG = 'singbox';
export const CONF_DIR = '/etc/singbox';
export const SUB_DIR = '/etc/singbox/subs';
export const RS_DIR = '/etc/singbox/rulesets';
export const BIN_DIR = '/etc/singbox/bin';
export const WORK_DIR = '/etc/singbox/work';
export const RUN_DIR = '/var/run/singbox';
export const CONFIG_OUT = '/var/run/singbox/config.json';
export const NFT_OUT = '/var/run/singbox/singbox.nft';
export const STATE_FILE = '/var/run/singbox/state.json';
export const TASK_FILE = '/var/run/singbox/task.json';
export const CUSTOM_CONFIG = '/etc/singbox/custom.json';
export const PROFILE_DIR = '/etc/singbox/profiles';

// Defaults used when an option is not set (keep in sync with /etc/config/singbox)
export const DEFAULT_MODE = 'tun';
export const DEFAULT_REMOTE_DNS = 'tcp://1.1.1.1';
export const DEFAULT_DIRECT_DNS = 'local';
export const DEFAULT_TUN_STACK = 'mixed';
export const DEFAULT_TEST_INTERVAL = '5m';
// "manual": no periodic tests - sing-box still tests once at start
export const MANUAL_TEST_INTERVAL = '8760h';

export const TPROXY_MARK = 0x5b;
export const ROUTE_TABLE = 91;
export const OUT_MARK = 0x5c;
export const TUN_NAME = 'sbtun0';
// sing-box marks its own sockets with this in TUN auto_redirect mode
// (auto_redirect_output_mark, set explicitly in the TUN inbound)
export const TUN_OUT_MARK = 0x2024;

// Xray sidecar (XHTTP, mKCP, VLESS encryption, Xray JSON configs)
export const XRAY_CONFIG_OUT = '/var/run/singbox/xray.json';
export const XRAY_PORT_BASE = 20900;
export const XRAY_TEST_PORT_BASE = 39900;

export function shq(s) {
	return "'" + replace('' + (s ?? ''), "'", "'\\''") + "'";
};

export function exec(cmd) {
	let p = popen(cmd + ' 2>&1', 'r');
	if (!p)
		return { code: 127, out: '' };
	let out = p.read('all') ?? '';
	let code = p.close();
	return { code: code ?? 0, out: out };
};

export function mkdirp(path) {
	let parts = split(path, '/');
	let cur = '';
	for (let i = 0; i < length(parts); i++) {
		if (parts[i] == '')
			continue;
		cur += '/' + parts[i];
		if (!stat(cur))
			mkdir(cur);
	}
	return !!stat(path);
};

export function readjson(path) {
	let data = readfile(path);
	if (data == null || data == '')
		return null;
	try {
		return json(data);
	}
	catch (e) {
		return null;
	}
};

export function writeatomic(path, data) {
	let tmp = path + '.tmp';
	if (writefile(tmp, data) == null)
		return false;
	return !!rename(tmp, path);
};

export function writejson(path, obj) {
	return writeatomic(path, sprintf('%J', obj));
};

export function bool(v, dflt) {
	if (v == null || v == '')
		return !!dflt;
	v = lc('' + v);
	return (v == '1' || v == 'true' || v == 'yes' || v == 'on' || v == 'enabled');
};

export function tolist(v) {
	if (v == null || v == '')
		return [];
	if (type(v) == 'array')
		return filter(v, (x) => x != null && x != '');
	return [ v ];
};

// Split list items that contain whitespace/commas/newlines into single values.
export function flatlist(v) {
	let out = [];
	let src = tolist(v);
	for (let i = 0; i < length(src); i++) {
		let parts = split(trim('' + src[i]), /[ \t\r\n,]+/);
		for (let j = 0; j < length(parts); j++)
			if (parts[j] != '')
				push(out, parts[j]);
	}
	return out;
};

export function toint(v, dflt) {
	let n = int(v);
	return (type(n) == 'int' && n == n) ? n : dflt;
};

export function urldecode(s) {
	if (s == null)
		return null;
	return replace('' + s, /%([0-9A-Fa-f][0-9A-Fa-f])/g, (m, h) => chr(hex(h)));
};

export function urlencode(s) {
	return replace('' + s, /[^A-Za-z0-9_.~-]/g, (c) => sprintf('%%%02X', ord(c)));
};

// Tolerant base64 decoder (standard + URL-safe, missing padding, whitespace).
export function b64d(s) {
	if (s == null)
		return null;
	s = replace(replace(replace('' + s, /[ \t\r\n]+/g, ''), /-/g, '+'), /_/g, '/');
	s = replace(s, /=+$/, '');
	if (s == '' || !match(s, regexp('^[A-Za-z0-9+/]+$')))
		return null;
	let pad = length(s) % 4;
	if (pad == 1)
		return null;
	if (pad == 2)
		s += '==';
	else if (pad == 3)
		s += '=';
	return b64dec(s);
};

export function parse_qs(q) {
	let res = {};
	if (q == null || q == '')
		return res;
	let pairs = split(q, '&');
	for (let i = 0; i < length(pairs); i++) {
		if (pairs[i] == '')
			continue;
		let eq = index(pairs[i], '=');
		let k = eq < 0 ? pairs[i] : substr(pairs[i], 0, eq);
		let v = eq < 0 ? '' : substr(pairs[i], eq + 1);
		res[urldecode(k)] = urldecode(v);
	}
	return res;
};

export function is_ipv4(s) {
	let m = match('' + s, /^([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})$/);
	if (!m)
		return false;
	for (let i = 1; i <= 4; i++)
		if (int(m[i]) > 255)
			return false;
	return true;
};

export function is_ipv6(s) {
	s = '' + s;
	return length(split(s, ':')) >= 3 && !!match(s, /^[0-9A-Fa-f:.]+$/);
};

export function is_ip(s) {
	return is_ipv4(s) || is_ipv6(s);
};

export function is_cidr(s) {
	let m = match('' + s, regexp('^([^/]+)(/([0-9]{1,3}))?$'));
	return !!m && is_ip(m[1]);
};

export function is_mac(s) {
	return !!match('' + s, /^[0-9A-Fa-f]{2}(:[0-9A-Fa-f]{2}){5}$/);
};

export function is_domain(s) {
	return !!match('' + s, /^[A-Za-z0-9_*]([A-Za-z0-9_.*-]*[A-Za-z0-9_])?$/) && index('' + s, '.') >= 0;
};

export function valid_port(p) {
	let n = int(p);
	return type(n) == 'int' && n >= 1 && n <= 65535;
};

export function clone(v) {
	if (v == null)
		return null;
	return json(sprintf('%J', v));
};

// --- sing-box core helpers -------------------------------------------------

export function core_path(main) {
	let cands = [ main?.core_path, BIN_DIR + '/sing-box', '/usr/bin/sing-box' ];
	for (let i = 0; i < length(cands); i++)
		if (cands[i] && access(cands[i], 'x'))
			return cands[i];
	return null;
};

export function core_version(bin) {
	if (!bin)
		return null;
	let r = exec(shq(bin) + ' version');
	let m = match(r.out, /sing-box version ([0-9]+)\.([0-9]+)\.([0-9]+)([^ \t\r\n]*)/);
	if (!m)
		return null;
	let tags = match(r.out, /Tags: ([^ \t\r\n]+)/);
	return {
		string: m[1] + '.' + m[2] + '.' + m[3] + m[4],
		major: int(m[1]),
		minor: int(m[2]),
		patch: int(m[3]),
		tags: tags ? split(trim(tags[1]), ',') : []
	};
};

// last non-empty line of a command's output
export function last_line(s) {
	let l = filter(split(trim('' + (s ?? '')), '\n'), (x) => trim(x) != '');
	return length(l) ? trim(l[length(l) - 1]) : '';
};

export function xray_path(main) {
	let cands = [ main?.xray_path, BIN_DIR + '/xray', '/usr/bin/xray', '/usr/sbin/xray' ];
	for (let i = 0; i < length(cands); i++)
		if (cands[i] && access(cands[i], 'x'))
			return cands[i];
	return null;
};

export function xray_version(bin) {
	if (!bin)
		return null;
	let r = exec(shq(bin) + ' version');
	let m = match(r.out, /Xray ([0-9]+)\.([0-9]+)\.([0-9]+)/);
	if (!m)
		return null;
	return { string: m[1] + '.' + m[2] + '.' + m[3], major: int(m[1]), minor: int(m[2]), patch: int(m[3]) };
};

// Compare a parsed version against major.minor; returns true when ver >= want.
export function ver_ge(ver, major, minor) {
	if (!ver)
		return true;	// unknown -> assume modern
	return ver.major > major || (ver.major == major && ver.minor >= minor);
};

// --- UCI loading --------------------------------------------------------------

function section_obj(s) {
	let o = {};
	for (let k in s)
		o[k] = s[k];
	o.id = s['.name'];
	return o;
}

export function load_conf() {
	let c = cursor();
	c.load(PKG);
	let conf = {
		main: c.get_all(PKG, 'main') ?? {},
		dns: c.get_all(PKG, 'dns') ?? {},
		route: c.get_all(PKG, 'route') ?? {},
		subs: [],
		nodes: [],
		rules: [],
		rulesets: [],
		hosts: [],
		profiles: [],
		client_rules: [],
		split_dns: []
	};
	c.foreach(PKG, 'subscription', (s) => { push(conf.subs, section_obj(s)); });
	c.foreach(PKG, 'node', (s) => { push(conf.nodes, section_obj(s)); });
	c.foreach(PKG, 'rule', (s) => { push(conf.rules, section_obj(s)); });
	c.foreach(PKG, 'ruleset', (s) => { push(conf.rulesets, section_obj(s)); });
	c.foreach(PKG, 'host', (s) => { push(conf.hosts, section_obj(s)); });
	c.foreach(PKG, 'profile', (s) => { push(conf.profiles, section_obj(s)); });
	c.foreach(PKG, 'client_rule', (s) => { push(conf.client_rules, section_obj(s)); });
	c.foreach(PKG, 'split_dns', (s) => { push(conf.split_dns, section_obj(s)); });
	return conf;
};

export function inbound_mode(main) {
	let m = main?.inbound_mode;
	return (m == 'tproxy' || m == 'tun' || m == 'mixed_only') ? m : DEFAULT_MODE;
};

// sing-box "log" object from the UI settings (logging switch + level)
export function log_options(main) {
	let eco = bool(main?.eco_mode, false);
	let level = main?.log_level ?? (eco ? 'warn' : 'info');
	if (!bool(main?.log_enabled, true) || level == 'off')
		return { disabled: true };
	return { level: level, timestamp: true };
};

// urltest interval: "manual" or a duration such as 30s, 5m, 2h
export function test_interval(main) {
	let v = trim('' + (main?.urltest_interval ?? DEFAULT_TEST_INTERVAL));
	if (v == 'manual')
		return MANUAL_TEST_INTERVAL;
	if (match(v, /^[0-9]+(s|m|h)$/))
		return v;
	return DEFAULT_TEST_INTERVAL;
};

function duration_secs(v) {
	let m = match('' + v, /^([0-9]+)(s|m|h)$/);
	if (!m)
		return 0;
	return int(m[1]) * (m[2] == 'h' ? 3600 : (m[2] == 'm' ? 60 : 1));
};

// Apply interval (and, when needed, idle_timeout) to a urltest outbound:
// sing-box rejects an interval longer than idle_timeout (default 30m).
export function apply_test_interval(group, main) {
	let iv = test_interval(main);
	group.interval = iv;
	if (duration_secs(iv) > 1800)
		group.idle_timeout = iv;
	return group;
};

export function log(msg) {
	system('logger -t singbox-ctl ' + shq(msg));
};

export function fmt_time(t) {
	let lt = localtime(t);
	return sprintf('%04d-%02d-%02d %02d:%02d:%02d', lt.year, lt.mon, lt.mday, lt.hour, lt.min, lt.sec);
};

export function remove(path) {
	if (stat(path))
		unlink(path);
};
