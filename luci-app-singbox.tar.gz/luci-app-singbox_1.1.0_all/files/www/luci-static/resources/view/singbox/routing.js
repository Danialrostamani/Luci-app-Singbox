'use strict';
'require view';
'require form';
'require ui';
'require uci';
'require rpc';
'require singbox.common as sb';

const callHostHints = rpc.declare({ object: 'luci-rpc', method: 'getHostHints', expect: { '': {} } });

// One-click rules: [ id, title, hint, [ [ type, [ values ], outbound, network ] ... ] ]
const TG_CIDR = [ '91.108.4.0/22', '91.108.8.0/22', '91.108.12.0/22', '91.108.16.0/22', '91.108.20.0/22', '91.108.56.0/22',
	'95.161.64.0/20', '149.154.160.0/20', '185.76.151.0/24', '2001:b28:f23c::/47', '2001:b28:f23f::/48', '2001:67c:4e8::/48', '2a0a:f280::/32' ];
const PRESETS = [
	[ 'telegram', _('Telegram via proxy'), _('Telegram domains and its server IP ranges (calls and media too).'),
		[ [ 'geosite', [ 'telegram' ], 'proxy' ], [ 'ip_cidr', TG_CIDR, 'proxy' ] ] ],
	[ 'meta', _('Instagram, WhatsApp & Facebook via proxy'), '',
		[ [ 'geosite', [ 'instagram', 'whatsapp', 'facebook' ], 'proxy' ] ] ],
	[ 'youtube', _('YouTube & Google via proxy'), '',
		[ [ 'geosite', [ 'youtube', 'google' ], 'proxy' ] ] ],
	[ 'x', _('X (Twitter) via proxy'), '',
		[ [ 'geosite', [ 'twitter' ], 'proxy' ] ] ],
	[ 'ai', _('AI services via proxy'), _('ChatGPT / OpenAI and Claude / Anthropic.'),
		[ [ 'geosite', [ 'openai', 'anthropic' ], 'proxy' ] ] ],
	[ 'media', _('Netflix & Spotify via proxy'), '',
		[ [ 'geosite', [ 'netflix', 'spotify' ], 'proxy' ] ] ],
	[ 'torrent', _('Torrents direct'), _('BitTorrent traffic goes direct: saves proxy traffic and avoids provider bans.'),
		[ [ 'protocol', [ 'bittorrent' ], 'direct' ] ] ],
	[ 'games', _('Online games direct'), _('Game servers go direct for a lower ping. Games that are blocked in your country stop working with this rule.'),
		[ [ 'geosite', [ 'category-games' ], 'direct' ] ] ]
];

const RULE_TYPES = [
	[ 'domain_suffix', _('Domain suffix') ],
	[ 'domain', _('Full domain') ],
	[ 'domain_keyword', _('Domain keyword') ],
	[ 'domain_regex', _('Domain regex') ],
	[ 'geosite', _('Geosite category') ],
	[ 'ip_cidr', _('Destination IP / CIDR') ],
	[ 'geoip', _('GeoIP country') ],
	[ 'source_ip_cidr', _('Source (LAN device) IP / CIDR') ],
	[ 'source_mac', _('Source MAC (sing-box ≥ 1.14)') ],
	[ 'port', _('Destination port') ],
	[ 'port_range', _('Destination port range') ],
	[ 'protocol', _('Sniffed protocol') ],
	[ 'network', _('Network (tcp/udp)') ],
	[ 'rule_set', _('Custom rule-set') ]
];

return view.extend({
	load() {
		return Promise.all([
			L.resolveDefault(sb.callNodes(), { nodes: [] }),
			L.resolveDefault(sb.callRulesets(), { rulesets: [] }),
			L.resolveDefault(sb.callStatus(), {}),
			L.resolveDefault(callHostHints(), {})
		]);
	},

	rulesetTable(rs) {
		const rows = (rs.rulesets || []).map((r) => E('tr', [
			E('td', { 'class': 'sb-ltr' }, r.tag),
			E('td', r.kind),
			E('td', { 'class': 'num' }, r.size ? sb.fmtBytes(r.size) : E('span', { 'class': 'sb-pill warn' }, _('missing'))),
			E('td', { 'class': 'num' }, r.mtime ? sb.fmtAgo(r.mtime) : '-')
		]));
		return E('div', { 'class': 'cbi-section' }, [
			E('h3', _('Rule-set files')),
			E('div', { 'class': 'cbi-section-descr' }, _('Rule-sets are downloaded to the router and refreshed daily, so sing-box always starts even without internet. Missing rule-sets are fetched automatically once the proxy is up.')),
			rows.length ? E('table', { 'class': 'sb-table' }, [
				E('tr', [ E('th', _('Tag')), E('th', _('Type')), E('th', { 'class': 'num' }, _('Size')), E('th', { 'class': 'num' }, _('Updated')) ]),
				...rows
			]) : E('div', { 'class': 'sb-empty' }, _('No rule-sets in use.')),
			E('div', { 'class': 'sb-toolbar', 'style': 'margin-top:10px' }, [
				E('button', {
					'class': 'btn cbi-button-action',
					'click': ui.createHandlerFn(this, () => sb.runTask('rs-update', 'all', _('Downloading rule-sets…')).then(() => location.reload()))
				}, '⟳ ' + _('Update rule-sets now'))
			])
		]);
	},

	/* Quick rules: add ready-made custom rules with one click */
	presetCard() {
		const existing = {};
		uci.sections('singbox', 'rule').forEach((r) => { if (r.preset) existing[r.preset] = true; });
		const add = (p) => {
			p[3].forEach(([ type, values, outbound ], i) => {
				const sid = uci.add('singbox', 'rule');
				uci.set('singbox', sid, 'enabled', '1');
				uci.set('singbox', sid, 'name', p[1] + (p[3].length > 1 ? ' (' + (i + 1) + ')' : ''));
				uci.set('singbox', sid, 'type', type);
				uci.set('singbox', sid, 'value', values);
				uci.set('singbox', sid, 'outbound', outbound);
				uci.set('singbox', sid, 'preset', p[0]);
			});
			return uci.save().then(() => {
				sb.notify(_('“%s” added to Custom rules. Press Save & Apply to use it.').format(p[1]));
				return new Promise((r) => window.setTimeout(r, 900)).then(() => location.reload());
			});
		};
		return E('div', { 'class': 'cbi-section' }, [
			E('h3', _('Quick rules')),
			E('div', { 'class': 'sb-sub', 'style': 'margin-bottom:8px' }, _('Add a ready-made rule with one click. It appears under Custom rules, where you can change or delete it.')),
			E('div', { 'class': 'sb-toolbar', 'style': 'flex-wrap:wrap' }, PRESETS.map((p) => existing[p[0]] ?
				E('button', { 'class': 'btn cbi-button', 'disabled': 'disabled', 'title': _('Already added') }, '✓ ' + p[1]) :
				E('button', { 'class': 'btn cbi-button-add', 'title': p[2] || p[1], 'click': ui.createHandlerFn(this, () => add(p)) }, '+ ' + p[1])))
		]);
	},

	render([ nodes, rs, st, hints ]) {
		const tags = (nodes.nodes || []).filter((n) => n.tag).map((n) => n.tag);
		const m = new form.Map('singbox', _('Routing'),
			_('Decide which traffic goes through the proxy. Rules are evaluated top to bottom; your custom rules come before the built-in policies.'));

		/* ---- built-in policy ---- */
		let s = m.section(form.NamedSection, 'route', 'route', _('Built-in policy'));
		s.addremove = false;

		let o = s.option(form.Flag, 'iran_direct', _('Iranian sites direct'),
			_('Send Iranian domains and IP ranges (and all .ir domains) directly, without the proxy. Uses the Danialrostamani/sing-box-iran-rules rule-sets.'));
		o.default = '1';
		o.rmempty = false;

		o = s.option(form.Flag, 'block_ads', _('Block ads, trackers & malware'),
			_('Blocks advertising, tracking, phishing, malware and miner domains/IPs for the whole network.'));
		o.default = '1';
		o.rmempty = false;

		o = s.option(form.Flag, 'block_quic', _('Block QUIC through the proxy'),
			_('Rejects UDP/443 for proxied traffic so browsers fall back to TCP. Often faster on throttled links.'));
		o.default = '0';

		o = s.option(form.ListValue, 'final', _('Everything else goes'));
		o.value('proxy', _('Through the selected node'));
		o.value('auto', _('Through the fastest node (auto)'));
		o.value('direct', _('Direct'));
		tags.forEach((t) => o.value(t, _('Node: %s').format(t)));
		o.default = 'proxy';

		o = s.option(form.Value, 'github_mirror', _('GitHub mirror'),
			_('Optional prefix for raw.githubusercontent.com / github.com downloads when GitHub is slow or blocked, e.g. https://ghfast.top/ . Only used for direct downloads.'));
		o.placeholder = 'https://ghfast.top/';
		o.validate = (sid, v) => (!v || /^https?:\/\/\S+$/.test(v)) ? true : _('Enter a valid URL');

		o = s.option(form.ListValue, 'ruleset_update_hour', _('Daily rule-set update at'));
		for (let h = 0; h < 24; h++)
			o.value(String(h), '%02d:23'.format(h));
		o.default = '4';

		o = s.option(form.ListValue, 'ruleset_via', _('Download rule-sets via'));
		o.value('auto', _('Direct first, then through the proxy'));
		o.value('direct', _('Direct only'));
		o.value('proxy', _('Through the proxy only'));
		o.default = 'auto';

		/* ---- client / device policy rules ---- */
		const cs = m.section(form.GridSection, 'client_rule', _('Client / Device rules'),
			_('Policy routing per LAN device: assign specific nodes, direct route, or block for specific phones, TVs, consoles, or computers. Evaluated before custom rules.'));
		cs.anonymous = true;
		cs.addremove = true;
		cs.sortable = true;
		cs.nodescriptions = true;
		cs.addbtntitle = _('Add device rule');
		cs.modaltitle = _('Client policy rule');

		o = cs.option(form.Flag, 'enabled', _('Enabled'));
		o.default = '1';
		o.editable = true;
		o.rmempty = false;

		o = cs.option(form.Value, 'name', _('Device name'));
		o.placeholder = _('e.g. Smart TV');

		o = cs.option(form.Value, 'client', _('Client IP or MAC'),
			_('IPv4/IPv6 address (e.g. 192.168.1.105), CIDR range (192.168.1.0/24), or MAC address.'));
		o.rmempty = false;
		o.placeholder = '192.168.1.105';
		Object.keys(hints || {}).forEach((mac) => {
			const h = hints[mac];
			const hostLabel = h.name ? '%s (%s)'.format(h.name, mac) : mac;
			(h.ipaddrs || []).forEach((ip) => {
				o.value(ip, '%s — %s'.format(ip, h.name || mac));
			});
			o.value(mac.toLowerCase(), hostLabel);
		});

		o = cs.option(form.ListValue, 'outbound', _('Route via'));
		o.value('proxy', _('Proxy (selected node)'));
		o.value('auto', _('Proxy (fastest node)'));
		o.value('direct', _('Direct (bypass proxy)'));
		o.value('block', _('Block traffic'));
		tags.forEach((t) => o.value(t, _('Node: %s').format(t)));
		o.default = 'proxy';
		sb.labelCells(o);

		o = cs.option(form.DynamicList, 'domain', _('Optional domain filter'),
			_('Leave empty to route ALL traffic from this device, or specify domains (e.g. netflix.com) so only matching requests go through this route.'));
		o.modalonly = true;

		/* ---- custom rules ---- */
		s = m.section(form.GridSection, 'rule', _('Custom rules'),
			_('Examples: route telegram.org via a specific node, send a smart TV directly, block a domain. Drag rows to change the order.'));
		s.anonymous = true;
		s.addremove = true;
		s.sortable = true;
		s.nodescriptions = true;
		s.addbtntitle = _('Add rule');
		s.modaltitle = _('Routing rule');

		o = s.option(form.Flag, 'enabled', _('Enabled'));
		o.default = '1';
		o.editable = true;
		o.rmempty = false;

		o = s.option(form.Value, 'name', _('Name'));
		o.placeholder = _('e.g. Telegram');

		o = s.option(form.ListValue, 'type', _('Match'));
		RULE_TYPES.forEach(([ k, v ]) => o.value(k, v));
		sb.labelCells(o);
		o.default = 'domain_suffix';

		o = s.option(form.DynamicList, 'value', _('Values'),
			_('One value per entry; you can also paste several separated by spaces or commas. Geosite/GeoIP names come from SagerNet sing-geosite / sing-geoip (e.g. openai, google, telegram / ir, us, ru).'));
		o.placeholder = 'telegram.org';
		o.textvalue = (sid) => {
			const v = L.toArray(m.data.get('singbox', sid, 'value'));
			return E('span', { 'class': 'sb-ltr', 'title': v.join('\n') }, v.length > 3 ? v.slice(0, 3).join(', ') + ' …(+%d)'.format(v.length - 3) : v.join(', '));
		};

		o = s.option(form.ListValue, 'outbound', _('Action'));
		o.value('proxy', _('Proxy (selected node)'));
		o.value('auto', _('Proxy (fastest node)'));
		o.value('direct', _('Direct'));
		o.value('block', _('Block'));
		tags.forEach((t) => o.value(t, _('Node: %s').format(t)));
		o.default = 'proxy';
		sb.labelCells(o);

		o = s.option(form.ListValue, 'network', _('Network'));
		o.value('', _('TCP + UDP'));
		o.value('tcp', 'TCP');
		o.value('udp', 'UDP');
		o.modalonly = true;

		/* ---- custom rule-sets ---- */
		s = m.section(form.GridSection, 'ruleset', _('Custom rule-sets'),
			_('Remote sing-box rule-sets (.srs binary or .json source). Reference them in a rule with match type “Custom rule-set” and the name below.'));
		s.anonymous = true;
		s.addremove = true;
		s.nodescriptions = true;
		s.addbtntitle = _('Add rule-set');

		o = s.option(form.Flag, 'enabled', _('Enabled'));
		o.default = '1';
		o.editable = true;
		o.rmempty = false;

		o = s.option(form.Value, 'name', _('Name'));
		o.rmempty = false;
		o.validate = (sid, v) => /^[A-Za-z0-9@!._-]+$/.test(v || '') ? true : _('Use letters, digits, dot, dash, underscore');

		o = s.option(form.Value, 'url', _('URL'));
		o.rmempty = false;
		o.validate = (sid, v) => /^https?:\/\/\S+$/.test(v || '') ? true : _('Enter a valid URL');

		o = s.option(form.ListValue, 'format', _('Format'));
		o.value('binary', _('Binary (.srs)'));
		o.value('source', _('Source (.json)'));
		o.default = 'binary';
		sb.labelCells(o);

		o = s.option(form.ListValue, 'kind', _('Content'),
			_('Domain-only rule-sets are also used for DNS decisions.'));
		o.value('mixed', _('Mixed / unknown'));
		o.value('domain', _('Domains only'));
		o.value('ip', _('IPs only'));
		o.default = 'mixed';
		sb.labelCells(o);

		/* ---- static hosts ---- */
		s = m.section(form.GridSection, 'host', _('Static DNS records'),
			_('Answer these names locally, for the whole network.'));
		s.anonymous = true;
		s.addremove = true;
		s.nodescriptions = true;
		s.addbtntitle = _('Add record');

		o = s.option(form.Flag, 'enabled', _('Enabled'));
		o.default = '1';
		o.editable = true;
		o.rmempty = false;

		o = s.option(form.Value, 'domain', _('Domain'));
		o.datatype = 'hostname';
		o.rmempty = false;

		o = s.option(form.DynamicList, 'ip', _('IP addresses'));
		o.datatype = 'ipaddr';
		o.rmempty = false;

		return m.render().then((node) => sb.wrap([ sb.profileBanner(st, _('Routing settings below apply to the built-in configuration only.')), this.presetCard(), node, this.rulesetTable(rs) ]));
	}
});
