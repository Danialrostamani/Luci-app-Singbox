'use strict';
'require baseclass';
'require rpc';
'require ui';

/*
 * Shared helpers for luci-app-singbox views: RPC declarations, formatting,
 * stylesheet and small UI widgets.
 */

/*
 * All backend calls go through decl(): when the backend reports an internal
 * error (reply.backend_error) the real message is shown once, so problems on
 * the router are visible instead of failing silently.
 */
let backendErrorShown = false;

function showBackendError(text) {
	if (backendErrorShown)
		return;
	backendErrorShown = true;
	ui.addNotification(_('sing-box backend error'), [
		E('p', _('The backend reported an error. Please report this message:')),
		E('pre', { 'style': 'white-space:pre-wrap;max-height:240px;overflow:auto;direction:ltr;text-align:left' }, String(text))
	], 'danger');
}

function decl(method, params) {
	return rpc.declare({
		object: 'luci.sbclient',
		method: method,
		params: params,
		expect: {},
		filter: (reply) => {
			if (reply && reply.backend_error)
				showBackendError(reply.backend_error);
			return reply;
		}
	});
}

const callStatus = decl('status');
const callNodes = decl('nodes');
const callNodeDetail = decl('node_detail', ['tag']);
const callSubs = decl('subs');
const callParse = decl('parse', ['text', 'core']);
const callService = decl('service', ['action']);
const callClash = decl('clash', ['action', 'name', 'id', 'mode', 'url', 'timeout']);
const callTask = decl('task', ['action', 'arg']);
const callTaskStatus = decl('task_status');
const callRulesets = decl('rulesets');
const callCoreInfo = decl('core_info');
const callXrayLatest = decl('xray_latest');
const callCoreReleases = decl('core_releases', [ 'core' ]);
const callPerfStatus = decl('perf_status');
const callAppCheck = decl('app_check');
const callUpdates = decl('updates', [ 'force' ]);
const callToolResults = decl('tool_results');
const callAwgStatus = decl('awg_status');
const callBenchStatus = decl('bench_status');
const callAbout = decl('about');
const callSpeedResults = decl('speed_results');
const callBackupCreate = decl('backup_create');
const callBackupRestore = decl('backup_restore', [ 'content' ]);
const callNotifyTest = decl('notify_test', [ 'token', 'chat', 'api' ]);
const callXrayRemove = decl('xray_remove');
const callCoreLatest = decl('core_latest', ['prerelease']);
const callCoreReset = decl('core_reset');
const callLogs = decl('logs', ['lines']);
const callConfig = decl('config');
const callRegenerate = decl('regenerate');
const callCustomGet = decl('custom_get');
const callCustomSet = decl('custom_set', ['text']);
const callSetSelected = decl('set_selected', ['name']);
const callTestResults = decl('test_results');
const callSpeedCaps = decl('speed_caps');
const callProfileGroups = decl('profile_groups');
const callProfiles = decl('profiles');
const callProfileSave = decl('profile_save', ['id', 'name', 'type', 'url', 'update_hours', 'via', 'user_agent', 'integrate', 'content', 'core']);
const callProfileDelete = decl('profile_delete', ['id']);
const callProfileActivate = decl('profile_activate', ['id']);
const callProfileContent = decl('profile_content', ['id']);
const callProfileCheck = decl('profile_check', ['id']);

const CSS = `
.sb-upd-dot { display: inline-block; width: 9px; height: 9px; border-radius: 50%; background: #e5484d; margin: 0 0 0 4px; vertical-align: top; position: relative; top: -1px; box-shadow: 0 0 0 0 rgba(229,72,77,.6); animation: sb-upd-pulse 2s ease-out infinite; }
@keyframes sb-upd-pulse { 0% { box-shadow: 0 0 0 0 rgba(229,72,77,.55); } 70% { box-shadow: 0 0 0 6px rgba(229,72,77,0); } 100% { box-shadow: 0 0 0 0 rgba(229,72,77,0); } }
.sb-new { display: inline-flex; align-items: center; gap: 5px; margin-left: 8px; padding: 1px 8px; border-radius: 10px; font-size: .75rem; font-weight: 600; color: #e5484d; background: rgba(229,72,77,.12); vertical-align: middle; }
.sb-new .sb-upd-dot { margin: 0; top: 0; }
.sb-footer { margin: 22px 0 4px; padding-top: 10px; border-top: 1px solid var(--sb-line, rgba(127,127,127,.25)); text-align: center; font-size: .78rem; opacity: .8; }
.sb-footer a { margin: 0 2px; }
.sb-chart { margin-top: 10px; }
.sb-chart svg { width: 100%; height: 56px; display: block; background: var(--sb-bg2, rgba(127,127,127,.06)); border-radius: 6px; }
.sb-chart-legend { font-size: .72rem; opacity: .75; margin-top: 3px; }
.sb-wrap { --sb-bg: var(--background-color-high, #fff); --sb-bg2: var(--background-color-medium, #f6f7f9);
	--sb-fg: var(--text-color-highest, #1f2328); --sb-fg2: var(--text-color-medium, #636c76);
	--sb-bd: var(--border-color-medium, #d8dee4); --sb-acc: #2f81f7; --sb-ok: #1a7f37; --sb-warn: #b7791f; --sb-bad: #cf222e;
	color: var(--sb-fg); }
[data-darkmode="true"] .sb-wrap { --sb-acc: #4493f8; --sb-ok: #3fb950; --sb-warn: #d29922; --sb-bad: #f85149; }
.sb-grid { display: grid; gap: 12px; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); margin-bottom: 14px; }
.sb-grid.sb-fit { grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); }
.sb-grid.sb-wide { grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); }
.sb-card { background: var(--sb-bg); border: 1px solid var(--sb-bd); border-radius: 12px; padding: 14px 16px; position: relative; min-width: 0; }
.sb-card h4 { margin: 0 0 8px; font-size: 0.85rem; font-weight: 600; color: var(--sb-fg2); text-transform: uppercase; letter-spacing: .03em; }
.sb-big { font-size: 1.6rem; font-weight: 700; line-height: 1.2; word-break: break-word; }
.sb-sub { color: var(--sb-fg2); font-size: .85rem; }
.sb-speed { font-size: 1.15rem; font-weight: 700; line-height: 1.3; font-variant-numeric: tabular-nums; white-space: nowrap; }
.sb-row { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
.sb-row.sb-between { justify-content: space-between; }
.sb-pill { display: inline-flex; align-items: center; gap: 6px; padding: 2px 10px; border-radius: 999px; font-size: .8rem; font-weight: 600;
	border: 1px solid var(--sb-bd); background: var(--sb-bg2); white-space: nowrap; }
.sb-pill.ok { color: var(--sb-ok); border-color: currentColor; }
.sb-pill.bad { color: var(--sb-bad); border-color: currentColor; }
.sb-pill.warn { color: var(--sb-warn); border-color: currentColor; }
.sb-dot { width: 8px; height: 8px; border-radius: 50%; background: currentColor; display: inline-block; }
.sb-power { width: 74px; height: 74px; border-radius: 50%; border: 3px solid var(--sb-bd); background: var(--sb-bg2); cursor: pointer;
	display: inline-flex; align-items: center; justify-content: center; font-size: 30px; color: var(--sb-fg2); transition: all .2s; flex: none; }
.sb-power:hover { transform: scale(1.04); }
.sb-power.on { border-color: var(--sb-ok); color: var(--sb-ok); box-shadow: 0 0 0 6px color-mix(in srgb, var(--sb-ok) 15%, transparent); }
.sb-power[disabled] { opacity: .5; cursor: wait; }
.sb-seg { display: inline-flex; border: 1px solid var(--sb-bd); border-radius: 10px; overflow: hidden; }
.sb-seg button { border: 0; background: transparent; padding: 7px 16px; cursor: pointer; color: var(--sb-fg); font-weight: 600; }
.sb-seg button + button { border-inline-start: 1px solid var(--sb-bd); }
.sb-seg button.active { background: var(--sb-acc); color: #fff; }
.sb-seg button[disabled] { opacity: .5; cursor: not-allowed; }
.sb-node { cursor: pointer; transition: border-color .15s, box-shadow .15s; padding: 12px 14px; }
.sb-node:hover { border-color: var(--sb-acc); }
.sb-node.sel { border-color: var(--sb-acc); box-shadow: 0 0 0 2px color-mix(in srgb, var(--sb-acc) 35%, transparent); }
.sb-node.err { opacity: .6; cursor: default; border-style: dashed; }
.sb-node .sb-name { font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1; min-width: 0; unicode-bidi: plaintext; }
.sb-node .sb-meta { color: var(--sb-fg2); font-size: .78rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; margin-top: 4px; }
.sb-tag { font-size: .7rem; padding: 1px 6px; border-radius: 6px; background: var(--sb-bg2); border: 1px solid var(--sb-bd); color: var(--sb-fg2); text-transform: uppercase; font-weight: 600; }
.sb-delay { font-size: .78rem; font-weight: 700; min-width: 54px; text-align: end; }
.sb-delay.good { color: var(--sb-ok); } .sb-delay.mid { color: var(--sb-warn); } .sb-delay.bad { color: var(--sb-bad); }
.sb-actions { display: flex; gap: 4px; margin-top: 8px; }
.sb-actions .btn, .sb-actions .cbi-button { padding: 0 8px; font-size: .75rem; min-height: 0; line-height: 1.9; }
.sb-group-h { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin: 18px 0 8px; flex-wrap: wrap; }
.sb-group-h h3 { margin: 0; font-size: 1.05rem; }
.sb-toolbar { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; margin: 4px 0 12px; }
.sb-toolbar input[type=search] { min-width: 200px; flex: 1; max-width: 340px; height: 2.2em; }
.sb-bar { height: 8px; background: var(--sb-bg2); border-radius: 6px; overflow: hidden; border: 1px solid var(--sb-bd); margin: 6px 0 4px; }
.sb-bar > div { height: 100%; background: var(--sb-acc); }
.sb-bar.hi > div { background: var(--sb-bad); }
.sb-alert { border-radius: 10px; padding: 10px 14px; margin-bottom: 12px; border: 1px solid; }
.sb-alert.warn { border-color: var(--sb-warn); color: var(--sb-warn); }
.sb-alert.bad { border-color: var(--sb-bad); color: var(--sb-bad); }
.sb-alert.info { border-color: var(--sb-acc); color: var(--sb-acc); }
.sb-alert ul { margin: 4px 0 0; padding-inline-start: 18px; }
.sb-pre { font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: 12px; white-space: pre-wrap; word-break: break-all;
	background: var(--sb-bg2); border: 1px solid var(--sb-bd); border-radius: 10px; padding: 10px; max-height: 70vh; overflow: auto; margin: 0; direction: ltr; text-align: left; }
.sb-log .lv-error, .sb-log .lv-fatal { color: var(--sb-bad); } .sb-log .lv-warn { color: var(--sb-warn); } .sb-log .lv-debug, .sb-log .lv-trace { color: var(--sb-fg2); }
.sb-ltr { direction: ltr; unicode-bidi: isolate; }
.sb-table { width: 100%; border-collapse: collapse; font-size: .85rem; }
.sb-table th, .sb-table td { padding: 6px 8px; border-bottom: 1px solid var(--sb-bd); text-align: start; vertical-align: top; }
.sb-table td.num, .sb-table th.num { text-align: end; white-space: nowrap; }
.sb-table td .sb-sub { font-size: .75rem; }
.sb-spin { display: inline-block; width: 14px; height: 14px; border: 2px solid currentColor; border-right-color: transparent; border-radius: 50%; animation: sb-rot .8s linear infinite; vertical-align: -2px; }
@keyframes sb-rot { to { transform: rotate(360deg); } }
.sb-empty { text-align: center; color: var(--sb-fg2); padding: 30px 10px; border: 1px dashed var(--sb-bd); border-radius: 12px; }
.sb-badge { font-size: .7rem; font-weight: 700; padding: 1px 7px; border-radius: 999px; background: var(--sb-acc); color: #fff; text-transform: uppercase; }
.sb-badge.muted { background: var(--sb-bg2); color: var(--sb-fg2); border: 1px solid var(--sb-bd); }
.sb-card.active { border-color: var(--sb-ok); box-shadow: 0 0 0 2px color-mix(in srgb, var(--sb-ok) 30%, transparent); }
.sb-form-row { margin: 8px 0; }
.sb-form-row > label { display: block; font-weight: 600; margin-bottom: 4px; }
.sb-form-row input[type=text], .sb-form-row select { width: 100%; max-width: 100%; }
.sb-modal-ta { width: 100%; min-height: 220px; font-family: ui-monospace, monospace; font-size: 12px; direction: ltr; }
@media (max-width: 600px) { .sb-grid { grid-template-columns: 1fr; } .sb-big { font-size: 1.3rem; } }
`;

let cssInjected = false;


return baseclass.extend({
	callStatus, callNodes, callNodeDetail, callSubs, callParse, callService, callClash,
	callTask, callTaskStatus, callRulesets, callCoreInfo, callCoreLatest, callCoreReset, callXrayLatest, callXrayRemove, callCoreReleases, callPerfStatus, callAppCheck, callUpdates, callToolResults, callAwgStatus, callBenchStatus, callAbout, callSpeedResults, callBackupCreate, callBackupRestore, callNotifyTest,
	callLogs, callConfig, callRegenerate, callCustomGet, callCustomSet, callSetSelected,
	callTestResults, callProfileGroups, callSpeedCaps,
	callProfiles, callProfileSave, callProfileDelete, callProfileActivate, callProfileContent, callProfileCheck,

	injectCSS() {
		if (cssInjected)
			return;
		cssInjected = true;
		document.head.appendChild(E('style', { 'id': 'sb-style' }, [ CSS ]));
	},

	/* Update badge: a red dot on the "Update" tab when the app or a core has a
	 * newer version. The router checks GitHub in the background (every hour). */
	updates(force, refetch) {
		if (force || refetch || !this._updP)
			this._updP = L.resolveDefault(callUpdates(!!force), null);
		return this._updP;
	},

	updateText(r) {
		const l = [];
		if (r?.app?.update) l.push('luci-app-singbox %s → %s'.format(r.app.current || '?', r.app.latest));
		if (r?.singbox?.update) l.push('sing-box %s → %s'.format(r.singbox.current || '?', r.singbox.latest));
		if (r?.xray?.update) l.push('Xray %s → %s'.format(r.xray.current || '?', r.xray.latest));
		return l;
	},

	markUpdates(r, tries) {
		const links = document.querySelectorAll('a[href*="/admin/services/singbox/update"]');
		if (!links.length) {
			/* the tab menu may be drawn after the view */
			if ((tries || 0) < 20)
				window.setTimeout(() => this.markUpdates(r, (tries || 0) + 1), 300);
			return;
		}
		const list = this.updateText(r);
		links.forEach((a) => {
			a.querySelectorAll('.sb-upd-dot').forEach((d) => d.remove());
			if (list.length)
				a.appendChild(E('span', { 'class': 'sb-upd-dot', 'title': _('Update available') + ': ' + list.join(', ') }));
		});
	},

	watchUpdates() {
		if (this._updWatch)
			return;
		this._updWatch = true;
		let n = 0;
		const run = (fresh) => this.updates(false, fresh).then((r) => {
			this.markUpdates(r);
			/* a background check is running: look again once it is done */
			if (r && r.checking && n++ < 4)
				window.setTimeout(() => run(true), 20000);
		});
		run(false);
	},

	/* Core picker for links: auto | xray | singbox */
	coreSelect(value) {
		return E('select', { 'class': 'cbi-input-select', 'style': 'display:block;width:100%;max-width:560px;margin-top:4px' }, [
			[ 'auto', _('Auto: sing-box, Xray only where needed (recommended)') ],
			[ 'xray', _('Xray: run VLESS / VMess / Trojan / Shadowsocks through Xray') ],
			[ 'singbox', _('sing-box only: skip nodes that need Xray') ]
		].map(([ v, l ]) => E('option', { 'value': v, 'selected': (value || 'auto') == v ? '' : null }, l)));
	},

	coreHint() {
		return E('div', { 'class': 'sb-sub', 'style': 'margin-top:2px' }, _('Which core runs these links. Xray is needed for XHTTP, mKCP and VLESS encryption (install it on the Update tab); Hysteria2, TUIC, AnyTLS and WireGuard always run in sing-box.'));
	},

	/* wrap page content */
	wrap(children) {
		this.injectCSS();
		this.watchUpdates();
		return E('div', { 'class': 'sb-wrap' }, [ ...children, this.footer() ]);
	},

	/* Author credit on every page of the app. */
	footer() {
		const ver = E('span', {}, '');
		if (!this._aboutP)
			this._aboutP = L.resolveDefault(callAbout(), {});
		this._aboutP.then((a) => { if (a && a.version) ver.textContent = ' v' + a.version; });
		return E('div', { 'class': 'sb-footer' }, [
			'luci-app-singbox', ver, ' · ', _('Made by'), ' ',
			E('strong', {}, 'Danial Rostamani'), ' · ',
			E('a', { 'href': 'https://t.me/Drostamani', 'target': '_blank', 'rel': 'noopener' }, 'Telegram'), ' · ',
			E('a', { 'href': 'https://github.com/Danialrostamani/Luci-app-Singbox', 'target': '_blank', 'rel': 'noopener' }, 'GitHub')
		]);
	},

	ltr(s) {
		return s;
	},

	fmtBytes(n) {
		if (n == null || isNaN(n))
			return '-';
		const u = [ 'B', 'KB', 'MB', 'GB', 'TB', 'PB' ];
		let i = 0;
		n = +n;
		while (n >= 1024 && i < u.length - 1) {
			n /= 1024;
			i++;
		}
		return this.ltr((i ? n.toFixed(n >= 100 ? 0 : (n >= 10 ? 1 : 2)) : Math.round(n)) + ' ' + u[i]);
	},

	/* transfer rate, always at least KB/s: 0.48 KB/s, 8.53 KB/s, 1.20 MB/s */
	fmtSpeed(n) {
		if (n == null || isNaN(n))
			return '-';
		let v = Math.max(0, +n) / 1024;
		const u = [ 'KB/s', 'MB/s', 'GB/s' ];
		let i = 0;
		while (v >= 1024 && i < u.length - 1) {
			v /= 1024;
			i++;
		}
		return this.ltr(v.toFixed(v >= 100 ? 0 : (v >= 10 ? 1 : 2)) + ' ' + u[i]);
	},

	fmtDuration(sec) {
		if (sec == null || isNaN(sec) || sec < 0)
			return '-';
		sec = Math.floor(sec);
		const d = Math.floor(sec / 86400), h = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
		if (d)
			return _('%dd %dh').format(d, h);
		if (h)
			return _('%dh %dm').format(h, m);
		if (m)
			return _('%dm %ds').format(m, s);
		return _('%ds').format(s);
	},

	fmtDate(ts) {
		if (!ts)
			return '-';
		const d = new Date(ts * 1000);
		const p = (x) => String(x).padStart(2, '0');
		return this.ltr('%d-%s-%s %s:%s'.format(d.getFullYear(), p(d.getMonth() + 1), p(d.getDate()), p(d.getHours()), p(d.getMinutes())));
	},

	fmtAgo(ts) {
		if (!ts)
			return _('never');
		const s = Math.floor(Date.now() / 1000) - ts;
		if (s < 60)
			return _('just now');
		return _('%s ago').format(this.fmtDuration(s));
	},

	delayClass(d) {
		if (d == null)
			return '';
		if (d <= 0)
			return 'bad';
		return d < 300 ? 'good' : (d < 800 ? 'mid' : 'bad');
	},

	delayText(d) {
		if (d == null)
			return '—';
		if (d <= 0)
			return _('timeout');
		return this.ltr(d + ' ms');
	},

	typeLabel(n) {
		const names = {
			vless: 'VLESS', vmess: 'VMess', trojan: 'Trojan', shadowsocks: 'SS', hysteria2: 'Hy2',
			hysteria: 'Hy', tuic: 'TUIC', anytls: 'AnyTLS', socks: 'SOCKS', http: 'HTTP',
			wireguard: 'WG', shadowtls: 'ShadowTLS', ssh: 'SSH', snell: 'Snell'
		};
		const parts = [ names[n.type] || (n.type || '?') ];
		if (n.transport)
			parts.push(n.transport);
		if (n.tls)
			parts.push(n.tls);
		return parts.join(' · ');
	},

	pill(text, cls, dot) {
		return E('span', { 'class': 'sb-pill ' + (cls || '') }, [ dot ? E('span', { 'class': 'sb-dot' }) : '', text ]);
	},

	spinner() {
		return E('span', { 'class': 'sb-spin' });
	},

	notify(msg, type) {
		ui.addTimeLimitedNotification(null, E('p', msg), 5000, type || 'info');
	},

	error(msg) {
		ui.addNotification(null, E('p', msg), 'danger');
	},

	/* Run a background task and poll until it finishes. */
	runTask(action, arg, label) {
		return this.callTask(action, arg || '').then((r) => {
			if (!r || !r.ok) {
				this.error(r?.error || _('Could not start task'));
				return null;
			}
			ui.showModal(label || _('Working…'), [
				E('p', { 'class': 'spinning' }, _('This may take a while. You can leave this page; the task keeps running in the background.'))
			]);
			const poll = () => new Promise((resolve) => window.setTimeout(resolve, 1500))
				// rpcd restarts during an app update: keep polling through errors
				.then(() => this.callTaskStatus().catch(() => ({ running: true })))
				.then((t) => {
					if (t && t.running)
						return poll();
					ui.hideModal();
					if (t && t.ok)
						this.notify(t.message || _('Done'), 'info');
					else
						this.error((t && t.message) || _('Task failed'));
					return t;
				});
			return poll();
		});
	},

	/* Show a task-in-progress banner if a background task is running. */
	taskBanner(task) {
		if (!task || !task.running)
			return E('div');
		const names = {
			'sub-update': _('Updating subscriptions'),
			'rs-update': _('Downloading rule-sets'),
			'core-update': _('Updating sing-box core'),
			'xray-install': _('Installing Xray core'),
			'core-package': _('Switching to the sing-box package'),
			'app-update': _('Updating luci-app-singbox'),
			'speed-test': _('Testing speed'),
			'profile-update': _('Updating profile'),
			'node-test': _('Testing latency'),
			'restart': _('Restarting')
		};
		return E('div', { 'class': 'sb-alert info' }, [ this.spinner(), ' ', names[task.action] || task.action, '…' ]);
	},

	/* Show the label instead of the raw value of a ListValue in grid rows. */
	labelCells(opt) {
		opt.textvalue = function(sid) {
			const v = this.cfgvalue(sid) ?? this.default;
			const i = this.keylist.indexOf(String(v ?? ''));
			return i >= 0 ? this.vallist[i] : (v ?? '-');
		};
		return opt;
	},

	/* Banner shown on pages whose settings are unused while a profile runs. */
	profileBanner(st, what) {
		if (!st || !st.profile)
			return E('div');
		return E('div', { 'class': 'sb-alert info' }, [
			_('Profile “%s” is active.').format(st.profile), ' ', what || '', ' ',
			E('a', { 'href': L.url('admin/services/singbox/profiles') }, _('Manage profiles'))
		]);
	},

	copyText(text) {
		if (navigator.clipboard && window.isSecureContext)
			return navigator.clipboard.writeText(text).then(() => this.notify(_('Copied to clipboard')));
		const ta = E('textarea', { 'style': 'position:fixed;opacity:0' }, [ text ]);
		document.body.appendChild(ta);
		ta.select();
		try { document.execCommand('copy'); this.notify(_('Copied to clipboard')); } catch (e) {}
		document.body.removeChild(ta);
		return Promise.resolve();
	}
});
