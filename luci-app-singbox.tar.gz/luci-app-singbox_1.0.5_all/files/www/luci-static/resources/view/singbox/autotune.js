'use strict';
'require view';
'require ui';
'require poll';
'require singbox.common as sb';

// Auto-tune: the router tries the settings that matter for speed on this
// hardware, one group at a time, and keeps the fastest combination.
const NAMES = {
	inbound_mode: { tproxy: 'TPROXY', tun: 'TUN' },
	tun_stack: { system: 'system', mixed: 'mixed', gvisor: 'gvisor' },
	bandwidth_mode: { bbr: 'BBR', keep: 'from config', custom: 'custom' },
	mux_mode: { keep: 'on', off: 'off' },
	mem_mode: { balanced: 'balanced', maximum: 'maximum', low: 'low' },
	max_perf: { '1': 'high', '0': 'normal' }
};

return view.extend({
	load() {
		return L.resolveDefault(sb.callBenchStatus(), {});
	},

	settingsTable(s) {
		s = s || {};
		const v = (k, d) => (NAMES[k] && NAMES[k][s[k] ?? d]) || s[k] || d || '-';
		const mode = (s.inbound_mode || 'tun') == 'tun' ? 'TUN · ' + _('stack') + ' ' + v('tun_stack', 'mixed') : 'TPROXY';
		return E('table', { 'class': 'sb-table', 'style': 'max-width:520px' }, [
			E('tr', [ E('td', _('Mode')), E('td', mode) ]),
			E('tr', [ E('td', _('Bandwidth')), E('td', v('bandwidth_mode', 'bbr')) ]),
			E('tr', [ E('td', _('Multiplex')), E('td', v('mux_mode', 'keep')) ]),
			E('tr', [ E('td', _('Memory mode')), E('td', v('mem_mode', 'balanced')) ]),
			E('tr', [ E('td', _('Priority')), E('td', v('max_perf', '1')) ])
		]);
	},

	resultsTable(b) {
		const rows = (b.results || []).map((r) => E('tr', { 'style': r.winner ? 'font-weight:600' : '' }, [
			E('td', { 'class': 'sb-sub' }, r.stage),
			E('td', [ r.winner ? '✅ ' : '', r.label ]),
			E('td', { 'class': 'num' }, r.ok ? '%.1f'.format(r.down) : E('span', { 'style': 'color:var(--sb-bad)' }, r.error || _('failed'))),
			E('td', { 'class': 'num' }, r.ok ? '%.1f'.format(r.up) : '-'),
			E('td', { 'class': 'num' }, r.ok && r.ping ? r.ping + ' ms' : '-'),
			E('td', { 'class': 'num' }, r.cpu != null ? '%.0f%%'.format(r.cpu) : '-')
		]));
		if (b.running && b.current)
			rows.push(E('tr', [ E('td', { 'class': 'sb-sub' }, b.stage || ''), E('td', [ sb.spinner(), ' ', b.current ]), E('td'), E('td'), E('td'), E('td') ]));
		if (!rows.length)
			return '';
		return E('div', { 'style': 'overflow-x:auto' }, E('table', { 'class': 'sb-table' }, [
			E('tr', [ E('th', _('Group')), E('th', _('Setting')), E('th', { 'class': 'num' }, _('Down Mbps')), E('th', { 'class': 'num' }, _('Up Mbps')), E('th', { 'class': 'num' }, _('Ping')), E('th', { 'class': 'num' }, _('CPU')) ]),
			...rows
		]));
	},

	draw(b) {
		const root = this.root;
		root.innerHTML = '';
		b = b || {};

		if (b.running && !b.interrupted) {
			const pct = b.total ? Math.round((b.done || 0) * 100 / b.total) : 0;
			root.appendChild(E('div', { 'class': 'sb-alert info' }, [
				E('strong', _('Auto-tune is running: %d of %d tests (%d%%)').format(b.done || 0, b.total || 0, pct)),
				E('div', { 'style': 'height:6px;background:var(--sb-bd);border-radius:3px;margin:8px 0;overflow:hidden' },
					E('div', { 'style': 'height:100%;width:' + pct + '%;background:var(--sb-acc)' })),
				E('div', { 'class': 'sb-sub' }, _('The internet drops for a few seconds before each test while sing-box restarts. You can leave this page; the test continues on the router.'))
			]));
		}
		else if (b.interrupted) {
			root.appendChild(E('div', { 'class': 'sb-alert warn' }, [
				_('The last auto-tune was interrupted. The router may still use one of the test settings.'), ' ',
				E('button', { 'class': 'btn cbi-button-action', 'click': ui.createHandlerFn(this, () => this.restore()) }, _('Restore previous settings'))
			]));
		}

		if (!b.running) {
			const secs = E('select', { 'class': 'cbi-input-select' }, [ 5, 10, 15, 20 ].map((v) => E('option', { 'value': v, 'selected': v == 10 ? '' : null }, _('%d s per test').format(v))));
			const apply = E('input', { 'type': 'checkbox', 'checked': '' });
			const svcOk = b.service && b.service.running;
			root.appendChild(E('div', { 'class': 'cbi-section' }, [
				E('h3', _('Find the fastest settings for this router')),
				E('div', { 'class': 'sb-sub', 'style': 'margin-bottom:8px' }, _('Tests, one group after the other, the settings that change speed on different CPUs and memory sizes: TPROXY or TUN (system / mixed / gvisor stack), BBR or Brutal bandwidth (Hysteria2 nodes), multiplex on or off (nodes with multiplex), memory mode and process priority. Each setting is applied for real, sing-box restarts and the router downloads and uploads through the current node. The best setting of a group is kept for the next one.')),
				E('ul', { 'class': 'sb-sub', 'style': 'margin:0 0 8px 18px' }, [
					E('li', _('Takes about 3–8 minutes. The internet drops for a few seconds before each test.')),
					E('li', _('Uses the node that is selected now; pick your usual node first.')),
					E('li', _('Do not download on other devices during the test; it would lower the results.'))
				]),
				svcOk ? '' : E('div', { 'class': 'sb-alert warn' }, _('Start the service first: the test measures the running connection.')),
				E('div', { 'class': 'sb-toolbar' }, [
					secs,
					E('label', [ apply, ' ', _('Apply the best settings when done') ]),
					E('button', {
						'class': 'btn cbi-button-action',
						'disabled': svcOk ? null : '',
						'click': ui.createHandlerFn(this, () => {
							if (!confirm(_('Start auto-tune? sing-box restarts several times and the internet drops briefly each time.')))
								return;
							return sb.callTask('bench', JSON.stringify({ secs: +secs.value, apply: apply.checked })).then((r) => {
								if (!r || !r.ok)
									return sb.error((r && r.error) || _('Could not start'));
								return this.refresh();
							});
						})
					}, '▶ ' + _('Start auto-tune'))
				])
			]));
		}

		if ((b.results || []).length) {
			const sec = E('div', { 'class': 'cbi-section' }, [ E('h3', b.running ? _('Results so far') : _('Last results')) ]);
			if (!b.running && b.finished) {
				sec.appendChild(E('div', { 'class': 'sb-sub', 'style': 'margin-bottom:6px' },
					_('Finished %s. ✅ = best in its group.').format(new Date(b.finished * 1000).toLocaleString()) + ' ' +
					(b.applied ? _('The best settings were applied.') : _('Your original settings were kept.'))));
			}
			sec.appendChild(this.resultsTable(b));
			if (!b.running && b.best) {
				sec.appendChild(E('div', { 'style': 'display:flex;gap:24px;flex-wrap:wrap;margin-top:12px' }, [
					E('div', [ E('h4', _('Best settings')), this.settingsTable(b.best) ]),
					E('div', [ E('h4', _('Before the test')), this.settingsTable(b.original) ])
				]));
				sec.appendChild(E('div', { 'class': 'sb-toolbar', 'style': 'margin-top:10px' }, [
					b.applied ? E('button', { 'class': 'btn cbi-button', 'click': ui.createHandlerFn(this, () => this.restore()) }, _('Go back to the settings before the test')) : ''
				]));
			}
			root.appendChild(sec);
		}
	},

	restore() {
		if (!confirm(_('Restore the settings from before the auto-tune? sing-box restarts.')))
			return;
		return sb.runTask('bench-restore', '', _('Restoring settings…')).then(() => this.refresh());
	},

	refresh() {
		return L.resolveDefault(sb.callBenchStatus(), {}).then((b) => {
			this.draw(b);
			return b;
		});
	},

	render(b) {
		this.root = E('div');
		this.draw(b);
		poll.add(() => {
			if (this.root.querySelector('.sb-alert.info') || (b && b.running))
				return this.refresh().then((nb) => { b = nb; });
		}, 3);
		return sb.wrap([
			E('h2', _('Auto-tune')),
			E('div', { 'class': 'cbi-map-descr' }, _('Different routers need different settings for full speed. Let the router test them and keep the fastest.')),
			this.root
		]);
	},

	handleSave: null,
	handleSaveApply: null,
	handleReset: null
});
