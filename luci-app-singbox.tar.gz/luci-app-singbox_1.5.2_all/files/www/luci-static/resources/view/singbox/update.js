'use strict';
'require view';
'require ui';
'require singbox.common as sb';

// Update page: this app, the sing-box core and the Xray core.
return view.extend({
	load() {
		return L.resolveDefault(sb.callCoreInfo(), {});
	},

	/* After a core task: reload on success, keep the error on screen otherwise. */
	taskDone(t) {
		if (t && t.ok) {
			ui.showModal(_('Done'), [
				E('p', t.message || _('Done')),
				E('div', { 'class': 'right' }, E('button', { 'class': 'btn cbi-button-action', 'click': () => location.reload() }, _('OK')))
			]);
			return;
		}
		ui.showModal(_('Installation failed'), [
			E('p', { 'style': 'color:var(--sb-bad)' }, (t && t.message) || _('The task could not be started.')),
			E('p', { 'class': 'sb-sub' }, _('The current core was not changed.')),
			E('div', { 'class': 'right' }, E('button', { 'class': 'btn', 'click': ui.hideModal }, _('Close')))
		]);
	},

	appSection(core) {
		const cur = core.app_version || '?';
		const status = E('div', { 'class': 'sb-sub', 'style': 'margin-top:4px' }, _('Press “Check for updates” to compare with the latest release on GitHub.'));
		const update = E('button', {
			'class': 'btn cbi-button-action',
			'click': ui.createHandlerFn(this, () => {
				if (!confirm(_('Download the latest luci-app-singbox from GitHub and install it? Settings, subscriptions, profiles and the sing-box core are kept. The service restarts.')))
					return;
				return sb.runTask('app-update', '', _('Updating luci-app-singbox…')).then((t) => {
					if (t && t.ok) {
						ui.showModal(_('App updated'), [
							E('p', t.message || _('Done')),
							E('p', { 'class': 'sb-sub' }, _('Reload the page with Ctrl+F5 (or clear the browser cache on a phone) to load the new interface.')),
							E('div', { 'class': 'right' }, E('button', { 'class': 'btn cbi-button-action', 'click': () => location.reload(true) }, _('Reload')))
						]);
					}
					else
						this.taskDone(t);
				});
			})
		}, _('Update app'));
		const check = E('button', {
			'class': 'btn cbi-button',
			'click': ui.createHandlerFn(this, () => {
				status.innerHTML = '';
				status.appendChild(E('span', [ sb.spinner(), ' ', _('Checking GitHub…') ]));
				return sb.callAppCheck().then((r) => {
					if (!r || !r.ok) {
						status.textContent = _('Could not check: %s').format((r && r.error) || '?');
						return;
					}
					if (r.update) {
						status.innerHTML = '';
						status.appendChild(E('strong', { 'style': 'color:var(--sb-good)' }, _('New version available: %s').format(r.latest)));
						update.classList.add('important');
					}
					else
						status.textContent = _('You have the latest version (%s).').format(r.latest || cur);
				});
			})
		}, _('Check for updates'));

		return E('div', { 'class': 'cbi-section' }, [
			E('h3', _('App update')),
			E('table', { 'class': 'sb-table', 'style': 'max-width:640px' }, [
				E('tr', [ E('td', _('Installed version')), E('td', { 'class': 'sb-ltr' }, cur) ]),
				E('tr', [ E('td', _('Source')), E('td', { 'class': 'sb-ltr' }, E('a', { 'href': 'https://github.com/Danialrostamani/Luci-app-Singbox', 'target': '_blank', 'rel': 'noopener' }, 'github.com/Danialrostamani/Luci-app-Singbox')) ])
			]),
			E('div', { 'class': 'sb-toolbar', 'style': 'margin-top:10px' }, [ check, update ]),
			status,
			E('div', { 'class': 'sb-sub' }, _('Uses the GitHub mirror from Routing when set, and falls back to the proxy when the service is running.'))
		]);
	},

	/* Version picker shared by both cores: the list comes from GitHub. */
	versionPicker(which, installed) {
		const sel = E('select', { 'class': 'cbi-input-select', 'style': 'min-width:220px' }, [
			E('option', { 'value': 'latest' }, _('Latest stable')),
			E('option', { 'value': 'package' }, which == 'xray' ? _('OpenWrt package (xray-core)') : _('OpenWrt package (sing-box)'))
		]);
		const status = E('div', { 'class': 'sb-sub', 'style': 'margin-top:4px' }, [ sb.spinner(), ' ', _('Loading versions from GitHub…') ]);
		const load = () => {
			status.innerHTML = '';
			status.appendChild(E('span', [ sb.spinner(), ' ', _('Loading versions from GitHub…') ]));
			return sb.callCoreReleases(which).then((r) => {
				while (sel.options.length > 2)
					sel.remove(2);
				Array.from(sel.querySelectorAll('optgroup')).forEach((g) => g.remove());
				if (!r || !r.ok) {
					status.textContent = _('Could not load the version list (%s). “Latest stable” and the package still work.').format((r && r.error) || '?');
					return;
				}
				const group = (label, list) => {
					if (!list || !list.length)
						return;
					sel.appendChild(E('optgroup', { 'label': label }, list.map((v) =>
						E('option', { 'value': v }, v + (v == installed ? ' ' + _('(installed)') : '')))));
				};
				group(_('Releases'), r.stable);
				group(_('Pre-releases (testing)'), r.prerelease);
				sel.options[0].textContent = _('Latest stable (%s)').format(r.latest || '?');
				if (installed && r.latest && installed != r.latest && r.stable.indexOf(installed) >= 0 && r.stable.indexOf(installed) > 0)
					status.textContent = _('Installed: %s — newer version available: %s').format(installed, r.latest);
				else
					status.textContent = installed ? _('Installed: %s').format(installed) : _('Not installed');
			}, (e) => { status.textContent = _('Could not load the version list: %s').format(e.message || e); });
		};
		const refresh = E('button', { 'class': 'btn cbi-button', 'title': _('Reload the version list'), 'click': ui.createHandlerFn(this, load) }, '⟳');
		load();
		return { select: sel, status: status, refresh: refresh };
	},

	coreSection(core) {
		const p = this.versionPicker('sing-box', core.downloaded_version || core.package_version || core.version);
		const install = E('button', {
			'class': 'btn cbi-button-action',
			'click': ui.createHandlerFn(this, () => {
				const v = p.select.value;
				const label = p.select.options[p.select.selectedIndex].textContent;
				if (v == 'package') {
					if (!confirm(_('Use the OpenWrt sing-box package (installed with the package manager if missing)? The downloaded core %s is removed and the service restarts.').format(core.downloaded_version || '-')))
						return;
					return sb.runTask('core-package', '', _('Switching to the sing-box package…')).then((t) => this.taskDone(t));
				}
				if (!confirm(_('Install sing-box %s from GitHub (%s)?\n\nThe current core (%s) is removed after the new one has been downloaded and verified. The service restarts.').format(label, core.arch, core.version || _('none'))))
					return;
				return sb.runTask('core-update', v, _('Installing sing-box %s…').format(v)).then((t) => this.taskDone(t));
			})
		}, _('Install selected version'));

		return E('div', { 'class': 'cbi-section' }, [
			E('h3', _('sing-box core')),
			E('table', { 'class': 'sb-table', 'style': 'max-width:640px' }, [
				E('tr', [ E('td', _('In use')), E('td', { 'class': 'sb-ltr' }, core.version ? '%s (%s)'.format(core.version, core.path) : _('not installed')) ]),
				E('tr', [ E('td', _('Source')), E('td', core.downloaded_version ? _('Official build (GitHub)') : (core.package_version ? _('OpenWrt package') : '-')) ]),
				E('tr', [ E('td', _('Architecture')), E('td', { 'class': 'sb-ltr' }, core.arch || '-') ]),
				E('tr', [ E('td', _('Build tags')), E('td', { 'class': 'sb-ltr', 'style': 'font-size:.75rem' }, (core.tags || []).join(', ') || '-') ])
			]),
			E('div', { 'class': 'sb-toolbar', 'style': 'margin-top:10px' }, [ E('strong', _('Version:')), p.select, p.refresh, install ]),
			p.status,
			E('div', { 'class': 'sb-sub' }, _('Pick any release (1.12 or newer) or the OpenWrt package. The official build includes every protocol and is stored in /etc/singbox/bin (kept across firmware upgrades); the previous core is removed once the new one works.') +
				(core.app_is_package ? ' ' + _('The sing-box package itself stays installed because this app was installed as a package that depends on it.') : ''))
		]);
	},

	xraySection(core) {
		const x = core.xray || {};
		const p = this.versionPicker('xray', x.version);
		const install = E('button', {
			'class': 'btn cbi-button-action',
			'click': ui.createHandlerFn(this, () => {
				const v = p.select.value;
				const label = p.select.options[p.select.selectedIndex].textContent;
				const cur = x.version ? x.version : _('none');
				const msg = (v == 'package') ?
					_('Install the OpenWrt package xray-core? The current Xray (%s) is replaced.').format(cur) :
					_('Install Xray %s from GitHub (%s, about 12 MB in /etc/singbox/bin)?\n\nThe current Xray (%s) is removed after the new one has been downloaded and verified.').format(label, core.arch, cur);
				if (!confirm(msg))
					return;
				return sb.runTask('xray-install', v, _('Installing Xray core…')).then((t) => this.taskDone(t));
			})
		}, _('Install selected version'));
		const remove = x.version ? E('button', {
			'class': 'btn cbi-button-negative',
			'click': ui.createHandlerFn(this, () => {
				if (!confirm(_('Uninstall the Xray core? Nodes that need it are skipped until it is installed again.')))
					return;
				return sb.callXrayRemove().then(() => location.reload());
			})
		}, _('Uninstall')) : '';

		let used = '-';
		if (x.version)
			used = (x.nodes || x.skipped) ? _('%d node(s) running through Xray').format(x.nodes || 0) + (x.skipped ? ', ' + _('%d skipped').format(x.skipped) : '') : _('no node needs it right now');
		else if (x.skipped)
			used = _('%d node(s) skipped - install Xray to use them').format(x.skipped);

		return E('div', { 'class': 'cbi-section' }, [
			E('h3', _('Xray core (XHTTP, mKCP, Xray configs)')),
			E('div', { 'class': 'sb-sub', 'style': 'margin-bottom:6px' },
				_('sing-box has no XHTTP (SplitHTTP), mKCP or VLESS encryption and cannot read Xray JSON configurations. Such nodes run through an Xray core next to sing-box; switching, latency tests, routing and DNS still work as usual. Optional - only needed for those nodes.')),
			E('table', { 'class': 'sb-table', 'style': 'max-width:640px' }, [
				E('tr', [ E('td', _('In use')), E('td', { 'class': 'sb-ltr' }, x.version ? '%s (%s)'.format(x.version, x.path) : _('not installed')) ]),
				E('tr', [ E('td', _('Source')), E('td', x.downloaded ? _('Official build (GitHub)') : (x.package ? _('OpenWrt package') : '-')) ]),
				E('tr', [ E('td', _('Nodes')), E('td', used) ])
			]),
			E('div', { 'class': 'sb-toolbar', 'style': 'margin-top:10px' }, [ E('strong', _('Version:')), p.select, p.refresh, install, remove ]),
			p.status,
			E('div', { 'class': 'sb-sub' }, _('Pick any release (24.11 or newer) or the OpenWrt package (may be older; VLESS encryption needs 25.8+). The previous Xray is removed once the new one works.'))
		]);
	},

	render(core) {
		return sb.wrap([
			E('h2', _('Update')),
			E('div', { 'class': 'cbi-map-descr' }, _('Update this app and choose the sing-box and Xray core versions. Settings, subscriptions and profiles are always kept.')),
			this.appSection(core),
			this.coreSection(core),
			this.xraySection(core)
		]);
	},

	handleSave: null,
	handleSaveApply: null,
	handleReset: null
});
