'use strict';
'require view';
'require form';
'require ui';
'require uci';
'require rpc';
'require tools.widgets as widgets';
'require singbox.common as sb';

const callHostHints = rpc.declare({ object: 'luci-rpc', method: 'getHostHints', expect: { '': {} } });

return view.extend({
	load() {
		return Promise.all([
			L.resolveDefault(sb.callCoreInfo(), {}),
			L.resolveDefault(callHostHints(), {}),
			L.resolveDefault(sb.callNodes(), { nodes: [] }),
			uci.load('singbox')
		]);
	},

	/* After a core task: reload on success, keep the error on screen otherwise. */
	taskDone(t) {
		if (t && t.ok) {
			ui.showModal(_('Done'), [
				E('p', t.message || _('Done')),
				E('div', { 'class': 'right' }, E('button', { 'class': 'btn cbi-button-action', 'click': () => location.reload() }, _('OK')))
			]);
			return;
		}
		ui.showModal(_('Installation failed'), [
			E('p', { 'style': 'color:var(--sb-bad)' }, (t && t.message) || _('The task could not be started.')),
			E('p', { 'class': 'sb-sub' }, _('The current core was not changed.')),
			E('div', { 'class': 'right' }, E('button', { 'class': 'btn', 'click': ui.hideModal }, _('Close')))
		]);
	},

	appSection(core) {
		const cur = core.app_version || '?';
		const status = E('div', { 'class': 'sb-sub', 'style': 'margin-top:4px' }, _('Press “Check for updates” to compare with the latest release on GitHub.'));
		const update = E('button', {
			'class': 'btn cbi-button-action',
			'click': ui.createHandlerFn(this, () => {
				if (!confirm(_('Download the latest luci-app-singbox from GitHub and install it? Settings, subscriptions, profiles and the sing-box core are kept. The service restarts.')))
					return;
				return sb.runTask('app-update', '', _('Updating luci-app-singbox…')).then((t) => {
					if (t && t.ok) {
						ui.showModal(_('App updated'), [
							E('p', t.message || _('Done')),
							E('p', { 'class': 'sb-sub' }, _('Reload the page with Ctrl+F5 (or clear the browser cache on a phone) to load the new interface.')),
							E('div', { 'class': 'right' }, E('button', { 'class': 'btn cbi-button-action', 'click': () => location.reload(true) }, _('Reload')))
						]);
					}
					else
						this.taskDone(t);
				});
			})
		}, _('Update app'));
		const check = E('button', {
			'class': 'btn cbi-button',
			'click': ui.createHandlerFn(this, () => {
				status.innerHTML = '';
				status.appendChild(E('span', [ sb.spinner(), ' ', _('Checking GitHub…') ]));
				return sb.callAppCheck().then((r) => {
					if (!r || !r.ok) {
						status.textContent = _('Could not check: %s').format((r && r.error) || '?');
						return;
					}
					if (r.update) {
						status.innerHTML = '';
						status.appendChild(E('strong', { 'style': 'color:var(--sb-good)' }, _('New version available: %s').format(r.latest)));
						update.classList.add('important');
					}
					else
						status.textContent = _('You have the latest version (%s).').format(r.latest || cur);
				});
			})
		}, _('Check for updates'));

		return E('div', { 'class': 'cbi-section' }, [
			E('h3', _('App update')),
			E('table', { 'class': 'sb-table', 'style': 'max-width:640px' }, [
				E('tr', [ E('td', _('Installed version')), E('td', { 'class': 'sb-ltr' }, cur) ]),
				E('tr', [ E('td', _('Source')), E('td', { 'class': 'sb-ltr' }, E('a', { 'href': 'https://github.com/Danialrostamani/Luci-app-Singbox', 'target': '_blank', 'rel': 'noopener' }, 'github.com/Danialrostamani/Luci-app-Singbox')) ])
			]),
			E('div', { 'class': 'sb-toolbar', 'style': 'margin-top:10px' }, [ check, update ]),
			status,
			E('div', { 'class': 'sb-sub' }, _('Uses the GitHub mirror from Routing when set, and falls back to the proxy when the service is running.'))
		]);
	},

	/* Version picker shared by both cores: the list comes from GitHub. */
	versionPicker(which, installed) {
		const sel = E('select', { 'class': 'cbi-input-select', 'style': 'min-width:220px' }, [
			E('option', { 'value': 'latest' }, _('Latest stable')),
			E('option', { 'value': 'package' }, which == 'xray' ? _('OpenWrt package (xray-core)') : _('OpenWrt package (sing-box)'))
		]);
		const status = E('div', { 'class': 'sb-sub', 'style': 'margin-top:4px' }, [ sb.spinner(), ' ', _('Loading versions from GitHub…') ]);
		const load = () => {
			status.innerHTML = '';
			status.appendChild(E('span', [ sb.spinner(), ' ', _('Loading versions from GitHub…') ]));
			return sb.callCoreReleases(which).then((r) => {
				while (sel.options.length > 2)
					sel.remove(2);
				Array.from(sel.querySelectorAll('optgroup')).forEach((g) => g.remove());
				if (!r || !r.ok) {
					status.textContent = _('Could not load the version list (%s). “Latest stable” and the package still work.').format((r && r.error) || '?');
					return;
				}
				const group = (label, list) => {
					if (!list || !list.length)
						return;
					sel.appendChild(E('optgroup', { 'label': label }, list.map((v) =>
						E('option', { 'value': v }, v + (v == installed ? ' ' + _('(installed)') : '')))));
				};
				group(_('Releases'), r.stable);
				group(_('Pre-releases (testing)'), r.prerelease);
				sel.options[0].textContent = _('Latest stable (%s)').format(r.latest || '?');
				if (installed && r.latest && installed != r.latest && r.stable.indexOf(installed) >= 0 && r.stable.indexOf(installed) > 0)
					status.textContent = _('Installed: %s — newer version available: %s').format(installed, r.latest);
				else
					status.textContent = installed ? _('Installed: %s').format(installed) : _('Not installed');
			}, (e) => { status.textContent = _('Could not load the version list: %s').format(e.message || e); });
		};
		const refresh = E('button', { 'class': 'btn cbi-button', 'title': _('Reload the version list'), 'click': ui.createHandlerFn(this, load) }, '⟳');
		load();
		return { select: sel, status: status, refresh: refresh };
	},

	coreSection(core) {
		const p = this.versionPicker('sing-box', core.downloaded_version || core.package_version || core.version);
		const install = E('button', {
			'class': 'btn cbi-button-action',
			'click': ui.createHandlerFn(this, () => {
				const v = p.select.value;
				const label = p.select.options[p.select.selectedIndex].textContent;
				if (v == 'package') {
					if (!confirm(_('Use the OpenWrt sing-box package (installed with the package manager if missing)? The downloaded core %s is removed and the service restarts.').format(core.downloaded_version || '-')))
						return;
					return sb.runTask('core-package', '', _('Switching to the sing-box package…')).then((t) => this.taskDone(t));
				}
				if (!confirm(_('Install sing-box %s from GitHub (%s)?\n\nThe current core (%s) is removed after the new one has been downloaded and verified. The service restarts.').format(label, core.arch, core.version || _('none'))))
					return;
				return sb.runTask('core-update', v, _('Installing sing-box %s…').format(v)).then((t) => this.taskDone(t));
			})
		}, _('Install selected version'));

		return E('div', { 'class': 'cbi-section' }, [
			E('h3', _('sing-box core')),
			E('table', { 'class': 'sb-table', 'style': 'max-width:640px' }, [
				E('tr', [ E('td', _('In use')), E('td', { 'class': 'sb-ltr' }, core.version ? '%s (%s)'.format(core.version, core.path) : _('not installed')) ]),
				E('tr', [ E('td', _('Source')), E('td', core.downloaded_version ? _('Official build (GitHub)') : (core.package_version ? _('OpenWrt package') : '-')) ]),
				E('tr', [ E('td', _('Architecture')), E('td', { 'class': 'sb-ltr' }, core.arch || '-') ]),
				E('tr', [ E('td', _('Build tags')), E('td', { 'class': 'sb-ltr', 'style': 'font-size:.75rem' }, (core.tags || []).join(', ') || '-') ])
			]),
			E('div', { 'class': 'sb-toolbar', 'style': 'margin-top:10px' }, [ E('strong', _('Version:')), p.select, p.refresh, install ]),
			p.status,
			E('div', { 'class': 'sb-sub' }, _('Pick any release (1.12 or newer) or the OpenWrt package. The official build includes every protocol and is stored in /etc/singbox/bin (kept across firmware upgrades); the previous core is removed once the new one works.') +
				(core.app_is_package ? ' ' + _('The sing-box package itself stays installed because this app was installed as a package that depends on it.') : ''))
		]);
	},

	xraySection(core) {
		const x = core.xray || {};
		const p = this.versionPicker('xray', x.version);
		const install = E('button', {
			'class': 'btn cbi-button-action',
			'click': ui.createHandlerFn(this, () => {
				const v = p.select.value;
				const label = p.select.options[p.select.selectedIndex].textContent;
				const cur = x.version ? x.version : _('none');
				const msg = (v == 'package') ?
					_('Install the OpenWrt package xray-core? The current Xray (%s) is replaced.').format(cur) :
					_('Install Xray %s from GitHub (%s, about 12 MB in /etc/singbox/bin)?\n\nThe current Xray (%s) is removed after the new one has been downloaded and verified.').format(label, core.arch, cur);
				if (!confirm(msg))
					return;
				return sb.runTask('xray-install', v, _('Installing Xray core…')).then((t) => this.taskDone(t));
			})
		}, _('Install selected version'));
		const remove = x.version ? E('button', {
			'class': 'btn cbi-button-negative',
			'click': ui.createHandlerFn(this, () => {
				if (!confirm(_('Uninstall the Xray core? Nodes that need it are skipped until it is installed again.')))
					return;
				return sb.callXrayRemove().then(() => location.reload());
			})
		}, _('Uninstall')) : '';

		let used = '-';
		if (x.version)
			used = (x.nodes || x.skipped) ? _('%d node(s) running through Xray').format(x.nodes || 0) + (x.skipped ? ', ' + _('%d skipped').format(x.skipped) : '') : _('no node needs it right now');
		else if (x.skipped)
			used = _('%d node(s) skipped - install Xray to use them').format(x.skipped);

		return E('div', { 'class': 'cbi-section' }, [
			E('h3', _('Xray core (XHTTP, mKCP, Xray configs)')),
			E('div', { 'class': 'sb-sub', 'style': 'margin-bottom:6px' },
				_('sing-box has no XHTTP (SplitHTTP), mKCP or VLESS encryption and cannot read Xray JSON configurations. Such nodes run through an Xray core next to sing-box; switching, latency tests, routing and DNS still work as usual. Optional - only needed for those nodes.')),
			E('table', { 'class': 'sb-table', 'style': 'max-width:640px' }, [
				E('tr', [ E('td', _('In use')), E('td', { 'class': 'sb-ltr' }, x.version ? '%s (%s)'.format(x.version, x.path) : _('not installed')) ]),
				E('tr', [ E('td', _('Source')), E('td', x.downloaded ? _('Official build (GitHub)') : (x.package ? _('OpenWrt package') : '-')) ]),
				E('tr', [ E('td', _('Nodes')), E('td', used) ])
			]),
			E('div', { 'class': 'sb-toolbar', 'style': 'margin-top:10px' }, [ E('strong', _('Version:')), p.select, p.refresh, install, remove ]),
			p.status,
			E('div', { 'class': 'sb-sub' }, _('Pick any release (24.11 or newer) or the OpenWrt package (may be older; VLESS encryption needs 25.8+). The previous Xray is removed once the new one works.'))
		]);
	},

	render([ core, hints, nodes ]) {
		const m = new form.Map('singbox', _('Settings'));
		const s = m.section(form.NamedSection, 'main', 'singbox');
		s.addremove = false;

		s.tab('general', _('General'));
		s.tab('lan', _('LAN & access control'));
		s.tab('ports', _('Ports & API'));
		s.tab('test', _('Latency test'));
		s.tab('tun', _('TUN'));
		s.tab('perf', _('Performance'));
		s.tab('advanced', _('Advanced'));

		/* general */
		let o = s.taboption('general', form.Flag, 'enabled', _('Enable'),
			_('Start sing-box at boot. You can also use the power button on the overview page.'));
		o.default = '1';
		o.rmempty = false;

		o = s.taboption('general', form.ListValue, 'inbound_mode', _('Proxy method'),
			_('<b>TUN</b>: kernel TUN device with auto-route for all LAN devices (default).<br><b>TPROXY</b>: transparent proxy via nftables (alternative, slightly lighter).<br><b>Proxy port only</b>: no transparent proxy; devices use the SOCKS/HTTP port manually.'));
		o.value('tun', _('TUN'));
		o.value('tproxy', _('Transparent proxy (TPROXY)'));
		o.value('mixed_only', _('Proxy port only'));
		o.default = 'tun';

		o = s.taboption('general', form.ListValue, 'proxy_mode', _('Default routing mode'),
			_('Mode used when the service starts; switch live on the overview page.'));
		o.value('rule', _('Rule'));
		o.value('global', _('Global'));
		o.value('direct', _('Direct'));
		o.default = 'rule';

		o = s.taboption('general', form.ListValue, 'selected', _('Default node'));
		o.value('auto', _('Auto (best)'));
		(nodes.nodes || []).filter((n) => n.tag).forEach((n) => o.value(n.tag));
		o.default = 'auto';

		o = s.taboption('general', form.Flag, 'proxy_router', _('Proxy the router itself'),
			_('Also send traffic generated by the router (opkg/apk, updates, …) through sing-box.'));
		o.default = '1';
		o.depends('inbound_mode', 'tproxy');

		o = s.taboption('general', form.Flag, 'ipv6', _('IPv6 support'),
			_('Proxy IPv6 traffic too. Leave off if your ISP has no IPv6; then IPv6 bypasses the proxy.'));
		o.default = '0';

		o = s.taboption('general', form.Flag, 'sniff', _('Protocol sniffing'),
			_('Detect domains from TLS/HTTP/QUIC so domain rules work for apps that connect by IP.'));
		o.default = '1';

		o = s.taboption('general', form.Flag, 'log_enabled', _('Logging'),
			_('Turn off to stop sing-box from writing logs (also switchable on the Logs page).'));
		o.default = '1';
		o.rmempty = false;

		o = s.taboption('general', form.ListValue, 'log_level', _('Log level'));
		[ 'trace', 'debug', 'info', 'warn', 'error', 'fatal', 'panic' ].forEach((l) => o.value(l));
		o.default = 'warn';
		o.depends('log_enabled', '1');

		/* lan */
		o = s.taboption('lan', widgets.NetworkSelect, 'lan_interfaces', _('LAN interfaces'),
			_('Traffic arriving on these interfaces is proxied (TPROXY mode).'));
		o.multiple = true;
		o.nocreate = true;
		o.default = 'lan';
		o.depends('inbound_mode', 'tproxy');

		o = s.taboption('lan', form.ListValue, 'access_mode', _('Devices'));
		o.value('all', _('Proxy all devices'));
		o.value('include', _('Only proxy the devices below'));
		o.value('exclude', _('Proxy all except the devices below'));
		o.default = 'all';
		o.depends('inbound_mode', 'tproxy');

		o = s.taboption('lan', form.DynamicList, 'access_ips', _('Device IPs'));
		o.datatype = 'or(ip4addr, ip6addr, cidr)';
		Object.keys(hints).forEach((mac) => {
			const h = hints[mac];
			(h.ipaddrs || h.ipv4 || []).forEach((ip) => o.value(ip, '%s (%s)'.format(ip, h.name || mac)));
		});
		o.depends('access_mode', 'include');
		o.depends('access_mode', 'exclude');

		o = s.taboption('lan', form.DynamicList, 'access_macs', _('Device MACs'));
		o.datatype = 'macaddr';
		Object.keys(hints).forEach((mac) => o.value(mac, '%s (%s)'.format(mac, hints[mac].name || (hints[mac].ipaddrs || [])[0] || '?')));
		o.depends('access_mode', 'include');
		o.depends('access_mode', 'exclude');

		o = s.taboption('lan', form.DynamicList, 'bypass_dst', _('Never proxy these destinations'),
			_('Extra IPs/CIDRs that always bypass sing-box at the firewall level (private ranges are already excluded).'));
		o.datatype = 'or(ip4addr, ip6addr, cidr)';
		o.depends('inbound_mode', 'tproxy');

		o = s.taboption('lan', form.DynamicList, 'proxy_ports', _('Only proxy these TCP ports'),
			_('Leave empty to proxy all ports. Example: 80, 443, 8080-8090. UDP is always proxied.'));
		o.datatype = 'or(port, portrange)';
		o.depends('inbound_mode', 'tproxy');

		/* ports */
		o = s.taboption('ports', form.Value, 'mixed_port', _('SOCKS5/HTTP port'),
			_('Mixed proxy port for manual use (browsers, Telegram, …).'));
		o.datatype = 'port';
		o.default = '2080';

		o = s.taboption('ports', form.Flag, 'mixed_allow_lan', _('Allow LAN access to the proxy port'));
		o.default = '0';

		o = s.taboption('ports', form.Value, 'tproxy_port', _('TPROXY port'));
		o.datatype = 'port';
		o.default = '7895';

		o = s.taboption('ports', form.Value, 'dns_port', _('Local DNS port'),
			_('dnsmasq forwards queries to 127.0.0.1 on this port.'));
		o.datatype = 'port';
		o.default = '1053';

		o = s.taboption('ports', form.Value, 'api_port', _('Clash API port'));
		o.datatype = 'port';
		o.default = '9090';

		o = s.taboption('ports', form.Value, 'api_secret', _('Clash API secret'));
		o.password = true;

		o = s.taboption('ports', form.Flag, 'api_allow_lan', _('Allow LAN access to the Clash API'),
			_('Needed for the web dashboard and for apps like Clash dashboards on your phone.'));
		o.default = '0';

		o = s.taboption('ports', form.Flag, 'dashboard', _('Web dashboard'),
			_('Downloads the zashboard web UI on first start and serves it at http://ROUTER:PORT/ui (requires LAN access to the API).'));
		o.default = '0';
		o.depends('api_allow_lan', '1');

		o = s.taboption('ports', form.DummyValue, '_dash', ' ');
		o.depends('dashboard', '1');
		o.cfgvalue = () => {
			const port = uci.get('singbox', 'main', 'api_port') || '9090';
			const secret = uci.get('singbox', 'main', 'api_secret') || '';
			const host = window.location.hostname;
			const url = 'http://%s:%s/ui/#/setup?hostname=%s&port=%s&secret=%s'.format(host, port, encodeURIComponent(host), port, encodeURIComponent(secret));
			return E('a', { 'href': url, 'target': '_blank', 'rel': 'noopener', 'class': 'btn cbi-button' }, _('Open dashboard'));
		};

		/* latency test */
		o = s.taboption('test', form.Value, 'urltest_url', _('Test URL'));
		o.value('https://www.gstatic.com/generate_204');
		o.value('https://cp.cloudflare.com/generate_204');
		o.value('https://www.google.com/generate_204');
		o.value('https://detectportal.firefox.com/success.txt');
		o.default = 'https://www.gstatic.com/generate_204';

		o = s.taboption('test', form.Value, 'urltest_interval', _('Auto test & switch interval'),
			_('How often “Auto (best)” re-tests all nodes and switches to the fastest one. sing-box only switches after a test, so this is also the switching interval. Choose “Manual” to test (and switch) only when you press a test button. You can type any value: 90s, 45m, 2h, …'));
		o.value('manual', _('Manual — only when I press Test'));
		[ [ '1m', 1, 'm' ], [ '3m', 3, 'm' ], [ '5m', 5, 'm' ], [ '10m', 10, 'm' ], [ '15m', 15, 'm' ], [ '30m', 30, 'm' ],
		  [ '1h', 1, 'h' ], [ '2h', 2, 'h' ], [ '6h', 6, 'h' ], [ '12h', 12, 'h' ], [ '24h', 24, 'h' ] ]
			.forEach(([ v, n, u ]) => o.value(v, u == 'm' ? _('Every %d minutes').format(n) : (n == 1 ? _('Every hour') : _('Every %d hours').format(n))));
		o.default = '5m';
		o.rmempty = false;
		o.validate = (sid, v) => /^(manual|[1-9][0-9]*[smh])$/.test((v || '').trim()) ? true : _('Use “manual” or a number followed by s, m or h (e.g. 45m)');

		o = s.taboption('test', form.Value, 'urltest_tolerance', _('Switch tolerance (ms)'),
			_('At each test, “Auto” only switches to another node if it is faster by at least this many milliseconds — avoids flapping between similar nodes.'));
		o.datatype = 'uinteger';
		o.default = '50';

		o = s.taboption('test', form.Button, '_test_now', _('Test now'));
		o.inputtitle = '⏱ ' + _('Test all nodes now');
		o.inputstyle = 'action';
		o.onclick = () => sb.callStatus().then((st) => {
			if (st.running)
				return sb.callClash('group_delay', st.profile ? '' : 'auto').then((r) => r.ok
					? sb.notify(_('Tested %d nodes; “Auto” picked the fastest.').format(Object.keys(r.delays || {}).length))
					: sb.error(_('Latency test failed: %s').format(r.error || '?')));
			return sb.runTask('node-test', 'all', _('Testing latency…'));
		});

		/* performance */
		o = s.taboption('perf', form.Flag, 'max_perf', _('Maximum performance'),
			_('Lets sing-box (and Xray) use all CPU cores and the free RAM: garbage collection only near a memory limit (65% of RAM, less CPU spent on cleanup), higher CPU priority, packet processing spread over all cores (packet steering, irqbalance), larger network buffers for fast / high-latency links, BBR and software flow offloading for direct traffic. Switching it off restores the previous system settings. Routers with less than 384 MB RAM keep the default memory behaviour.'));
		o.default = '1';
		o.rmempty = false;

		o = s.taboption('perf', form.DummyValue, '_perfst', _('Current state'));
		o.rawhtml = true;
		o.load = function() {
			return sb.callPerfStatus().then((r) => { this.st = r || {}; }, () => { this.st = {}; });
		};
		o.cfgvalue = function() {
			const r = this.st || {};
			const yes = (b) => b ? '<span style="color:var(--sb-good)">✔</span>' : '<span class="sb-sub">✘</span>';
			const env = (r.env || []).join(' ') || _('default');
			const rows = [
				[ _('CPU cores / RAM'), '%d / %d MB'.format(r.cpus || 0, r.mem_mb || 0) ],
				[ _('Core memory settings'), env ],
				[ _('Packet steering (all CPUs)'), yes(r.packet_steering == '2') ],
				[ _('Software flow offloading'), yes(r.flow_offloading) ],
				[ _('BBR congestion control'), yes(r.bbr) ],
				[ _('irqbalance'), r.irqbalance_installed ? yes(true) : _('not installed (apk add irqbalance)') ]
			];
			return '<table class="sb-table" style="max-width:520px">' + rows.map((x) => '<tr><td>' + x[0] + '</td><td>' + x[1] + '</td></tr>').join('') + '</table>' +
				'<div class="sb-sub">' + _('Applied when the service starts (Save & Apply restarts it).') + '</div>';
		};
		o.write = o.remove = function() {};

		o = s.taboption('perf', form.ListValue, 'bandwidth_mode', _('Bandwidth limits'),
			_('Hysteria2 links and profiles may contain fixed speeds (up_mbps / down_mbps). sing-box then sends at exactly that rate (“Brutal”) and never faster. <b>Remove limits</b> lets the BBR congestion control find the real speed of your line. <b>Custom</b> forces your own values. Applies to built-in nodes and profiles.'));
		o.value('keep', _('Keep values from links / profiles'));
		o.value('bbr', _('Remove limits (BBR, recommended for fast lines)'));
		o.value('custom', _('Custom speed'));
		o.default = 'bbr';

		o = s.taboption('perf', form.Value, 'bandwidth_down', _('Download (Mbps)'),
			_('Your real line speed. Too high causes packet loss with Brutal.'));
		o.datatype = 'range(1, 100000)';
		o.placeholder = '1000';
		o.depends('bandwidth_mode', 'custom');
		o.rmempty = false;

		o = s.taboption('perf', form.Value, 'bandwidth_up', _('Upload (Mbps)'));
		o.datatype = 'range(1, 100000)';
		o.placeholder = '100';
		o.depends('bandwidth_mode', 'custom');
		o.rmempty = false;

		o = s.taboption('perf', form.ListValue, 'mux_mode', _('Multiplex (mux)'),
			_('Some links enable multiplex, which squeezes all connections into a few shared ones (h2mux/smux) and can limit speed on fast lines.'));
		o.value('keep', _('Keep setting from links / profiles'));
		o.value('off', _('Disable multiplex'));
		o.default = 'keep';

		o = s.taboption('perf', form.DummyValue, '_caps', _('Limits found'));
		o.rawhtml = true;
		o.load = function() {
			return sb.callSpeedCaps().then((r) => { this.caps = r || {}; }, () => { this.caps = {}; });
		};
		o.cfgvalue = function() {
			const esc = (v) => String(v ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
			const r = this.caps || {};
			const list = r.nodes || [];
			if (!list.length)
				return '<span>' + esc(_('None of the %d nodes of the %s has a bandwidth limit or multiplex.').format(r.total || 0,
					r.source == 'profile' ? _('active profile') : _('built-in configuration'))) + '</span>';
			let h = '<div style="margin-bottom:4px">' + esc(_('%d of %d nodes have limits (the setting above overrides them):').format(list.length, r.total || 0)) + '</div>';
			h += '<table class="sb-table" style="max-width:640px"><tr><th>' + esc(_('Node')) + '</th><th>' + esc(_('Type')) +
				'</th><th>' + esc(_('Down / Up (Mbps)')) + '</th><th>' + esc(_('Multiplex')) + '</th></tr>';
			list.slice(0, 50).forEach((n) => {
				const bw = (n.down != null || n.up != null) ? '%s / %s'.format(n.down ?? '-', n.up ?? '-')
					: (n.brutal_down ? 'brutal %s / %s'.format(n.brutal_down, n.brutal_up ?? '-') : '-');
				h += '<tr><td style="unicode-bidi:plaintext">' + esc(n.tag) + '</td><td>' + esc(n.type) + '</td><td>' + esc(bw) + '</td><td>' + esc(n.mux || '-') + '</td></tr>';
			});
			return h + '</table>';
		};
		o.write = o.remove = function() {};

		/* tun */
		o = s.taboption('tun', form.Value, 'tun_mtu', _('MTU'));
		o.datatype = 'range(1280, 65535)';
		o.default = '9000';

		o = s.taboption('tun', form.Flag, 'tun_strict', _('Strict route'));
		o.default = '0';

		o = s.taboption('tun', form.ListValue, 'tun_stack', _('Network stack'),
			_('mixed = system TCP + gVisor UDP (default, best compatibility). If the installed core has no gVisor support (“tiny” package) “system” is used automatically. sing-box 1.15+ ignores this and uses its own stack.'));
		o.value('mixed', _('mixed (default)'));
		o.value('system', 'system');
		o.value('gvisor', 'gvisor');
		o.default = 'mixed';

		/* advanced */
		o = s.taboption('advanced', form.Value, 'core_path', _('sing-box binary'),
			_('Leave empty for automatic: downloaded core first, then /usr/bin/sing-box.'));
		o.placeholder = core.path || '/usr/bin/sing-box';

		o = s.taboption('advanced', form.Flag, 'use_custom', _('Use custom configuration'),
			_('Ignore the generated configuration and run /etc/singbox/custom.json instead (edit it on the Configuration page). Firewall/DNS integration still uses the ports configured here.'));
		o.default = '0';

		return m.render().then((node) => sb.wrap([ node, this.appSection(core), this.coreSection(core), this.xraySection(core) ]));
	}
});
