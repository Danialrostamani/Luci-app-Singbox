'use strict';
'require baseclass';
'require form';
'require ui';
'require singbox.common as sb';

const UA_PRESETS = [
	'v2rayNG/1.9.30',
	'v2rayN/7.10',
	'sing-box/1.13.0',
	'SFA/1.13.0',
	'clash.meta',
	'Hiddify/2.5.7',
	'Mozilla/5.0'
];

/* Subscription editor, shown on the Profiles page (feeds the built-in configuration). */
return baseclass.extend({
	/* Turn a subscription whose link returns a complete sing-box config into a profile. */
	useAsProfile(m, sid) {
		const name = m.data.get('singbox', sid, 'name') || 'Profile';
		const url = m.data.get('singbox', sid, 'url');
		if (!url)
			return sb.error(_('Only link subscriptions can be used as a profile.'));
		return sb.callProfileSave('', name, 'remote', url, m.data.get('singbox', sid, 'update_hours') || '24', m.data.get('singbox', sid, 'via') || 'auto', '', true, '').then((r) => {
			if (!r.ok)
				return sb.error(r.error || _('Save failed'));
			return sb.runTask('profile-update', r.id, _('Downloading profile…')).then(() => {
				if (!confirm(_('Profile “%s” created. Switch to it now? (It keeps its own routing and DNS.)').format(name)))
					return;
				return sb.callProfileActivate(r.id).then((a) => {
					if (!a.ok)
						return sb.error(_('Could not switch: %s').format(a.error || '?'));
					sb.notify(_('Now running “%s”.').format(name));
				});
			});
		});
	},

	render(subs, st) {
		const info = subs.subs || {};
		const m = new form.Map('singbox', _('Subscriptions'),
			_('Node subscriptions for the built-in configuration: nodes are refreshed automatically and merged into the node list (Nodes page). Supported: base64 / share links, “multi” links, Clash & Mihomo YAML, sing-box JSON and Xray JSON (XHTTP / mKCP / Xray-config nodes need the Xray core, see Settings). A link to a complete sing-box configuration can be turned into a profile with one click.'));

		const s = m.section(form.GridSection, 'subscription');
		s.anonymous = true;
		s.addremove = true;
		s.sortable = true;
		s.nodescriptions = true;
		s.addbtntitle = _('Add subscription');
		s.modaltitle = _('Subscription');

		let o = s.option(form.Flag, 'enabled', _('Enabled'));
		o.default = '1';
		o.editable = true;
		o.rmempty = false;

		o = s.option(form.Value, 'name', _('Name'));
		o.rmempty = false;
		o.validate = (sid, v) => (v && v.trim()) ? true : _('Required');

		o = s.option(form.ListValue, 'source', _('Source'));
		o.value('url', _('Link (URL)'));
		o.value('paste', _('Paste content'));
		o.default = 'url';
		o.modalonly = true;

		o = s.option(form.Value, 'url', _('Subscription URL'),
			_('Any subscription link: base64 / share links, Clash or Mihomo YAML, sing-box JSON or Xray JSON. A link to a complete sing-box configuration can also be used as a profile.'));
		o.modalonly = true;
		o.depends('source', 'url');
		o.validate = (sid, v) => /^(https?|sing-box):\/\/\S+$/i.test(v || '') ? true : _('Enter a valid http(s) URL');

		o = s.option(form.TextValue, 'content', _('Content'),
			_('Paste share links (one per line), a base64 subscription, Clash YAML, sing-box JSON or an Xray JSON configuration.'));
		o.modalonly = true;
		o.rows = 10;
		o.depends('source', 'paste');
		o.validate = (sid, v) => (v && v.trim()) ? true : _('Required');

		o = s.option(form.DummyValue, '_nodes', _('Nodes'));
		o.modalonly = false;
		const view_ = this;
		o.textvalue = (sid) => {
			const i = info[sid];
			if (!i)
				return E('span', { 'class': 'sb-sub' }, _('not fetched yet'));
			if (!i.count && i.error)
				return E('div', { 'style': 'color:var(--sb-bad);max-width:360px;word-break:break-word', 'title': (i.errors || []).join('\n') }, _('Update failed: %s').format(i.error));
			return E('div', {}, [
				E('span', {}, [ String(i.count), i.skipped ? E('span', { 'class': 'sb-sub', 'title': (i.errors || []).join('\n') }, ' ' + _('(%d skipped)').format(i.skipped)) : '' ]),
				i.error ? E('div', { 'class': 'sb-sub', 'style': 'color:var(--sb-bad)' }, _('Last update failed: %s').format(i.error)) : '',
				i.full_config ? E('div', { 'style': 'margin-top:4px' }, [
					E('span', { 'class': 'sb-sub' }, _('Full sing-box config') + ' · '),
					E('a', { 'href': '#', 'click': (ev) => { ev.preventDefault(); view_.useAsProfile(m, sid); } }, _('Use as profile'))
				]) : ''
			]);
		};

		o = s.option(form.DummyValue, '_usage', _('Usage'));
		o.modalonly = false;
		o.textvalue = (sid) => {
			const d = info[sid]?.info || {};
			if (!d.total)
				return '-';
			const used = (d.upload || 0) + (d.download || 0);
			const pct = Math.min(100, used / d.total * 100);
			return E('div', { 'style': 'min-width:140px' }, [
				E('div', { 'class': 'sb-bar' + (pct > 90 ? ' hi' : '') }, [ E('div', { 'style': 'width:%.1f%%'.format(pct) }) ]),
				E('div', { 'class': 'sb-sub sb-ltr' }, '%s / %s'.format(sb.fmtBytes(used), sb.fmtBytes(d.total))),
				d.expire ? E('div', { 'class': 'sb-sub' }, _('Expires: %s').format(sb.fmtDate(d.expire))) : ''
			]);
		};

		o = s.option(form.DummyValue, '_updated', _('Last update'));
		o.modalonly = false;
		o.textvalue = (sid) => info[sid] ? sb.fmtAgo(info[sid].updated) : '-';

		o = s.option(form.ListValue, 'update_hours', _('Auto update'));
		o.value('0', _('Never'));
		[ 1, 3, 6, 12, 24, 48, 168 ].forEach((h) => o.value(String(h), h < 24 ? _('Every %d hours').format(h) : _('Every %d days').format(h / 24)));
		o.default = '12';
		o.modalonly = true;
		o.depends('source', 'url');

		o = s.option(form.ListValue, 'via', _('Download via'));
		o.value('auto', _('Direct first, then through the proxy'));
		o.value('direct', _('Direct only'));
		o.value('proxy', _('Through the proxy only'));
		o.default = 'auto';
		o.modalonly = true;
		o.depends('source', 'url');

		o = s.option(form.Value, 'user_agent', _('User-Agent'),
			_('Some panels return a different format depending on the client. v2rayNG returns standard share links - choose it for XHTTP / mKCP nodes, which panels leave out of sing-box and Clash output.'));
		UA_PRESETS.forEach((ua) => o.value(ua));
		o.placeholder = 'v2rayNG/1.9.30';
		o.modalonly = true;
		o.depends('source', 'url');

		o = s.option(form.Value, 'include', _('Only include'),
			_('Keep only nodes whose name contains one of these keywords, separated by |. Example: DE|NL|Germany'));
		o.modalonly = true;

		o = s.option(form.Value, 'exclude', _('Exclude'),
			_('Drop nodes whose name contains one of these keywords, separated by |. Example: expire|traffic|剩余'));
		o.modalonly = true;

		o = s.option(form.Value, 'prefix', _('Name prefix'),
			_('Optional text prepended to every node name from this subscription.'));
		o.modalonly = true;

		o = s.option(form.Button, '_update', _('Update'));
		o.modalonly = false;
		o.inputtitle = _('Update now');
		o.inputstyle = 'action';
		o.editable = true;
		o.onclick = (ev, sid) => {
			return sb.runTask('sub-update', sid, _('Updating subscription…')).then(() => location.reload());
		};

		return m.render().then((node) => {
			const head = E('div', { 'class': 'sb-toolbar' }, [
				E('button', {
					'class': 'btn cbi-button-action',
					'click': ui.createHandlerFn(this, () => sb.runTask('sub-update', 'all', _('Updating subscriptions…')).then(() => location.reload()))
				}, '⟳ ' + _('Update all')),
				E('a', { 'class': 'btn cbi-button', 'href': L.url('admin/services/singbox/nodes') }, _('Show nodes'))
			]);
			const banner = st.profile ? E('div', { 'class': 'sb-alert info' }, _('These subscriptions feed the built-in configuration; the active profile uses its own nodes.')) : E('div');
			const sec = node.querySelector('.cbi-section');
			if (sec) {
				sec.parentNode.insertBefore(banner, sec);
				sec.parentNode.insertBefore(head, sec);
			}
			else
				node.appendChild(head);
			return node;
		});
	}
});
