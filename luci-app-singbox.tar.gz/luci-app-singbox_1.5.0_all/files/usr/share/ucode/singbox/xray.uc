// SPDX-License-Identifier: GPL-3.0-or-later
// luci-app-singbox - Xray sidecar
//
// sing-box cannot speak XHTTP (SplitHTTP), mKCP, VLESS encryption or run
// Xray JSON configurations. Such nodes are stored as { type: 'xray', ... }
// and run by an Xray core next to sing-box: every node gets its own SOCKS
// inbound on 127.0.0.1 and sing-box reaches it through a socks outbound, so
// selection, url tests, routing and DNS keep working in sing-box.

import { chmod } from 'fs';
import * as u from 'singbox.util';

const PROXY_PROTOCOLS = {
	vless: true, vmess: true, trojan: true, shadowsocks: true,
	socks: true, http: true, wireguard: true, hysteria: true
};

const XRAY_NETS = { xhttp: true, splithttp: true, kcp: true, mkcp: true };

const XHTTP_MODES = { auto: true, 'packet-up': true, 'stream-up': true, 'stream-one': true };

// legacy kcp header names <-> FinalMask mkcp-legacy header names
const KCP_TO_MASK = { none: '', '': '', srtp: 'srtp', utp: 'utp', 'wechat-video': 'wechat', wechat: 'wechat', dtls: 'dtls', wireguard: 'wireguard', dns: 'dns' };
const MASK_TO_KCP = { '': 'none', srtp: 'srtp', utp: 'utp', wechat: 'wechat-video', dtls: 'dtls', wireguard: 'wireguard', dns: 'dns' };

function lcs(s) {
	return (s == null) ? '' : lc('' + s);
}

function csv(v) {
	if (v == null)
		return [];
	if (type(v) == 'array')
		return filter(map(v, (x) => trim('' + x)), (x) => x != '');
	return filter(map(split('' + v, ','), (x) => trim(x)), (x) => x != '');
}

function truthy(v) {
	if (v == null)
		return false;
	if (type(v) == 'bool')
		return v;
	let s = lcs(v);
	return s == '1' || s == 'true' || s == 'yes' || s == 'on';
}

function str(v) {
	return (v == null) ? '' : trim('' + v);
}

// Does a normalized share-link node (see parser.uc) need the Xray core?
export function needs_xray(n) {
	let net = lcs(n?.net);
	if (XRAY_NETS[net])
		return true;
	if (lcs(n?.proto) == 'vless') {
		let enc = lcs(n.encryption ?? 'none');
		if (enc != '' && enc != 'none')
			return true;
	}
	return false;
};

function stream_from_node(n) {
	let net = lcs(n.net);
	if (net == '' || net == 'none' || net == 'raw')
		net = 'tcp';
	let s = {};
	let path = str(n.path);
	let host = str(n.host);

	switch (net) {
	case 'tcp':
		s.network = 'raw';
		if (lcs(n.header_type) == 'http') {
			let req = { path: [ path != '' ? split(path, ',')[0] : '/' ] };
			let hosts = csv(host);
			if (length(hosts))
				req.headers = { Host: hosts };
			s.rawSettings = { header: { type: 'http', request: req } };
		}
		break;

	case 'ws':
	case 'websocket':
		s.network = 'ws';
		s.wsSettings = { path: path != '' ? path : '/' };
		if (host != '')
			s.wsSettings.host = host;
		break;

	case 'grpc': {
		s.network = 'grpc';
		let sn = str(n.service_name ?? n.path);
		s.grpcSettings = { serviceName: sn };
		if (n.grpc_multi)
			s.grpcSettings.multiMode = true;
		if (host != '')
			s.grpcSettings.authority = host;
		break;
	}

	case 'httpupgrade':
		s.network = 'httpupgrade';
		s.httpupgradeSettings = { path: path != '' ? path : '/' };
		if (host != '')
			s.httpupgradeSettings.host = host;
		break;

	case 'h2':
	case 'http':
		// HTTP/2 transport was folded into XHTTP
		s.network = 'xhttp';
		s.xhttpSettings = { path: path != '' ? path : '/' };
		if (host != '')
			s.xhttpSettings.host = split(host, ',')[0];
		break;

	case 'xhttp':
	case 'splithttp': {
		s.network = 'xhttp';
		let x = { path: path != '' ? path : '/' };
		if (host != '')
			x.host = host;
		let mode = lcs(n.xhttp_mode ?? '');
		if (mode == '' && XHTTP_MODES[lcs(n.header_type)])
			mode = lcs(n.header_type);
		if (XHTTP_MODES[mode])
			x.mode = mode;
		if (n.xhttp_extra != null && n.xhttp_extra != '') {
			let ex = n.xhttp_extra;
			if (type(ex) == 'string') {
				try { ex = json(ex); } catch (e) { ex = null; }
			}
			if (type(ex) == 'object')
				x.extra = ex;
		}
		s.xhttpSettings = x;
		break;
	}

	case 'kcp':
	case 'mkcp': {
		s.network = 'kcp';
		let k = {};
		let ht = lcs(n.header_type ?? 'none');
		if (ht != '' && ht != 'none') {
			k.header = { type: ht };
			if (ht == 'dns' && host != '')
				k.header.domain = host;
		}
		// v2rayN keeps the mKCP seed in "seed" or in the path
		let seed = str(n.kcp_seed ?? n.path);
		if (seed != '')
			k.seed = seed;
		s.kcpSettings = k;
		break;
	}

	case 'quic':
		return { error: 'QUIC transport was removed from Xray' };

	default:
		return { error: 'unsupported transport: ' + net };
	}

	let sec = lcs(n.security);
	let sni = str(n.sni);
	if (sni == '') {
		if (host != '' && net != 'grpc' && net != 'kcp' && net != 'mkcp')
			sni = split(host, ',')[0];
		else if (!u.is_ip(n.server))
			sni = str(n.server);
	}
	let fp = lcs(n.fp);
	if (sec == 'reality') {
		if (str(n.pbk) == '')
			return { error: 'reality without public key' };
		let r = { serverName: sni, publicKey: str(n.pbk), fingerprint: (fp != '' && fp != 'none') ? fp : 'chrome' };
		if (str(n.sid) != '')
			r.shortId = str(n.sid);
		if (str(n.spx) != '')
			r.spiderX = str(n.spx);
		if (str(n.pqv) != '')
			r.mldsa65Verify = str(n.pqv);
		s.security = 'reality';
		s.realitySettings = r;
	}
	else if (sec == 'tls' || sec == 'xtls') {
		let t = {};
		if (sni != '')
			t.serverName = sni;
		let alpn = csv(n.alpn);
		if (length(alpn))
			t.alpn = alpn;
		if (fp != '' && fp != 'none')
			t.fingerprint = fp;
		if (truthy(n.insecure))
			t.allowInsecure = true;
		if (str(n.ech) != '')
			t.echConfigList = str(n.ech);
		s.security = 'tls';
		s.tlsSettings = t;
	}
	else
		s.security = 'none';

	return { stream: s };
}

function node_meta(o, ob) {
	let ss = ob.streamSettings ?? {};
	o.xray_net = ss.network ?? 'raw';
	o.xray_sec = ss.security ?? 'none';
	return o;
}

// Normalized share-link node -> { outbound: { type: 'xray', ... } }
export function from_node(n) {
	let proto = lcs(n.proto);
	let name = str(n.name);
	if (name == '')
		name = proto + '-' + n.server + ':' + n.port;
	let port = u.toint(n.port, 0);
	let ob = { protocol: proto };

	switch (proto) {
	case 'vless': {
		if (str(n.uuid) == '')
			return { error: 'missing uuid' };
		let user = { id: str(n.uuid), encryption: str(n.encryption) != '' ? str(n.encryption) : 'none' };
		let flow = str(n.flow);
		if (flow != '' && flow != 'none')
			user.flow = flow;
		ob.settings = { vnext: [ { address: n.server, port: port, users: [ user ] } ] };
		break;
	}
	case 'vmess': {
		if (str(n.uuid) == '')
			return { error: 'missing uuid' };
		let sec = lcs(n.method ?? 'auto');
		if (sec == '')
			sec = 'auto';
		ob.settings = { vnext: [ { address: n.server, port: port, users: [ { id: str(n.uuid), security: sec } ] } ] };
		break;
	}
	case 'trojan':
		if (str(n.password) == '')
			return { error: 'missing password' };
		ob.settings = { servers: [ { address: n.server, port: port, password: str(n.password) } ] };
		break;
	case 'shadowsocks':
	case 'ss':
		ob.protocol = 'shadowsocks';
		ob.settings = { servers: [ { address: n.server, port: port, method: str(n.method), password: str(n.password) } ] };
		break;
	default:
		return { error: 'protocol ' + proto + ' is not supported with this transport' };
	}

	let st = stream_from_node(n);
	if (st.error)
		return { error: st.error };
	ob.streamSettings = st.stream;
	if (truthy(n.mux))
		ob.mux = { enabled: true, concurrency: 8 };

	let o = { type: 'xray', tag: name, server: n.server, server_port: port, xray: ob };
	return { outbound: node_meta(o, ob) };
};

// ---------------------------------------------------------------------------
// Xray JSON configurations
// ---------------------------------------------------------------------------

export function is_xray_config(js) {
	if (type(js) != 'object' || type(js.outbounds) != 'array')
		return false;
	for (let i = 0; i < length(js.outbounds); i++) {
		let o = js.outbounds[i];
		if (type(o) == 'object' && type(o.protocol) == 'string' && o.type == null)
			return true;
	}
	return false;
};

// a JSON document holding one Xray config or an array of them
export function is_xray_json(js) {
	if (is_xray_config(js))
		return true;
	if (type(js) == 'array' && length(js)) {
		for (let i = 0; i < length(js); i++)
			if (is_xray_config(js[i]))
				return true;
	}
	return false;
};

function out_refs(o) {
	let r = [];
	let dp = o?.streamSettings?.sockopt?.dialerProxy;
	if (type(dp) == 'string' && dp != '')
		push(r, dp);
	let ps = o?.proxySettings?.tag;
	if (type(ps) == 'string' && ps != '')
		push(r, ps);
	return r;
}

function server_of(o) {
	let s = o.settings ?? {};
	if (type(s.vnext) == 'array' && length(s.vnext))
		return [ s.vnext[0].address, s.vnext[0].port ];
	if (type(s.servers) == 'array' && length(s.servers))
		return [ s.servers[0].address, s.servers[0].port ];
	if (type(s.peers) == 'array' && length(s.peers)) {
		let m = match('' + (s.peers[0].endpoint ?? ''), /^\[?([^\]]*)\]?:([0-9]+)$/);
		if (m)
			return [ m[1], int(m[2]) ];
	}
	if (s.address != null)
		return [ s.address, s.port ];
	return [ null, null ];
}

// { nodes: [ { outbound } ], errors: [] }
export function from_json(js) {
	let res = { nodes: [], errors: [] };
	let configs = (type(js) == 'array') ? filter(js, (c) => is_xray_config(c)) : [ js ];
	let one_per_config = (type(js) == 'array');

	for (let ci = 0; ci < length(configs); ci++) {
		let c = configs[ci];
		let obs = filter(c.outbounds, (o) => type(o) == 'object' && type(o.protocol) == 'string');
		let by_tag = {};
		let referenced = {};
		for (let i = 0; i < length(obs); i++) {
			if (obs[i].tag != null)
				by_tag[obs[i].tag] = obs[i];
			let rf = out_refs(obs[i]);
			for (let j = 0; j < length(rf); j++)
				referenced[rf[j]] = true;
		}
		let cands = filter(obs, (o) => PROXY_PROTOCOLS[o.protocol] && !(o.tag != null && referenced[o.tag]));
		let remarks = str(c.remarks);
		if (!length(cands)) {
			push(res.errors, (remarks != '' ? remarks : ('config #' + (ci + 1))) + ': no proxy outbound');
			continue;
		}
		if (one_per_config) {
			let pick = filter(cands, (o) => o.tag == 'proxy')[0] ?? cands[0];
			cands = [ pick ];
		}
		for (let k = 0; k < length(cands); k++) {
			let main = cands[k];
			// helper outbounds reachable through dialerProxy / proxySettings
			let helpers = [];
			let seen = {};
			if (main.tag != null)
				seen[main.tag] = true;
			let queue = out_refs(main);
			let missing = null;
			for (let q = 0; q < length(queue) && q < 32; q++) {
				let t = queue[q];
				if (seen[t])
					continue;
				seen[t] = true;
				let h = by_tag[t];
				if (!h) {
					missing = t;
					continue;
				}
				push(helpers, u.clone(h));
				let more = out_refs(h);
				for (let j = 0; j < length(more); j++)
					push(queue, more[j]);
			}
			let name;
			if (length(cands) == 1 && remarks != '')
				name = remarks;
			else if (remarks != '')
				name = remarks + ' ' + (main.tag ?? (main.protocol + '-' + k));
			else
				name = main.tag ?? (main.protocol + '-' + (ci + 1) + '-' + (k + 1));
			if (missing) {
				push(res.errors, name + ': outbound "' + missing + '" referenced but missing');
				continue;
			}
			let srv = server_of(main);
			let ob = u.clone(main);
			let o = { type: 'xray', tag: name, server: srv[0], server_port: srv[1], xray: ob };
			if (length(helpers))
				o.xray_helpers = helpers;
			push(res.nodes, { outbound: node_meta(o, ob) });
		}
	}
	return res;
};

// ---------------------------------------------------------------------------
// Sidecar configuration
// ---------------------------------------------------------------------------

function rename_refs(o, prefix, names) {
	let ss = o.streamSettings;
	if (type(ss?.sockopt) == 'object' && names[ss.sockopt.dialerProxy] != null)
		ss.sockopt.dialerProxy = names[ss.sockopt.dialerProxy];
	if (type(o.proxySettings) == 'object' && names[o.proxySettings.tag] != null)
		o.proxySettings.tag = names[o.proxySettings.tag];
}

// mKCP header/seed moved from kcpSettings to streamSettings.finalmask in
// newer Xray releases; convert either way.
function kcp_fix(ss, finalmask) {
	if (type(ss) != 'object' || (ss.network != 'kcp' && ss.network != 'mkcp'))
		return;
	ss.network = 'kcp';
	let k = ss.kcpSettings ?? {};
	if (finalmask) {
		let ht = lcs(k.header?.type ?? '');
		let seed = str(k.seed);
		let domain = str(k.header?.domain);
		delete k.header;
		delete k.seed;
		ss.kcpSettings = k;
		let fm = ss.finalmask ?? {};
		let udp = filter(fm.udp ?? [], (x) => x?.type != 'mkcp-legacy');
		let mh = KCP_TO_MASK[ht] ?? '';
		let has_legacy = length(filter(fm.udp ?? [], (x) => x?.type == 'mkcp-legacy')) > 0;
		if (has_legacy && ht == '' && seed == '')
			return;		// already in the new form
		push(udp, { type: 'mkcp-legacy', settings: { header: mh, value: (mh == 'dns') ? domain : seed } });
		fm.udp = udp;
		ss.finalmask = fm;
	}
	else {
		let legacy = filter(ss.finalmask?.udp ?? [], (x) => x?.type == 'mkcp-legacy')[0];
		if (legacy) {
			let mh = str(legacy.settings?.header);
			let v = str(legacy.settings?.value);
			let ht = MASK_TO_KCP[mh] ?? 'none';
			if (ht != 'none')
				k.header = { type: ht };
			if (ht == 'dns' && v != '')
				k.header.domain = v;
			else if (v != '')
				k.seed = v;
			ss.finalmask.udp = filter(ss.finalmask.udp, (x) => x?.type != 'mkcp-legacy');
			if (!length(ss.finalmask.udp))
				delete ss.finalmask.udp;
			if (!length(keys(ss.finalmask)))
				delete ss.finalmask;
		}
		ss.kcpSettings = k;
	}
}

export function has_kcp(nodes) {
	for (let i = 0; i < length(nodes); i++) {
		let all = [ nodes[i].outbound.xray, ...(nodes[i].outbound.xray_helpers ?? []) ];
		for (let j = 0; j < length(all); j++) {
			let n = all[j]?.streamSettings?.network;
			if (n == 'kcp' || n == 'mkcp')
				return true;
		}
	}
	return false;
};

// Prefer the FinalMask form on recent cores.
export function prefer_finalmask(ver) {
	return ver != null && ver.major >= 26;
};

// nodes: [ { outbound: { type:'xray', tag, xray, xray_helpers }, port } ]
// opts:  { mark, iface, dns: [ ip ], ipv6, finalmask, loglevel }
export function build(nodes, opts) {
	let strategy = opts?.ipv6 ? 'UseIP' : 'UseIPv4';
	let dns = filter(opts?.dns ?? [], (ip) => u.is_ip(ip) && substr(ip, 0, 4) != '127.' && ip != '::1');
	if (!length(dns))
		dns = [ '1.1.1.1', '8.8.8.8' ];

	let sockopt = (so, proxy) => {
		so = (type(so) == 'object') ? so : {};
		if (opts?.mark)
			so.mark = opts.mark;
		if (opts?.iface && so.dialerProxy == null)
			so.interface = opts.iface;
		if (proxy && so.domainStrategy == null)
			so.domainStrategy = strategy;
		return so;
	};

	let direct = {
		tag: 'sbx-direct',
		protocol: 'freedom',
		settings: { domainStrategy: strategy },
		streamSettings: { sockopt: sockopt({}, false) }
	};

	let cfg = {
		log: { loglevel: opts?.loglevel ?? 'warning' },
		dns: { servers: dns, queryStrategy: opts?.ipv6 ? 'UseIP' : 'UseIPv4', tag: 'sbx-dns' },
		inbounds: [],
		outbounds: [ direct ],
		routing: {
			domainStrategy: 'AsIs',
			rules: [ { type: 'field', inboundTag: [ 'sbx-dns' ], outboundTag: 'sbx-direct' } ]
		}
	};

	for (let i = 0; i < length(nodes); i++) {
		let o = nodes[i].outbound;
		let prefix = 'n' + i + '-';
		let main_tag = 'n' + i;
		let names = {};
		let helpers = map(o.xray_helpers ?? [], (h) => u.clone(h));
		for (let j = 0; j < length(helpers); j++)
			if (helpers[j].tag != null)
				names[helpers[j].tag] = prefix + helpers[j].tag;
		let list = [ u.clone(o.xray), ...helpers ];
		for (let j = 0; j < length(list); j++) {
			let x = list[j];
			x.tag = (j == 0) ? main_tag : (names[x.tag] ?? (prefix + 'h' + j));
			rename_refs(x, prefix, names);
			let proxy = PROXY_PROTOCOLS[x.protocol] ? true : false;
			if (x.protocol == 'blackhole' || x.protocol == 'dns' || x.protocol == 'loopback')
				continue;
			// freedom helpers (fragment / noise) resolve the destination themselves:
			// keep that away from the system resolver, which leads into sing-box
			if (x.protocol == 'freedom') {
				x.settings = (type(x.settings) == 'object') ? x.settings : {};
				if (x.settings.domainStrategy == null || x.settings.domainStrategy == 'AsIs')
					x.settings.domainStrategy = strategy;
			}
			let ss = (type(x.streamSettings) == 'object') ? x.streamSettings : {};
			ss.sockopt = sockopt(ss.sockopt, proxy);
			kcp_fix(ss, !!opts?.finalmask);
			x.streamSettings = ss;
			push(cfg.outbounds, x);
		}
		push(cfg.inbounds, {
			tag: 'in-' + i,
			listen: '127.0.0.1',
			port: nodes[i].port,
			protocol: 'socks',
			settings: { auth: 'noauth', udp: true, ip: '127.0.0.1' }
		});
		push(cfg.routing.rules, { type: 'field', inboundTag: [ 'in-' + i ], outboundTag: main_tag });
	}
	return cfg;
};

export function socks_outbound(tag, port) {
	return { type: 'socks', tag: tag, server: '127.0.0.1', server_port: port, version: '5' };
};

export function check(bin, path) {
	let r = u.exec(u.shq(bin) + ' run -test -c ' + u.shq(path));
	let out = replace(trim(r.out), /\x1b\[[0-9;]*m/g, '');
	return { ok: r.code == 0 && !match(out, /Failed to start|failed to/), output: out };
};

// Write the sidecar config; drops nodes Xray rejects.
// Returns { ok, config, dropped: [ tag ], output, finalmask }
export function prepare(bin, ver, nodes, opts, path) {
	let fm = prefer_finalmask(ver);
	let try_cfg = (list, finalmask) => {
		let o = u.clone(opts ?? {});
		o.finalmask = finalmask;
		let cfg = build(list, o);
		u.writeatomic(path, sprintf('%J', cfg));
		chmod(path, 384);
		return { cfg: cfg, chk: check(bin, path) };
	};
	let t = try_cfg(nodes, fm);
	if (!t.chk.ok && has_kcp(nodes)) {
		let t2 = try_cfg(nodes, !fm);
		if (t2.chk.ok) {
			fm = !fm;
			t = t2;
		}
		else
			t = try_cfg(nodes, fm);
	}
	let dropped = [];
	if (!t.chk.ok) {
		// find the nodes Xray rejects one by one (mKCP nodes in both forms)
		let res = [];
		let only_alt = 0, only_cur = 0;
		for (let i = 0; i < length(nodes) && i < 64; i++) {
			let e = { node: nodes[i], cur: try_cfg([ nodes[i] ], fm).chk, alt: null };
			if (has_kcp([ nodes[i] ])) {
				e.alt = try_cfg([ nodes[i] ], !fm).chk;
				if (e.alt.ok && !e.cur.ok)
					only_alt++;
				if (e.cur.ok && !e.alt.ok)
					only_cur++;
			}
			push(res, e);
		}
		if (only_alt > 0 && only_cur == 0)
			fm = !fm;
		let good = [];
		for (let i = 0; i < length(res); i++) {
			let e = res[i];
			let c = (e.alt && fm != prefer_finalmask(ver)) ? e.alt : e.cur;
			if (c.ok)
				push(good, e.node);
			else
				push(dropped, { tag: e.node.outbound.tag, error: u.last_line(c.output) });
		}
		for (let i = 64; i < length(nodes); i++)
			push(good, nodes[i]);
		nodes = good;
		t = try_cfg(good, fm);
	}
	return { ok: t.chk.ok, config: t.cfg, nodes: nodes, dropped: dropped, output: t.chk.output, finalmask: fm };
};

// Default-route device for binding Xray's sockets outside sing-box's TUN.
export function wan_device() {
	let r = u.exec('ip -4 route show default 2>/dev/null; ip -4 route show table main default 2>/dev/null');
	let m = match(r.out, /dev ([^ \t\r\n]+)/);
	if (m && m[1] != u.TUN_NAME)
		return m[1];
	return null;
};
