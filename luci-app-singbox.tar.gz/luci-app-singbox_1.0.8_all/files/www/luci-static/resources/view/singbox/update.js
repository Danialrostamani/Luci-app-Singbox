'use strict';
'require view';
'require ui';
'require singbox.common as sb';

// Update page: this app, the sing-box core and the Xray core.
return view.extend({
	load() {
		return Promise.all([ L.resolveDefault(sb.callCoreInfo(), {}), sb.updates(false) ]).then((r) => {
			const core = r[0] || {};
			core.upd = r[1] || {};
			return core;
		});
	},

	/* red "New: x.y.z" pill next to a section title */
	newBadge(u) {
		return (u && u.update) ? E('span', { 'class': 'sb-new' }, [ E('span', { 'class': 'sb-upd-dot' }), _('New: %s').format(u.latest) ]) : '';
	},

	checkLine(upd) {
		const line = E('div', { 'class': 'sb-sub', 'style': 'margin:-4px 0 10px' });
		const when = upd.checked ? new Date(upd.checked * 1000).toLocaleString() : _('not yet');
		const now = E('a', {
			'href': '#',
			'click': ui.createHandlerFn(this, (ev) => {
				ev.preventDefault();
				line.innerHTML = '';
				line.appendChild(E('span', [ sb.spinner(), ' ', _('Checking GitHub…') ]));
				let n = 0;
				const poll = () => new Promise((res) => window.setTimeout(res, 3000))
					.then(() => sb.updates(false, true))
					.then((r) => (r && r.checking && n++ < 25) ? poll() : location.reload());
				return sb.updates(true).then(poll);
			})
		}, _('Check now'));
		const list = sb.updateText(upd);
		line.appendChild(E('span', [
			list.length ? E('strong', { 'style': 'color:#e5484d' }, _('Updates available: %s').format(list.join(', ')) + ' · ') : (upd.checked && !upd.error ? _('Everything is up to date.') + ' · ' : ''),
			upd.error ? _('Last check failed (%s).').format(upd.error) + ' ' : '',
			_('Last checked: %s').format(when), ' · ', now
		]));
		return line;
	},

	/* After a core task: reload on success, keep the error on screen otherwise. */
	taskDone(t) {
		if (t && t.ok) {
			ui.showModal(_('Done'), [
				E('p', t.message || _('Done')),
				E('div', { 'class': 'right' }, E('button', { 'class': 'btn cbi-button-action', 'click': () => location.reload() }, _('OK')))
			]);
			return;
		}
		ui.showModal(_('Installation failed'), [
			E('p', { 'style': 'color:var(--sb-bad)' }, (t && t.message) || _('The task could not be started.')),
			E('p', { 'class': 'sb-sub' }, _('The current core was not changed.')),
			E('div', { 'class': 'right' }, E('button', { 'class': 'btn', 'click': ui.hideModal }, _('Close')))
		]);
	},

	appSection(core) {
		const cur = core.app_version || '?';
		const ua = core.upd?.app || {};
		const status = E('div', { 'class': 'sb-sub', 'style': 'margin-top:4px' }, ua.update ?
			E('strong', { 'style': 'color:var(--sb-ok)' }, _('New version available: %s').format(ua.latest)) :
			_('Press “Check for updates” to compare with the latest release on GitHub.'));
		const update = E('button', {
			'class': 'btn cbi-button-action',
			'click': ui.createHandlerFn(this, () => {
				if (!confirm(_('Download the latest luci-app-singbox from GitHub and install it? Settings, subscriptions, profiles and the sing-box core are kept. The service restarts.')))
					return;
				return sb.runTask('app-update', '', _('Updating luci-app-singbox…')).then((t) => {
					if (t && t.ok) {
						ui.showModal(_('App updated'), [
							E('p', t.message || _('Done')),
							E('p', { 'class': 'sb-sub' }, _('Reload the page with Ctrl+F5 (or clear the browser cache on a phone) to load the new interface.')),
							E('div', { 'class': 'right' }, E('button', { 'class': 'btn cbi-button-action', 'click': () => location.reload(true) }, _('Reload')))
						]);
					}
					else
						this.taskDone(t);
				});
			})
		}, _('Update app'));
		if (ua.update)
			update.classList.add('important');
		const check = E('button', {
			'class': 'btn cbi-button',
			'click': ui.createHandlerFn(this, () => {
				status.innerHTML = '';
				status.appendChild(E('span', [ sb.spinner(), ' ', _('Checking GitHub…') ]));
				return sb.callAppCheck().then((r) => {
					if (!r || !r.ok) {
						status.textContent = _('Could not check: %s').format((r && r.error) || '?');
						return;
					}
					if (r.update) {
						status.innerHTML = '';
						status.appendChild(E('strong', { 'style': 'color:var(--sb-ok)' }, _('New version available: %s').format(r.latest)));
						update.classList.add('important');
					}
					else
						status.textContent = _('You have the latest version (%s).').format(r.latest || cur);
				});
			})
		}, _('Check for updates'));

		return E('div', { 'class': 'cbi-section' }, [
			E('h3', [ _('App update'), this.newBadge(core.upd?.app) ]),
			E('table', { 'class': 'sb-table', 'style': 'max-width:640px' }, [
				E('tr', [ E('td', _('Installed version')), E('td', { 'class': 'sb-ltr' }, cur) ]),
				E('tr', [ E('td', _('Source')), E('td', { 'class': 'sb-ltr' }, E('a', { 'href': 'https://github.com/Danialrostamani/Luci-app-Singbox', 'target': '_blank', 'rel': 'noopener' }, 'github.com/Danialrostamani/Luci-app-Singbox')) ])
			]),
			E('div', { 'class': 'sb-toolbar', 'style': 'margin-top:10px' }, [ check, update ]),
			status,
			E('div', { 'class': 'sb-sub' }, _('Uses the GitHub mirror from Routing when set, and falls back to the proxy when the service is running.'))
		]);
	},

	/* Version picker shared by both cores: the list comes from GitHub. */
	versionPicker(which, installed) {
		const opts = [
			E('option', { 'value': 'latest' }, _('Latest stable')),
			E('option', { 'value': 'package' }, which == 'xray' ? _('OpenWrt package (xray-core)') : _('OpenWrt package (sing-box standard)'))
		];
		if (which == 'sing-box')
			opts.push(E('option', { 'value': 'package-tiny' }, _('OpenWrt package (sing-box-tiny) — Low RAM/Storage')));
		const sel = E('select', { 'class': 'cbi-input-select', 'style': 'min-width:220px' }, opts);
		const status = E('div', { 'class': 'sb-sub', 'style': 'margin-top:4px' }, [ sb.spinner(), ' ', _('Loading versions from GitHub…') ]);
		const load = () => {
			status.innerHTML = '';
			status.appendChild(E('span', [ sb.spinner(), ' ', _('Loading versions from GitHub…') ]));
			return sb.callCoreReleases(which).then((r) => {
				while (sel.options.length > 2)
					sel.remove(2);
				Array.from(sel.querySelectorAll('optgroup')).forEach((g) => g.remove());
				if (!r || !r.ok) {
					status.textContent = _('Could not load the version list (%s). “Latest stable” and the package still work.').format((r && r.error) || '?');
					return;
				}
				const group = (label, list) => {
					if (!list || !list.length)
						return;
					sel.appendChild(E('optgroup', { 'label': label }, list.map((v) =>
						E('option', { 'value': v }, v + (v == installed ? ' ' + _('(installed)') : '')))));
				};
				group(_('Releases'), r.stable);
				group(_('Pre-releases (testing)'), r.prerelease);
				sel.options[0].textContent = _('Latest stable (%s)').format(r.latest || '?');
				if (installed && r.latest && installed != r.latest && r.stable.indexOf(installed) >= 0 && r.stable.indexOf(installed) > 0)
					status.textContent = _('Installed: %s — newer version available: %s').format(installed, r.latest);
				else
					status.textContent = installed ? _('Installed: %s').format(installed) : _('Not installed');
			}, (e) => { status.textContent = _('Could not load the version list: %s').format(e.message || e); });
		};
		const refresh = E('button', { 'class': 'btn cbi-button', 'title': _('Reload the version list'), 'click': ui.createHandlerFn(this, load) }, '⟳');
		load();
		return { select: sel, status: status, refresh: refresh };
	},

	coreSection(core) {
		const p = this.versionPicker('sing-box', core.downloaded_version || core.package_version || core.version);
		const install = E('button', {
			'class': 'btn cbi-button-action',
			'click': ui.createHandlerFn(this, () => {
				const v = p.select.value;
				const label = p.select.options[p.select.selectedIndex].textContent;
				if (v == 'package-tiny') {
					if (!confirm(_('Use the lightweight OpenWrt sing-box-tiny package (optimized for low RAM and flash)? Any downloaded core is removed and the service restarts.')))
						return;
					return sb.runTask('core-package-tiny', '', _('Switching to the sing-box-tiny package…')).then((t) => this.taskDone(t));
				}
				if (v == 'package') {
					if (!confirm(_('Use the OpenWrt sing-box package (installed with the package manager if missing)? The downloaded core %s is removed and the service restarts.').format(core.downloaded_version || '-')))
						return;
					return sb.runTask('core-package', '', _('Switching to the sing-box package…')).then((t) => this.taskDone(t));
				}
				if (!confirm(_('Install sing-box %s from GitHub (%s)?\n\nThe current core (%s) is removed after the new one has been downloaded and verified. The service restarts.').format(label, core.arch, core.version || _('none'))))
					return;
				return sb.runTask('core-update', v, _('Installing sing-box %s…').format(v)).then((t) => this.taskDone(t));
			})
		}, _('Install selected version'));

		return E('div', { 'class': 'cbi-section' }, [
			E('h3', [ _('sing-box core'), this.newBadge(core.upd?.singbox) ]),
			E('table', { 'class': 'sb-table', 'style': 'max-width:640px' }, [
				E('tr', [ E('td', _('In use')), E('td', { 'class': 'sb-ltr' }, core.version ? '%s (%s)'.format(core.version, core.path) : _('not installed')) ]),
				E('tr', [ E('td', _('Source')), E('td', core.downloaded_version ? _('Official build (GitHub)') : (core.package_is_tiny ? _('OpenWrt package (sing-box-tiny)') : (core.package_version ? _('OpenWrt package (standard)') : '-'))) ]),
				E('tr', [ E('td', _('Architecture')), E('td', { 'class': 'sb-ltr' }, core.arch || '-') ]),
				E('tr', [ E('td', _('Build tags')), E('td', { 'class': 'sb-ltr', 'style': 'font-size:.75rem' }, (core.tags || []).join(', ') || '-') ])
			]),
			E('div', { 'class': 'sb-toolbar', 'style': 'margin-top:10px' }, [ E('strong', _('Version:')), p.select, p.refresh, install ]),
			p.status,
			E('div', { 'class': 'sb-sub' }, _('Pick any release (1.12 or newer) or the OpenWrt package. The official build includes every protocol and is stored in /etc/singbox/bin (kept across firmware upgrades); the previous core is removed once the new one works.') +
				(core.app_is_package ? ' ' + _('The sing-box package itself stays installed because this app was installed as a package that depends on it.') : ''))
		]);
	},

	xraySection(core) {
		const x = core.xray || {};
		const p = this.versionPicker('xray', x.version);
		const install = E('button', {
			'class': 'btn cbi-button-action',
			'click': ui.createHandlerFn(this, () => {
				const v = p.select.value;
				const label = p.select.options[p.select.selectedIndex].textContent;
				const cur = x.version ? x.version : _('none');
				const msg = (v == 'package') ?
					_('Install the OpenWrt package xray-core? The current Xray (%s) is replaced.').format(cur) :
					_('Install Xray %s from GitHub (%s, about 12 MB in /etc/singbox/bin)?\n\nThe current Xray (%s) is removed after the new one has been downloaded and verified.').format(label, core.arch, cur);
				if (!confirm(msg))
					return;
				return sb.runTask('xray-install', v, _('Installing Xray core…')).then((t) => this.taskDone(t));
			})
		}, _('Install selected version'));
		const remove = x.version ? E('button', {
			'class': 'btn cbi-button-negative',
			'click': ui.createHandlerFn(this, () => {
				if (!confirm(_('Uninstall the Xray core? Nodes that need it are skipped until it is installed again.')))
					return;
				return sb.callXrayRemove().then(() => location.reload());
			})
		}, _('Uninstall')) : '';

		let used = '-';
		if (x.version)
			used = (x.nodes || x.skipped) ? _('%d node(s) running through Xray').format(x.nodes || 0) + (x.skipped ? ', ' + _('%d skipped').format(x.skipped) : '') : _('no node needs it right now');
		else if (x.skipped)
			used = _('%d node(s) skipped - install Xray to use them').format(x.skipped);

		return E('div', { 'class': 'cbi-section' }, [
			E('h3', [ _('Xray core (XHTTP, mKCP, Xray configs)'), this.newBadge(core.upd?.xray) ]),
			E('div', { 'class': 'sb-sub', 'style': 'margin-bottom:6px' },
				_('sing-box has no XHTTP (SplitHTTP), mKCP or VLESS encryption and cannot read Xray JSON configurations. Such nodes run through an Xray core next to sing-box; switching, latency tests, routing and DNS still work as usual. Optional - only needed for those nodes.')),
			E('table', { 'class': 'sb-table', 'style': 'max-width:640px' }, [
				E('tr', [ E('td', _('In use')), E('td', { 'class': 'sb-ltr' }, x.version ? '%s (%s)'.format(x.version, x.path) : _('not installed')) ]),
				E('tr', [ E('td', _('Source')), E('td', x.downloaded ? _('Official build (GitHub)') : (x.package ? _('OpenWrt package') : '-')) ]),
				E('tr', [ E('td', _('Nodes')), E('td', used) ])
			]),
			E('div', { 'class': 'sb-toolbar', 'style': 'margin-top:10px' }, [ E('strong', _('Version:')), p.select, p.refresh, install, remove ]),
			p.status,
			E('div', { 'class': 'sb-sub' }, _('Pick any release (24.11 or newer) or the OpenWrt package (may be older; VLESS encryption needs 25.8+). The previous Xray is removed once the new one works.'))
		]);
	},

	/* AmneziaWG: optional kernel packages, nodes become system interfaces */
	awgSection() {
		const body = E('div', {}, E('span', [ sb.spinner(), ' ', _('Checking…') ]));
		L.resolveDefault(sb.callAwgStatus(), {}).then((a) => {
			body.innerHTML = '';
			const b = a.board || {};
			const free = a.free_kb != null ? sb.fmtBytes(a.free_kb * 1024) : '?';
			const enough = a.free_kb == null || a.free_kb >= (a.need_kb || 1024);
			const hasCore = !!a.installed;
			const hasProto = !!a.proto_installed;
			const isFull = hasCore && hasProto;
			body.appendChild(E('table', { 'class': 'sb-table', 'style': 'max-width:640px' }, [
				E('tr', [ E('td', _('Kernel & Tools')), E('td', hasCore ? E('strong', { 'style': 'color:var(--sb-ok)' }, _('Installed')) : _('Not installed')) ]),
				E('tr', [ E('td', _('LuCI Protocol')), E('td', hasProto ? E('strong', { 'style': 'color:var(--sb-ok)' }, _('Installed (luci-proto-amneziawg)')) : _('Not installed')) ]),
				E('tr', [ E('td', _('Firmware')), E('td', { 'class': 'sb-ltr' }, '%s · %s/%s · %s'.format(b.version || '?', b.target || '?', b.subtarget || '?', b.arch || '?')) ]),
				E('tr', [ E('td', _('Free space')), E('td', [ free, ' ', enough ? '' : E('span', { 'style': 'color:var(--sb-bad)' }, _('(about 1 MB needed)')) ]) ]),
				hasCore ? E('tr', [ E('td', _('Interfaces')), E('td', { 'class': 'sb-ltr' }, (a.interfaces || []).join(', ') || '-') ]) : ''
			]));
			if (!hasCore && !a.available)
				body.appendChild(E('div', { 'class': 'sb-alert warn', 'style': 'margin-top:8px' }, _('No prebuilt AmneziaWG packages for this firmware: %s').format(a.error || '?')));
			const btns = [];
			if (!isFull)
				btns.push(E('button', {
					'class': 'btn cbi-button-action',
					'disabled': (a.available && enough) ? null : '',
					'click': ui.createHandlerFn(this, () => {
						if (!confirm(_('Install the AmneziaWG kernel module, tools, and LuCI protocol package for OpenWrt %s from github.com/Slava-Shchipunov/awg-openwrt?').format(b.version || '')))
							return;
						return sb.runTask('awg-install', '', _('Installing AmneziaWG…')).then((t) => this.taskDone(t));
					})
				}, hasCore ? _('Install LuCI Protocol') : _('Install AmneziaWG')));

			if (hasCore || hasProto)
				btns.push(E('button', {
					'class': 'btn cbi-button-negative',
					'click': ui.createHandlerFn(this, () => {
						if (!confirm(_('Remove AmneziaWG? AmneziaWG nodes are skipped until it is installed again.')))
							return;
						return sb.runTask('awg-remove', '', _('Removing AmneziaWG…')).then((t) => this.taskDone(t));
					})
				}, _('Uninstall')));
			body.appendChild(E('div', { 'class': 'sb-toolbar', 'style': 'margin-top:10px' }, btns));
		});
		return E('div', { 'class': 'cbi-section' }, [
			E('h3', _('AmneziaWG (optional)')),
			E('div', { 'class': 'sb-sub', 'style': 'margin-bottom:6px' },
				_('sing-box has no AmneziaWG. With these packages an AmneziaWG .conf (with Jc / S1 / H1 … lines) added under Nodes runs as a separate system interface, and sing-box sends that node’s traffic through it; switching, Auto, tests and routing work as for other nodes. Packages exist only for stable OpenWrt releases and must match the firmware: after a firmware upgrade install them again.')),
			body
		]);
	},

	backupSection() {
		const status = E('div', { 'class': 'sb-sub', 'style': 'margin-top:6px' });
		const download = E('button', {
			'class': 'btn cbi-button-action',
			'click': ui.createHandlerFn(this, () => sb.callBackupCreate().then((r) => {
				if (!r || !r.ok)
					return sb.error((r && r.error) || _('Backup failed'));
				const d = new Date();
				const name = 'luci-app-singbox-backup-%04d%02d%02d.json'.format(d.getFullYear(), d.getMonth() + 1, d.getDate());
				const blob = new Blob([ JSON.stringify(r.backup, null, 1) ], { 'type': 'application/json' });
				const a = E('a', { 'href': URL.createObjectURL(blob), 'download': name, 'style': 'display:none' });
				document.body.appendChild(a);
				a.click();
				window.setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
				status.textContent = _('Saved %s.').format(name);
			}))
		}, _('Download backup'));
		const file = E('input', { 'type': 'file', 'accept': '.json,application/json', 'style': 'display:none' });
		file.addEventListener('change', () => {
			const f = file.files[0];
			file.value = '';
			if (!f)
				return;
			if (f.size > 4 * 1024 * 1024)
				return sb.error(_('This file is too large to be a backup.'));
			const rd = new FileReader();
			rd.onload = () => {
				let b = null;
				try { b = JSON.parse(rd.result); } catch (e) {}
				if (!b || b.app != 'luci-app-singbox')
					return sb.error(_('This is not a luci-app-singbox backup.'));
				if (!confirm(_('Restore the backup from %s (version %s)? All current settings, subscriptions and profiles of this app are replaced. The service restarts and subscriptions are downloaded again.').format(b.created ? new Date(b.created * 1000).toLocaleString() : '?', b.version || '?')))
					return;
				status.textContent = _('Restoring…');
				sb.callBackupRestore(rd.result).then((r) => {
					if (!r || !r.ok)
						return sb.error((r && r.error) || _('Restore failed'));
					ui.showModal(_('Backup restored'), [
						E('p', _('Settings and %d file(s) restored. The service is restarting and subscriptions are being downloaded again.').format(r.files || 0)),
						E('div', { 'class': 'right' }, E('button', { 'class': 'btn cbi-button-action', 'click': () => location.reload() }, _('OK')))
					]);
				});
			};
			rd.readAsText(f);
		});
		return E('div', { 'class': 'cbi-section' }, [
			E('h3', _('Backup & restore')),
			E('div', { 'class': 'sb-sub', 'style': 'margin-bottom:6px' }, _('One file with all settings of this app: subscriptions, nodes, routing, DNS, local profiles and the custom configuration. Use it after a reset or to set up another router the same way. Subscription node lists and remote profiles are downloaded again after a restore. The file contains your subscription links and node passwords: keep it private.')),
			E('div', { 'class': 'sb-toolbar' }, [
				download,
				E('button', { 'class': 'btn cbi-button', 'click': () => file.click() }, _('Restore from file…')), file
			]),
			status
		]);
	},

	render(core) {
		return sb.wrap([
			E('h2', _('Update')),
			E('div', { 'class': 'cbi-map-descr' }, _('Update this app and choose the sing-box and Xray core versions. Settings, subscriptions and profiles are always kept.')),
			this.checkLine(core.upd || {}),
			this.appSection(core),
			this.coreSection(core),
			this.xraySection(core),
			this.awgSection(),
			this.backupSection(),
			E('div', { 'class': 'cbi-section' }, [
				E('h3', _('About')),
				E('table', { 'class': 'sb-table', 'style': 'max-width:640px' }, [
					E('tr', [ E('td', _('App')), E('td', 'luci-app-singbox ' + (core.app_version || '')) ]),
					E('tr', [ E('td', _('Author')), E('td', {}, E('strong', {}, 'Danial Rostamani')) ]),
					E('tr', [ E('td', _('Contact')), E('td', {}, E('a', { 'href': 'https://t.me/Drostamani', 'target': '_blank', 'rel': 'noopener' }, 't.me/Drostamani')) ]),
					E('tr', [ E('td', _('Project')), E('td', {}, E('a', { 'href': 'https://github.com/Danialrostamani/Luci-app-Singbox', 'target': '_blank', 'rel': 'noopener' }, 'github.com/Danialrostamani/Luci-app-Singbox')) ]),
					E('tr', [ E('td', _('Rule-sets')), E('td', {}, E('a', { 'href': 'https://github.com/Danialrostamani/sing-box-iran-rules', 'target': '_blank', 'rel': 'noopener' }, 'github.com/Danialrostamani/sing-box-iran-rules')) ]),
					E('tr', [ E('td', _('License')), E('td', {}, _('© 2026 Danial Rostamani. All rights reserved. Free to install and use; copying, modifying or redistributing requires written permission.')) ])
				])
			])
		]);
	},

	handleSave: null,
	handleSaveApply: null,
	handleReset: null
});
