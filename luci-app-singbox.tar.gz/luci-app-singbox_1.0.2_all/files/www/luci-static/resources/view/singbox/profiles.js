'use strict';
'require view';
'require ui';
'require singbox.common as sb';
'require singbox.subsform as subsform';

const UA_PRESETS = [ 'sing-box/1.13.0 (SFA)', 'SFA/1.13.0', 'sing-box', 'Hiddify/2.5.7', 'v2rayNG/1.9.30' ];

/* sing-box://import-remote-profile?url=<encoded>#<name> (SFA / SFI deep link) */
function parseDeepLink(s) {
	const m = /^sing-box:\/\/import-remote-profile\?(.*)$/i.exec((s || '').trim());
	if (!m)
		return null;
	let q = m[1], name = '';
	const h = q.indexOf('#');
	if (h >= 0) {
		name = decodeURIComponent(q.slice(h + 1));
		q = q.slice(0, h);
	}
	const params = new URLSearchParams(q);
	const url = params.get('url');
	return url ? { url: url, name: name || params.get('name') || '' } : null;
}

return view.extend({
	load() {
		return Promise.all([
			sb.callProfiles(),
			L.resolveDefault(sb.callStatus(), {}),
			L.resolveDefault(sb.callSubs(), { subs: {} })
		]);
	},

	/* ---------- actions ---------- */

	reload() {
		return this.load().then((d) => this.draw(d));
	},

	activate(id, name) {
		ui.showModal(_('Switching profile…'), [
			E('p', { 'class': 'spinning' }, id ? _('Validating and starting “%s”…').format(name) : _('Switching to the built-in configuration…'))
		]);
		return sb.callProfileActivate(id).then((r) => {
			ui.hideModal();
			if (!r.ok)
				return sb.error(_('Could not switch: %s').format(r.error || '?'));
			if (r.running === false)
				sb.notify(_('Saved. It will be used when the service starts.'));
			else
				sb.notify(id ? _('Now running “%s”.').format(name) : _('Now running the built-in configuration.'));
			if (r.warnings?.length)
				ui.addTimeLimitedNotification(_('Warnings'), E('ul', r.warnings.map((w) => E('li', w))), 10000, 'warning');
		}).then(() => this.reload());
	},

	update(p) {
		return sb.runTask('profile-update', p.id, _('Updating profile…')).then(() => this.reload());
	},

	check(p) {
		return sb.callProfileCheck(p.id).then((r) => {
			const body = [];
			body.push(r.ok
				? E('div', { 'class': 'sb-alert info' }, _('“%s” passes “sing-box check” with the router integration applied (%d nodes, %d groups).').format(p.name, r.stats?.nodes ?? 0, r.stats?.groups ?? 0))
				: E('div', { 'class': 'sb-alert bad' }, [ E('strong', _('Check failed')), E('pre', { 'class': 'sb-pre', 'style': 'margin-top:6px' }, r.error || r.output || '?') ]));
			if (r.warnings?.length)
				body.push(E('div', { 'class': 'sb-alert warn' }, [ E('strong', _('Adjustments for the router')), E('ul', r.warnings.map((w) => E('li', w))) ]));
			body.push(E('div', { 'class': 'right' }, [ E('button', { 'class': 'btn cbi-button-action', 'click': ui.hideModal }, _('Close')) ]));
			ui.showModal(_('Check: %s').format(p.name), body);
		});
	},

	exportProfile(p) {
		return sb.callProfileContent(p.id).then((r) => {
			if (!r.ok || !r.text)
				return sb.error(_('Profile has no content yet.'));
			const blob = new Blob([ r.text ], { type: 'application/json' });
			const a = E('a', { 'href': URL.createObjectURL(blob), 'download': (p.name || 'profile').replace(/[^\w.-]+/g, '_') + '.json' });
			document.body.appendChild(a);
			a.click();
			document.body.removeChild(a);
		});
	},

	duplicate(p) {
		return sb.callProfileContent(p.id).then((r) => {
			if (!r.ok || !r.text)
				return sb.error(_('Profile has no content yet.'));
			return sb.callProfileSave('', _('%s (copy)').format(p.name), 'local', '', '', '', '', p.integrate, r.text, p.core || 'auto').then((s) => {
				if (!s.ok)
					return sb.error(s.error);
				sb.notify(_('Local copy created.'));
				return this.reload();
			});
		});
	},

	remove(p) {
		if (!confirm(_('Delete profile “%s”?').format(p.name)))
			return;
		return sb.callProfileDelete(p.id).then(() => this.reload());
	},

	/* ---------- editor ---------- */

	editor(p) {
		const isNew = !p;
		p = p || { id: '', name: '', type: 'remote', url: '', update_hours: '24', via: 'auto', user_agent: '', integrate: true };

		const name = E('input', { 'type': 'text', 'class': 'cbi-input-text', 'value': p.name, 'placeholder': _('e.g. My provider') });
		const typeSel = E('select', { 'class': 'cbi-input-select' }, [
			E('option', { 'value': 'remote', 'selected': p.type == 'remote' ? '' : null }, _('Remote (URL, updated automatically)')),
			E('option', { 'value': 'local', 'selected': p.type == 'local' ? '' : null }, _('Local (paste or upload)'))
		]);
		if (!isNew)
			typeSel.disabled = true;

		const url = E('input', { 'type': 'text', 'class': 'cbi-input-text', 'value': p.url || '', 'placeholder': 'https://… ' + _('or') + ' sing-box://import-remote-profile?url=…' });
		url.addEventListener('input', () => {
			const dl = parseDeepLink(url.value);
			if (dl) {
				url.value = dl.url;
				if (!name.value.trim() && dl.name)
					name.value = dl.name;
			}
		});

		const hours = E('select', { 'class': 'cbi-input-select' }, [ [ '0', _('Never') ], [ '1', _('Every hour') ], [ '6', _('Every %d hours').format(6) ], [ '12', _('Every %d hours').format(12) ], [ '24', _('Every day') ], [ '72', _('Every %d days').format(3) ], [ '168', _('Every week') ] ]
			.map(([ v, l ]) => E('option', { 'value': v, 'selected': String(p.update_hours) == v ? '' : null }, l)));
		const via = E('select', { 'class': 'cbi-input-select' }, [ [ 'auto', _('Direct first, then through the proxy') ], [ 'direct', _('Direct only') ], [ 'proxy', _('Through the proxy only') ] ]
			.map(([ v, l ]) => E('option', { 'value': v, 'selected': p.via == v ? '' : null }, l)));
		const ua = E('input', { 'type': 'text', 'class': 'cbi-input-text', 'value': p.user_agent || '', 'placeholder': UA_PRESETS[0], 'list': 'sb-ua-list' });
		const uaList = E('datalist', { 'id': 'sb-ua-list' }, UA_PRESETS.map((v) => E('option', { 'value': v })));

		const ta = E('textarea', { 'class': 'sb-modal-ta', 'style': 'min-height:260px', 'spellcheck': 'false', 'placeholder': '{\n  "outbounds": [ … ],\n  "route": { … }\n}\n\n' + _('or share links, a subscription body, Clash YAML or a WireGuard .conf ([Interface] / [Peer])') });
		const file = E('input', { 'type': 'file', 'accept': '.json,.conf,.txt,.yaml,.yml,application/json', 'style': 'display:none' });
		file.addEventListener('change', () => {
			const f = file.files[0];
			if (!f)
				return;
			const rd = new FileReader();
			rd.onload = () => {
				ta.value = rd.result;
				if (!name.value.trim())
					name.value = f.name.replace(/\.(json|conf|txt|ya?ml)$/i, '');
			};
			rd.readAsText(f);
		});
		const fromGenerated = E('button', {
			'class': 'btn cbi-button',
			'click': ui.createHandlerFn(this, () => sb.callConfig().then((c) => {
				try { ta.value = JSON.stringify(JSON.parse(c.config), null, 2); }
				catch (e) { sb.error(_('No generated configuration yet.')); }
			}))
		}, _('Start from the built-in config'));
		const contentHint = E('div', { 'class': 'sb-sub' });

		const coreSel = E('select', { 'class': 'cbi-input-select' }, [
			[ 'auto', _('Auto: sing-box, Xray only where needed (recommended)') ],
			[ 'xray', _('Xray: run VLESS / VMess / Trojan / Shadowsocks through Xray') ],
			[ 'singbox', _('sing-box only: skip nodes that need Xray') ]
		].map(([ v, l ]) => E('option', { 'value': v, 'selected': (p.core || 'auto') == v ? '' : null }, l)));

		const integrate = E('input', { 'type': 'checkbox' });
		integrate.checked = p.integrate !== false;

		const remoteRows = E('div', {}, [
			E('div', { 'class': 'sb-form-row' }, [ E('label', _('Profile URL')), url ]),
			E('div', { 'class': 'sb-form-row' }, [ E('label', _('Auto update')), hours ]),
			E('div', { 'class': 'sb-form-row' }, [ E('label', _('Download via')), via ]),
			E('div', { 'class': 'sb-form-row' }, [ E('label', _('User-Agent')), ua, uaList ])
		]);
		const localRows = E('div', {}, [
			E('div', { 'class': 'sb-form-row' }, [
				E('label', _('Configuration or subscription')),
				ta,
				E('div', { 'class': 'sb-toolbar', 'style': 'margin-top:6px' }, [
					E('button', { 'class': 'btn cbi-button', 'click': () => file.click() }, _('Upload file…')), file, fromGenerated
				]),
				contentHint
			])
		]);

		const sync = () => {
			const local = typeSel.value == 'local';
			remoteRows.style.display = local ? 'none' : '';
			localRows.style.display = local ? '' : 'none';
		};
		typeSel.addEventListener('change', sync);
		sync();

		if (!isNew) {
			sb.callProfileContent(p.id).then((r) => {
				if (r.ok)
					ta.value = r.text;
				if (p.type == 'remote')
					contentHint.textContent = _('Remote profiles are replaced on every update; use “Duplicate” to keep an edited copy.');
			});
			if (p.type == 'remote')
				localRows.style.display = 'none';
		}

		const save = () => {
			const t = typeSel.value;
			const content = (t == 'local') ? ta.value : '';
			if (!name.value.trim())
				return Promise.resolve(sb.error(_('Name is required.')));
			if (t == 'local') {
				// a JSON configuration, or subscription content (links, base64, Clash YAML)
				const c0 = content.trim().charAt(0);
				if (c0 == '{' || c0 == '[') {
					try { JSON.parse(content); }
					catch (e) { return Promise.resolve(sb.error(_('Invalid JSON: %s').format(e.message))); }
				}
			}
			return sb.callProfileSave(p.id, name.value.trim(), t, url.value.trim(), hours.value, via.value, ua.value.trim(), integrate.checked, content, coreSel.value).then((r) => {
				if (!r.ok)
					return sb.error(r.error || _('Save failed'));
				ui.hideModal();
				if (t == 'remote' && (r.created || url.value.trim() != (p.url || '')))
					return sb.runTask('profile-update', r.id, _('Downloading profile…')).then(() => this.reload());
				sb.notify(_('Profile saved.'));
				return this.reload();
			});
		};

		ui.showModal(isNew ? _('New profile') : _('Edit profile'), [
			E('div', { 'class': 'sb-wrap' }, [
				E('div', { 'class': 'sb-form-row' }, [ E('label', _('Name')), name ]),
				E('div', { 'class': 'sb-form-row' }, [ E('label', _('Type')), typeSel ]),
				remoteRows,
				localRows,
				E('div', { 'class': 'sb-form-row' }, [
					E('label', _('Core')), coreSel,
					E('div', { 'class': 'sb-sub' }, _('For subscription links (share links, base64, Clash, Xray JSON). Xray is needed for XHTTP, mKCP and Xray configurations; Hysteria2, TUIC and AnyTLS always run in sing-box. A complete sing-box configuration always runs in sing-box.'))
				]),
				E('div', { 'class': 'sb-form-row' }, [
					E('label', { 'style': 'font-weight:normal' }, [ integrate, ' ', E('strong', _('Adapt for the router (recommended)')) ]),
					E('div', { 'class': 'sb-sub' }, _('Replaces the profile’s TUN / proxy inbounds with this router’s TPROXY/TUN, DNS and proxy-port inbounds, routes LAN DNS through it, fixes “local” DNS loops and connects the Clash API used by this interface. Turn off only to run the file exactly as written.'))
				])
			]),
			E('div', { 'class': 'right' }, [
				E('button', { 'class': 'btn', 'click': ui.hideModal }, _('Cancel')), ' ',
				E('button', { 'class': 'btn cbi-button-positive', 'click': ui.createHandlerFn(this, save) }, _('Save'))
			])
		]);
		name.focus();
	},

	/* ---------- rendering ---------- */

	builtinCard(active, st) {
		return E('div', { 'class': 'sb-card' + (active ? ' active' : '') }, [
			E('div', { 'class': 'sb-row sb-between' }, [
				E('strong', _('Built-in configuration')),
				active ? E('span', { 'class': 'sb-badge' }, _('Active')) : E('span', { 'class': 'sb-badge muted' }, _('Generated'))
			]),
			E('div', { 'class': 'sb-sub', 'style': 'margin-top:6px' }, _('Built from your Subscriptions, Nodes, Routing and DNS settings (Iran direct, ad blocking, custom rules).')),
			E('div', { 'class': 'sb-sub' }, _('%d nodes').format(st?.state?.nodes ?? 0)),
			E('div', { 'class': 'sb-actions' }, [
				active ? '' : E('button', { 'class': 'btn cbi-button-action', 'click': ui.createHandlerFn(this, () => this.activate('', '')) }, _('Use')),
				E('a', { 'class': 'btn cbi-button', 'href': L.url('admin/services/singbox/nodes') }, _('Nodes'))
			])
		]);
	},

	profileCard(p, active, running) {
		const i = p.info || {};
		const u = i.info || {};
		const used = (u.upload || 0) + (u.download || 0);
		const pct = u.total ? Math.min(100, used / u.total * 100) : 0;
		const hasContent = !!i.size;
		const badges = [ E('span', { 'class': 'sb-badge muted' }, p.type == 'remote' ? _('Remote') : _('Local')) ];
		if ((p.info || {}).kind == 'subscription')
			badges.push(E('span', { 'class': 'sb-badge muted', 'title': _('Node subscription: runs with the built-in routing and DNS') }, _('Subscription')));
		if (active)
			badges.unshift(E('span', { 'class': 'sb-badge' }, running ? _('Active') : _('Selected')));

		const actions = [];
		if (!active)
			actions.push(E('button', { 'class': 'btn cbi-button-action', 'disabled': (hasContent || p.type == 'remote') ? null : true, 'click': ui.createHandlerFn(this, () => this.activate(p.id, p.name)) }, _('Use')));
		if (p.type == 'remote')
			actions.push(E('button', { 'class': 'btn cbi-button', 'click': ui.createHandlerFn(this, () => this.update(p)) }, _('Update')));
		actions.push(E('button', { 'class': 'btn cbi-button', 'click': () => this.editor(p) }, _('Edit')));
		if (hasContent) {
			actions.push(E('button', { 'class': 'btn cbi-button', 'click': ui.createHandlerFn(this, () => this.check(p)) }, _('Check')));
			actions.push(E('button', { 'class': 'btn cbi-button', 'click': ui.createHandlerFn(this, () => this.exportProfile(p)) }, _('Export')));
			actions.push(E('button', { 'class': 'btn cbi-button', 'click': ui.createHandlerFn(this, () => this.duplicate(p)) }, _('Duplicate')));
		}
		actions.push(E('button', { 'class': 'btn cbi-button-negative', 'click': ui.createHandlerFn(this, () => this.remove(p)) }, _('Delete')));

		return E('div', { 'class': 'sb-card' + (active ? ' active' : '') }, [
			E('div', { 'class': 'sb-row sb-between', 'style': 'flex-wrap:nowrap' }, [
				E('strong', { 'style': 'overflow:hidden;text-overflow:ellipsis;white-space:nowrap' }, p.name),
				E('span', { 'class': 'sb-row', 'style': 'gap:4px;flex-wrap:nowrap' }, badges)
			]),
			p.type == 'remote' ? E('div', { 'class': 'sb-sub sb-ltr', 'style': 'overflow:hidden;text-overflow:ellipsis;white-space:nowrap', 'title': p.url }, p.url) : '',
			E('div', { 'class': 'sb-sub', 'style': 'margin-top:4px' }, hasContent
				? _('%d nodes · %d groups · %s').format(i.nodes ?? 0, i.groups ?? 0, sb.fmtBytes(i.size))
				: _('Not downloaded yet')),
			u.total ? E('div', {}, [
				E('div', { 'class': 'sb-bar' + (pct > 90 ? ' hi' : '') }, [ E('div', { 'style': 'width:%.1f%%'.format(pct) }) ]),
				E('div', { 'class': 'sb-sub sb-row sb-between' }, [
					E('span', '%s / %s'.format(sb.fmtBytes(used), sb.fmtBytes(u.total))),
					u.expire ? E('span', _('Expires: %s').format(sb.fmtDate(u.expire))) : ''
				])
			]) : '',
			E('div', { 'class': 'sb-sub' }, [
				p.type == 'remote' ? _('Updated %s').format(sb.fmtAgo(i.updated)) : _('Saved %s').format(sb.fmtAgo(i.updated)),
				p.integrate ? '' : ' · ' + _('runs as-is')
			]),
			i.error ? E('div', { 'class': 'sb-sub', 'style': 'color:var(--sb-bad)' }, i.error) : '',
			E('div', { 'class': 'sb-actions', 'style': 'flex-wrap:wrap' }, actions)
		]);
	},

	draw([ data, st ]) {
		/* only the profile cards are redrawn; the subscription form keeps its state */
		const root = this.root;
		while (root.firstChild)
			root.removeChild(root.firstChild);

		const active = data.active || '';
		const running = !!st.running;
		const cards = [ this.builtinCard(active == '', st) ];
		(data.profiles || []).forEach((p) => cards.push(this.profileCard(p, p.id == active, running)));

		if (st.state && st.state.source == 'builtin' && active != '' && st.state.warnings?.length)
			root.appendChild(E('div', { 'class': 'sb-alert warn' }, [ E('strong', _('The selected profile could not be used:')), E('ul', st.state.warnings.slice(0, 3).map((w) => E('li', w))) ]));
		root.appendChild(sb.taskBanner(data.task));
		root.appendChild(E('div', { 'class': 'sb-grid sb-wide' }, cards));
		if (!(data.profiles || []).length)
			root.appendChild(E('div', { 'class': 'sb-empty' }, [
				E('p', _('No profiles yet.')),
				E('p', _('A profile is a complete sing-box configuration (for example the “remote profile” link for the sing-box app, or a JSON file exported from a phone or PC) or any subscription link: share links, base64, Clash YAML or Xray JSON. Subscription profiles run their nodes with the built-in routing and DNS.'))
			]));
	},

	render(data) {
		this.root = E('div');
		this.draw(data);
		return subsform.render(data[2] || { subs: {} }, data[1] || {}).then((subsNode) => sb.wrap([
			E('h2', _('Profiles')),
			E('div', { 'class': 'cbi-map-descr' }, _('Run a complete sing-box configuration instead of the built-in one, just like profiles in the sing-box apps. Remote profiles update automatically; the router’s transparent proxy, DNS and this interface keep working.')),
			E('div', { 'class': 'sb-toolbar' }, [
				E('button', { 'class': 'btn cbi-button-positive', 'click': () => this.editor(null) }, '+ ' + _('New profile')),
				E('button', {
					'class': 'btn cbi-button',
					'click': ui.createHandlerFn(this, () => sb.runTask('profile-update', 'all', _('Updating profiles…')).then(() => this.reload()))
				}, '⟳ ' + _('Update all remote'))
			]),
			this.root,
			E('div', { 'style': 'margin-top:28px' }, [ subsNode ])
		]));
	}
});
