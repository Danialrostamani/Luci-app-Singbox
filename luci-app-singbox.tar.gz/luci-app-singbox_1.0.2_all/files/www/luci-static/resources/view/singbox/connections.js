'use strict';
'require view';
'require poll';
'require ui';
'require singbox.common as sb';

return view.extend({
	filter: '',
	paused: false,
	prev: {},

	load() {
		return L.resolveDefault(sb.callClash('connections'), { ok: false });
	},

	host(c) {
		const m = c.metadata || {};
		const h = m.host || m.destinationIP || '';
		const p = m.destinationPort ? ':' + m.destinationPort : '';
		return h.includes(':') && !m.host ? '[' + h + ']' + p : h + p;
	},

	draw(data) {
		const body = this.tbody;
		while (body.firstChild)
			body.removeChild(body.firstChild);

		if (!data.ok) {
			this.summary.textContent = _('Service not running or Clash API not reachable.');
			return;
		}
		const now = Date.now();
		const q = this.filter.toLowerCase();
		const list = (data.connections || []).filter((c) => {
			if (!q)
				return true;
			const m = c.metadata || {};
			return [ m.host, m.destinationIP, m.sourceIP, c.rule, (c.chains || []).join(' ') ].join(' ').toLowerCase().includes(q);
		}).sort((a, b) => (b.download + b.upload) - (a.download + a.upload));

		const cur = {};
		list.forEach((c) => {
			const m = c.metadata || {};
			const prev = this.prev[c.id];
			let rate = '';
			if (prev) {
				const dt = (now - prev.t) / 1000;
				const dl = Math.max(0, (c.download - prev.d) / dt), ul = Math.max(0, (c.upload - prev.u) / dt);
				if (dl + ul > 0)
					rate = '↓%s ↑%s'.format(sb.fmtSpeed(dl), sb.fmtSpeed(ul));
			}
			cur[c.id] = { t: now, d: c.download, u: c.upload };
			const age = c.start ? (now - Date.parse(c.start)) / 1000 : null;
			const chain = (c.chains || []).slice().reverse().join(' → ');
			body.appendChild(E('tr', [
				E('td', [
					E('div', { 'class': 'sb-ltr', 'style': 'word-break:break-all' }, this.host(c)),
					E('div', { 'class': 'sb-sub sb-ltr' }, '%s · %s%s'.format((m.network || '').toUpperCase(), m.sourceIP || '', m.sourcePort ? ':' + m.sourcePort : ''))
				]),
				E('td', [ E('div', { 'style': 'unicode-bidi:plaintext' }, chain), E('div', { 'class': 'sb-sub' }, c.rule + (c.rulePayload ? ' (' + c.rulePayload + ')' : '')) ]),
				E('td', { 'class': 'num sb-ltr' }, [ E('div', '↓ ' + sb.fmtBytes(c.download)), E('div', '↑ ' + sb.fmtBytes(c.upload)), E('div', { 'class': 'sb-sub' }, rate) ]),
				E('td', { 'class': 'num' }, sb.fmtDuration(age)),
				E('td', { 'class': 'num' }, E('button', {
					'class': 'btn cbi-button-negative',
					'style': 'padding:0 8px',
					'title': _('Close connection'),
					'click': ui.createHandlerFn(this, () => sb.callClash('close', '', c.id).then(() => this.refresh()))
				}, '✕'))
			]));
		});
		this.prev = cur;
		if (!list.length)
			body.appendChild(E('tr', [ E('td', { 'colspan': 5, 'class': 'sb-sub', 'style': 'text-align:center' }, _('No connections.')) ]));
		this.summary.textContent = _('%d connections · total ↓ %s ↑ %s').format((data.connections || []).length, sb.fmtBytes(data.downloadTotal), sb.fmtBytes(data.uploadTotal));
	},

	refresh() {
		if (this.paused)
			return Promise.resolve();
		return L.resolveDefault(sb.callClash('connections'), { ok: false }).then((d) => this.draw(d));
	},

	render(data) {
		this.tbody = E('tbody');
		this.summary = E('div', { 'class': 'sb-sub' });
		const search = E('input', { 'type': 'search', 'class': 'cbi-input-text', 'placeholder': _('Filter by host, IP, rule or node…') });
		search.addEventListener('input', () => { this.filter = search.value; this.refresh(); });
		const pause = E('button', { 'class': 'btn cbi-button', 'click': (ev) => {
			this.paused = !this.paused;
			ev.target.textContent = this.paused ? '▶ ' + _('Resume') : '⏸ ' + _('Pause');
		} }, '⏸ ' + _('Pause'));

		const page = sb.wrap([
			E('h2', _('Connections')),
			E('div', { 'class': 'cbi-map-descr' }, _('Live connections handled by sing-box, refreshed every 2 seconds.')),
			E('div', { 'class': 'sb-toolbar' }, [
				search, pause,
				E('button', {
					'class': 'btn cbi-button-negative',
					'click': ui.createHandlerFn(this, () => {
						if (confirm(_('Close all connections?')))
							return sb.callClash('close').then(() => this.refresh());
					})
				}, _('Close all'))
			]),
			this.summary,
			E('div', { 'class': 'sb-card', 'style': 'padding:0;overflow-x:auto;margin-top:8px' }, [
				E('table', { 'class': 'sb-table' }, [
					E('thead', [ E('tr', [ E('th', _('Destination')), E('th', _('Route')), E('th', { 'class': 'num' }, _('Traffic')), E('th', { 'class': 'num' }, _('Duration')), E('th') ]) ]),
					this.tbody
				])
			])
		]);
		this.draw(data);
		poll.add(() => this.refresh(), 2);
		return page;
	},

	handleSaveApply: null,
	handleSave: null,
	handleReset: null
});
