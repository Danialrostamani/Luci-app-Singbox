'use strict';
'require view';
'require ui';
'require uci';
'require singbox.common as sb';

return view.extend({
	delays: {},
	filter: '',
	sortBy: 'default',
	testing: {},

	load() {
		return Promise.all([
			sb.callStatus(),
			sb.callNodes(),
			uci.load('singbox')
		]).then(([ st, nodes ]) => {
			const prof = !!st.profile;
			let px;
			if (st.running)
				px = L.resolveDefault(sb.callClash(prof ? 'groups' : 'proxies'), null);
			else
				px = prof ? L.resolveDefault(sb.callProfileGroups(), null) : Promise.resolve(null);
			/* results of earlier tests made while the service was stopped */
			const saved = st.running ? Promise.resolve({ delays: {} }) : L.resolveDefault(sb.callTestResults(), { delays: {} });
			const speeds = L.resolveDefault(sb.callSpeedResults(), { results: {} });
			return Promise.all([ px, saved, speeds ]).then(([ p, t, sp ]) => { this.speeds = (sp && sp.results) || {}; return [ st, nodes, p, t ]; });
		});
	},

	/* ---------- latency tests while the service is stopped ---------- */

	/* arg: node tag or 'all'. Runs a temporary test instance on the router. */
	offlineTest(arg) {
		if (this.offlineBusy)
			return Promise.resolve();
		this.offlineBusy = true;
		if (arg == 'all')
			this.testingAll = true;
		else
			this.testing[arg] = true;
		this.redraw();
		const finish = () => {
			this.offlineBusy = false;
			this.testingAll = false;
			this.testingGroup = null;
			delete this.testing[arg];
			this.redraw();
		};
		return sb.callTask('node-test', arg).then((r) => {
			if (!r || !r.ok) {
				sb.error(r?.error || _('Could not start the latency test'));
				return;
			}
			const poll = () => new Promise((res) => window.setTimeout(res, 1000))
				.then(() => sb.callTaskStatus())
				.then((t) => {
					if (t && t.running)
						return poll();
					if (t && !t.ok)
						sb.error(_('Latency test failed: %s').format(t.message || '?'));
					else if (t?.result?.skipped?.length)
						ui.addTimeLimitedNotification(_('Some nodes could not be tested'), E('ul', t.result.skipped.slice(0, 8).map((x) => E('li', x))), 8000, 'warning');
					return sb.callTestResults().then((d) => { Object.assign(this.delays, d.delays || {}); });
				});
			return poll();
		}).finally(finish);
	},

	/* ---------- profile mode: groups from the running configuration ---------- */

	groupSelect(group, name) {
		if (!this.status.running)
			return Promise.resolve(sb.notify(_('Start the service to switch nodes inside a profile group.'), 'warning'));
		return sb.callClash('select', name, group).then((r) => {
			if (!r.ok)
				return sb.error(_('Could not switch node: %s').format(r.error || '?'));
			return this.reload();
		});
	},

	groupTest(group) {
		if (!this.status.running) {
			this.testingGroup = group;
			return this.offlineTest('all');
		}
		this.testingGroup = group;
		this.redraw();
		return sb.callClash('group_delay', group).then((r) => {
			if (!r.ok)
				sb.error(_('Latency test failed: %s').format(r.error || '?'));
			else
				Object.keys(r.delays || {}).forEach((k) => { this.delays[k] = r.delays[k]; });
		}).finally(() => {
			this.testingGroup = null;
			this.redraw();
		});
	},

	memberCard(g, name) {
		const types = this.px?.types || {};
		const t = String(types[name] || '').toLowerCase();
		const isGroup = (t == 'selector' || t == 'urltest');
		const sub = isGroup ? (this.px.groups.find((x) => x.name == name)?.now) : null;
		/* follow nested groups down to the node actually used */
		let leaf = name;
		for (let i = 0; i < 8; i++) {
			const gg = this.px.groups.find((x) => x.name == leaf);
			if (!gg || !gg.now)
				break;
			leaf = gg.now;
		}
		const d = this.delays[leaf];
		const selectable = String(g.type).toLowerCase() == 'selector';
		const sel = g.now == name;
		const testing = this.testingGroup == g.name || this.testingAll || this.testing[name];
		return E('div', {
			'class': 'sb-card sb-node' + (sel ? ' sel' : ''),
			'style': selectable ? null : 'cursor:default',
			'title': selectable ? _('Click to use this node') : _('Chosen automatically by latency'),
			'click': selectable ? ui.createHandlerFn(this, () => this.groupSelect(g.name, name)) : null
		}, [
			E('div', { 'class': 'sb-row', 'style': 'flex-wrap:nowrap' }, [
				E('span', { 'class': 'sb-name' }, (isGroup ? '⧉ ' : '') + name),
				testing ? sb.spinner() : E('span', { 'class': 'sb-delay ' + sb.delayClass(d) }, sb.delayText(d))
			]),
			E('div', { 'class': 'sb-meta' }, [
				E('span', { 'class': 'sb-tag' }, types[name] || '?'),
				sub ? E('span', { 'style': 'unicode-bidi:plaintext' }, ' → ' + sub) : ''
			])
		]);
	},

	redrawGroups(root) {
		const st = this.status;
		root.appendChild(E('div', { 'class': 'sb-alert info' }, [
			_('Profile “%s” is active — nodes and groups come from the profile.').format(st.profile), ' ',
			E('a', { 'href': L.url('admin/services/singbox/profiles') }, _('Manage profiles'))
		]));
		if (!this.px?.ok) {
			root.appendChild(E('div', { 'class': 'sb-empty' }, st.running ? _('Clash API not reachable') : (this.px?.error || _('The profile has no content yet.'))));
			return;
		}
		if (!st.running)
			root.appendChild(E('div', { 'class': 'sb-alert warn' }, _('The service is stopped: groups are shown from the profile file. Latency tests still work; switching nodes needs the service running.')));
		const q = this.filter.toLowerCase();
		const groups = (this.px.groups || []).slice().sort((a, b) => (a.name == this.px.main ? -1 : 0) - (b.name == this.px.main ? -1 : 0));
		groups.forEach((g) => {
			let members = (g.all || []).filter((n) => !q || n.toLowerCase().includes(q));
			if (this.sortBy == 'name')
				members = members.slice().sort((a, b) => a.localeCompare(b));
			else if (this.sortBy == 'delay') {
				const v = (n) => { const d = this.delays[n]; return d == null ? 1e9 - 1 : (d <= 0 ? 1e9 : d); };
				members = members.slice().sort((a, b) => v(a) - v(b));
			}
			const isSel = String(g.type).toLowerCase() == 'selector';
			root.appendChild(E('div', {}, [
				E('div', { 'class': 'sb-group-h' }, [
					E('h3', { 'style': 'unicode-bidi:plaintext' }, [
						g.name, ' ',
						E('span', { 'class': 'sb-badge muted' }, isSel ? _('Selector') : _('Auto (URL test)')), ' ',
						g.name == this.px.main ? E('span', { 'class': 'sb-badge' }, _('Main')) : '',
						E('span', { 'class': 'sb-sub' }, ' (%d)'.format((g.all || []).length))
					]),
					E('button', { 'class': 'btn cbi-button', 'click': ui.createHandlerFn(this, () => this.groupTest(g.name)) }, '⏱ ' + _('Test'))
				]),
				members.length ? E('div', { 'class': 'sb-grid' }, members.map((n) => this.memberCard(g, n))) : E('div', { 'class': 'sb-empty' }, _('No nodes match the filter.'))
			]));
		});
	},

	/* ---------- actions ---------- */

	select(tag) {
		const done = () => {
			this.selected = tag;
			this.redraw();
		};
		sb.callSetSelected(tag);
		if (!this.status.running) {
			sb.notify(_('“%s” will be used when the service starts.').format(tag == 'auto' ? _('Auto (best)') : tag));
			return Promise.resolve(done());
		}
		return sb.callClash('select', tag).then((r) => {
			if (!r.ok)
				return sb.error(_('Could not switch node: %s').format(r.error || '?'));
			done();
		});
	},

	testOne(tag) {
		if (!this.status.running)
			return this.offlineTest(tag);
		this.testing[tag] = true;
		this.redraw();
		return sb.callClash('delay', tag).then((r) => {
			this.delays[tag] = r.ok ? r.delay : 0;
		}).finally(() => {
			delete this.testing[tag];
			this.redraw();
		});
	},

	testProfileGroups() {
		if (!this.status.running)
			return this.offlineTest('all');
		if (!this.px)
			return Promise.resolve();
		const groups = (this.px.groups || []).map((g) => g.name);
		return groups.reduce((p, g) => p.then(() => this.groupTest(g)), Promise.resolve());
	},

	testAll() {
		if (!this.status.running)
			return this.offlineTest('all');
		this.testingAll = true;
		this.redraw();
		return sb.callClash('group_delay', 'auto').then((r) => {
			if (!r.ok) {
				sb.error(_('Latency test failed: %s').format(r.error || '?'));
				return;
			}
			const d = r.delays || {};
			this.nodes.forEach((n) => { if (n.tag) this.delays[n.tag] = d[n.tag] ?? 0; });
		}).finally(() => {
			this.testingAll = false;
			this.redraw();
		});
	},

	showDetail(tag) {
		return sb.callNodeDetail(tag).then((r) => {
			if (!r.ok)
				return sb.error(r.error);
			const text = JSON.stringify(r.outbound, null, 2);
			ui.showModal(_('Node: %s').format(tag), [
				E('pre', { 'class': 'sb-pre' }, text),
				E('div', { 'class': 'right' }, [
					E('button', { 'class': 'btn', 'click': () => sb.copyText(text) }, _('Copy JSON')), ' ',
					E('button', { 'class': 'btn cbi-button-action', 'click': ui.hideModal }, _('Close'))
				])
			]);
		});
	},

	applyChanges() {
		return uci.save().then(() => ui.changes.apply(true));
	},

	editManual(sid) {
		const name = E('input', { 'class': 'cbi-input-text', 'style': 'width:100%', 'value': uci.get('singbox', sid, 'name') || '' });
		const isJson = !!uci.get('singbox', sid, 'json');
		const body = E('textarea', { 'class': 'sb-modal-ta' }, [ isJson ? uci.get('singbox', sid, 'json') : (uci.get('singbox', sid, 'link') || '') ]);
		const enabled = E('input', { 'type': 'checkbox' });
		enabled.checked = uci.get('singbox', sid, 'enabled') != '0';
		const coreSel = sb.coreSelect(uci.get('singbox', sid, 'core'));
		ui.showModal(_('Edit node'), [
			E('p', _('Display name (optional, overrides the name in the link)')), name,
			E('p', { 'style': 'margin-top:10px' }, _('Share link (vless://, vmess://, ss://, trojan://, hy2://, tuic://, …) or a sing-box outbound JSON object')),
			body,
			E('p', { 'style': 'margin-top:10px' }, E('strong', _('Core'))), coreSel, sb.coreHint(),
			E('label', { 'style': 'display:block;margin-top:8px' }, [ enabled, ' ', _('Enabled') ]),
			E('div', { 'class': 'right' }, [
				E('button', { 'class': 'btn', 'click': ui.hideModal }, _('Cancel')), ' ',
				E('button', {
					'class': 'btn cbi-button-positive',
					'click': ui.createHandlerFn(this, () => {
						const txt = body.value.trim();
						return sb.callParse(txt, coreSel.value).then((r) => {
							if (!r.ok || r.nodes.length != 1)
								return sb.error(_('Input must contain exactly one valid node. %s').format((r.errors || []).join('; ')));
							uci.set('singbox', sid, 'name', name.value.trim() || null);
							uci.set('singbox', sid, 'enabled', enabled.checked ? null : '0');
							uci.set('singbox', sid, 'core', coreSel.value == 'auto' ? null : coreSel.value);
							if (r.nodes[0].link) {
								uci.set('singbox', sid, 'link', r.nodes[0].link);
								uci.unset('singbox', sid, 'json');
							}
							else {
								uci.set('singbox', sid, 'json', txt.startsWith('{') ? txt : r.nodes[0].json);
								uci.unset('singbox', sid, 'link');
							}
							ui.hideModal();
							return this.applyChanges();
						});
					})
				}, _('Save & Apply'))
			])
		]);
	},

	deleteManual(sid, tag) {
		if (!confirm(_('Delete node “%s”?').format(tag || sid)))
			return;
		uci.remove('singbox', sid);
		return this.applyChanges();
	},

	addNodes() {
		const ta = E('textarea', {
			'class': 'sb-modal-ta',
			'placeholder': 'vless://…\nvmess://…\nss://…\nhy2://…\n\n' + _('or a base64 subscription body, Clash YAML, sing-box JSON or a WireGuard .conf')
		});
		const preview = E('div', { 'style': 'margin-top:8px' });
		const coreSel = sb.coreSelect('auto');
		let parsed = null;
		coreSel.addEventListener('change', () => { if (parsed) { parsed = null; doParse(); } });

		const doParse = () => sb.callParse(ta.value, coreSel.value).then((r) => {
			parsed = r;
			preview.innerHTML = '';
			if (!r.nodes?.length) {
				preview.appendChild(E('div', { 'class': 'sb-alert bad' }, [ _('No valid nodes found.'), r.errors?.length ? E('ul', r.errors.slice(0, 10).map((e) => E('li', e))) : '' ]));
				return;
			}
			preview.appendChild(E('div', { 'class': 'sb-alert info' }, _('%d node(s) recognized (format: %s)').format(r.nodes.length, r.format)));
			preview.appendChild(E('table', { 'class': 'sb-table' }, r.nodes.slice(0, 50).map((n) =>
				E('tr', [ E('td', { 'style': 'unicode-bidi:plaintext' }, n.tag), E('td', n.type), E('td', { 'class': 'sb-ltr' }, '%s:%s'.format(n.server, n.port)) ]))));
			if (r.errors?.length)
				preview.appendChild(E('div', { 'class': 'sb-alert warn' }, [ _('Skipped:'), E('ul', r.errors.slice(0, 10).map((e) => E('li', e))) ]));
		});

		const file = E('input', { 'type': 'file', 'multiple': true, 'accept': '.conf,.txt,.json,.yaml,.yml', 'style': 'display:none' });
		file.addEventListener('change', () => {
			const files = Array.from(file.files || []);
			if (!files.length)
				return;
			Promise.all(files.map((f) => f.text())).then((texts) => {
				const cur = ta.value.trim();
				ta.value = (cur ? cur + '\n\n' : '') + texts.map((t) => t.trim()).join('\n\n');
				parsed = null;
				file.value = '';
				return doParse();
			});
		});

		ui.showModal(_('Add nodes'), [
			E('p', _('Paste one or more share links (one per line). Supported: VLESS (incl. Reality), VMess, Trojan, Shadowsocks (incl. 2022, obfs), Hysteria2, Hysteria, TUIC, AnyTLS, SOCKS, HTTP, WireGuard.')),
			E('p', { 'style': 'opacity:.75;font-size:90%' }, _('WireGuard: upload the .conf file from your provider or paste its [Interface] / [Peer] text. AmneziaWG files are not supported by sing-box.')),
			ta,
			E('div', { 'style': 'margin-top:6px' }, [
				file,
				E('button', { 'class': 'btn', 'click': (ev) => { ev.preventDefault(); file.click(); } }, '📄 ' + _('Upload file…'))
			]),
			E('div', { 'style': 'margin-top:10px' }, [ E('strong', _('Run with core:')), ' ', coreSel, sb.coreHint() ]),
			preview,
			E('div', { 'class': 'right', 'style': 'margin-top:10px' }, [
				E('button', { 'class': 'btn', 'click': ui.hideModal }, _('Cancel')), ' ',
				E('button', { 'class': 'btn cbi-button-action', 'click': ui.createHandlerFn(this, doParse) }, _('Check')), ' ',
				E('button', {
					'class': 'btn cbi-button-positive',
					'click': ui.createHandlerFn(this, () => (parsed ? Promise.resolve() : doParse()).then(() => {
						if (!parsed?.nodes?.length)
							return;
						parsed.nodes.forEach((n) => {
							const sid = uci.add('singbox', 'node');
							if (n.link) {
								uci.set('singbox', sid, 'link', n.link);
								if (coreSel.value != 'auto')
									uci.set('singbox', sid, 'core', coreSel.value);
							}
							else {
								uci.set('singbox', sid, 'json', n.json);
								uci.set('singbox', sid, 'name', n.tag);
							}
						});
						ui.hideModal();
						return this.applyChanges();
					}))
				}, _('Add & Apply'))
			])
		]);
		ta.addEventListener('input', () => { parsed = null; });
		ta.focus();
	},

	/* ---------- speed test ---------- */

	speedLine(tag) {
		const r = (this.speeds || {})[tag];
		if (!r)
			return '';
		if (r.error)
			return E('div', { 'class': 'sb-meta', 'style': 'color:var(--sb-bad)' }, _('Speed test failed: %s').format(r.error));
		return E('div', { 'class': 'sb-meta sb-ltr', 'title': _('Measured %s').format(sb.fmtAgo(r.time)) }, [
			E('strong', {}, '↓ %.1f'.format(r.down_mbps)), r.up_mbps ? '  ↑ %.1f'.format(r.up_mbps) : '', ' Mbps'
		]);
	},

	speedTest(tag) {
		return sb.runTask('speed-test', tag, _('Testing the speed of “%s”…').format(tag)).then(() =>
			L.resolveDefault(sb.callSpeedResults(), { results: {} }).then((sp) => {
				this.speeds = (sp && sp.results) || {};
				this.redraw();
			}));
	},

	/* ---------- rendering ---------- */

	nodeCard(n) {
		const sel = this.selected == n.tag;
		const d = this.delays[n.tag];
		const testing = this.testing[n.tag] || this.testingAll;
		if (n.error)
			return E('div', { 'class': 'sb-card sb-node err' }, [
				E('div', { 'class': 'sb-row' }, [ E('span', { 'class': 'sb-name' }, n.name || _('(invalid node)')), E('span', { 'class': 'sb-tag' }, _('error')) ]),
				E('div', { 'class': 'sb-meta' }, n.error),
				n.source == 'manual' ? E('div', { 'class': 'sb-actions' }, [
					E('button', { 'class': 'btn cbi-button', 'click': (ev) => { ev.stopPropagation(); this.editManual(n.source_id); } }, _('Edit')),
					E('button', { 'class': 'btn cbi-button-negative', 'click': (ev) => { ev.stopPropagation(); this.deleteManual(n.source_id, n.name); } }, _('Delete'))
				]) : ''
			]);

		const actions = [
			E('button', { 'class': 'btn cbi-button', 'title': _('Test latency'), 'click': (ev) => { ev.stopPropagation(); this.testOne(n.tag); } }, _('Test')),
			E('button', { 'class': 'btn cbi-button', 'title': _('Download / upload speed through this node (about 20 seconds)'), 'click': (ev) => { ev.stopPropagation(); this.speedTest(n.tag); } }, _('Speed')),
			E('button', { 'class': 'btn cbi-button', 'click': (ev) => { ev.stopPropagation(); this.showDetail(n.tag); } }, _('Details'))
		];
		if (n.source == 'manual') {
			actions.push(E('button', { 'class': 'btn cbi-button', 'click': (ev) => { ev.stopPropagation(); this.editManual(n.source_id); } }, _('Edit')));
			actions.push(E('button', { 'class': 'btn cbi-button-negative', 'click': (ev) => { ev.stopPropagation(); this.deleteManual(n.source_id, n.tag); } }, _('Delete')));
		}
		return E('div', {
			'class': 'sb-card sb-node' + (sel ? ' sel' : ''),
			'title': _('Click to use this node'),
			'click': () => this.select(n.tag)
		}, [
			E('div', { 'class': 'sb-row', 'style': 'flex-wrap:nowrap' }, [
				E('span', { 'class': 'sb-name' }, n.tag),
				testing ? sb.spinner() : E('span', { 'class': 'sb-delay ' + sb.delayClass(d) }, sb.delayText(d))
			]),
			E('div', { 'class': 'sb-meta' }, [ E('span', { 'class': 'sb-tag' }, sb.typeLabel(n)), ' ', E('span', { 'class': 'sb-ltr' }, '%s:%s'.format(n.server ?? '?', n.port ?? '?')) ]),
			this.speedLine(n.tag),
			E('div', { 'class': 'sb-actions' }, actions)
		]);
	},

	autoCard() {
		const sel = this.selected == 'auto' || !this.selected;
		const best = this.px?.auto;
		return E('div', { 'class': 'sb-card sb-node' + (sel ? ' sel' : ''), 'click': () => this.select('auto') }, [
			E('div', { 'class': 'sb-row', 'style': 'flex-wrap:nowrap' }, [
				E('span', { 'class': 'sb-name' }, '⚡ ' + _('Auto (best)')),
				best ? E('span', { 'class': 'sb-delay ' + sb.delayClass(this.delays[best]) }, sb.delayText(this.delays[best])) : ''
			]),
			E('div', { 'class': 'sb-meta', 'style': 'unicode-bidi:plaintext' }, best ? '→ ' + best : _('Picks the fastest node automatically'))
		]);
	},

	sorted(list) {
		const q = this.filter.toLowerCase();
		let out = list.filter((n) => !q || (n.tag || n.name || '').toLowerCase().includes(q) || (n.server || '').toLowerCase().includes(q) || (n.type || '').includes(q));
		if (this.sortBy == 'name')
			out = out.slice().sort((a, b) => (a.tag || '').localeCompare(b.tag || ''));
		else if (this.sortBy == 'delay') {
			const v = (n) => { const d = this.delays[n.tag]; return d == null ? 1e9 - 1 : (d <= 0 ? 1e9 : d); };
			out = out.slice().sort((a, b) => v(a) - v(b));
		}
		return out;
	},

	group(title, list, extra) {
		const cards = this.sorted(list).map((n) => this.nodeCard(n));
		return E('div', {}, [
			E('div', { 'class': 'sb-group-h' }, [ E('h3', { 'style': 'unicode-bidi:plaintext' }, [ title, ' ', E('span', { 'class': 'sb-sub' }, '(%d)'.format(list.length)) ]), extra || '' ]),
			cards.length ? E('div', { 'class': 'sb-grid' }, cards) : E('div', { 'class': 'sb-empty' }, _('No nodes match the filter.'))
		]);
	},

	redraw() {
		const root = this.root;
		while (root.firstChild)
			root.removeChild(root.firstChild);

		if (this.status.profile) {
			this.redrawGroups(root);
			return;
		}

		const manual = this.nodes.filter((n) => n.source == 'manual');
		const bySub = {};
		this.nodes.filter((n) => n.source == 'sub').forEach((n) => { (bySub[n.source_id] = bySub[n.source_id] || []).push(n); });

		const parts = [];
		if (!this.status.running)
			parts.push(E('div', { 'class': 'sb-alert warn' }, _('The service is stopped. You can still pick a default node and test latency (a temporary test instance runs on the router).')));

		if (!this.nodes.length) {
			parts.push(E('div', { 'class': 'sb-empty' }, [
				E('p', _('No nodes yet.')),
				E('p', _('Add a subscription or paste share links to get started.')),
				E('div', { 'class': 'sb-row', 'style': 'justify-content:center' }, [
					E('button', { 'class': 'btn cbi-button-action', 'click': () => this.addNodes() }, _('Add nodes')),
					E('a', { 'class': 'btn cbi-button', 'href': L.url('admin/services/singbox/profiles') }, _('Profiles & subscriptions'))
				])
			]));
		}
		else {
			parts.push(E('div', { 'class': 'sb-grid' }, [ this.autoCard() ]));
			if (manual.length)
				parts.push(this.group(_('Manual nodes'), manual));
			(this.subs || []).forEach((s) => {
				const list = bySub[s.id] || [];
				if (!list.length && !s.enabled)
					return;
				const upd = E('button', { 'class': 'btn cbi-button', 'click': ui.createHandlerFn(this, () => sb.runTask('sub-update', s.id, _('Updating subscription…')).then(() => this.reload())) }, _('Update'));
				parts.push(this.group(s.name + (s.enabled ? '' : ' (' + _('disabled') + ')'), list, upd));
			});
		}
		parts.forEach((p) => root.appendChild(p));
	},

	reload() {
		return this.load().then((d) => this.setData(d)).then(() => this.redraw());
	},

	setData([ st, nodes, px, saved ]) {
		this.status = st;
		this.nodes = nodes.nodes || [];
		this.subs = nodes.subs || [];
		this.px = px && px.ok ? px : null;
		this.selected = (this.px && !st.profile) ? this.px.selected : (nodes.selected || 'auto');
		if (this.px)
			Object.assign(this.delays, this.px.delays || {});
		if (saved)
			Object.assign(this.delays, saved.delays || {});
	},

	render(data) {
		this.setData(data);
		this.root = E('div');

		const search = E('input', { 'type': 'search', 'class': 'cbi-input-text', 'placeholder': _('Search nodes…') });
		search.addEventListener('input', () => { this.filter = search.value; this.redraw(); });

		const sort = E('select', { 'class': 'cbi-input-select', 'change': (ev) => { this.sortBy = ev.target.value; this.redraw(); } }, [
			E('option', { 'value': 'default' }, _('Original order')),
			E('option', { 'value': 'name' }, _('Sort by name')),
			E('option', { 'value': 'delay' }, _('Sort by latency'))
		]);

		const toolbar = E('div', { 'class': 'sb-toolbar' }, [
			search, sort,
			E('button', { 'class': 'btn cbi-button-action', 'click': ui.createHandlerFn(this, () => this.status.profile ? this.testProfileGroups() : this.testAll()) }, '⏱ ' + _('Test all')),
			this.status.profile ? '' : E('button', { 'class': 'btn cbi-button-positive', 'click': () => this.addNodes() }, '+ ' + _('Add nodes')),
			this.status.profile ? '' : E('button', { 'class': 'btn cbi-button', 'click': ui.createHandlerFn(this, () => sb.runTask('sub-update', 'all', _('Updating subscriptions…')).then(() => this.reload())) }, '⟳ ' + _('Update subscriptions'))
		]);

		this.redraw();
		return sb.wrap([
			E('h2', _('Nodes')),
			E('div', { 'class': 'cbi-map-descr' }, this.status.profile
				? _('Tap a node inside a selector group to use it. Changes take effect immediately without restarting.')
				: _('Tap a node to use it. “Auto” always picks the fastest node. Changes take effect immediately without restarting.')),
			this.status.profile ? E('div', { 'class': 'sb-alert info' }, [
				_('A profile is active, so the nodes come from that profile and “Add nodes” is hidden. To add share links or a WireGuard .conf file: Profiles → Add profile → Local → Upload file… (or paste the text), or deactivate the profile to use the built-in node list.'), ' ',
				E('a', { 'href': L.url('admin/services/singbox/profiles') }, _('Open Profiles') + ' →')
			]) : '',
			toolbar,
			this.root
		]);
	},

	handleSaveApply: null,
	handleSave: null,
	handleReset: null
});
