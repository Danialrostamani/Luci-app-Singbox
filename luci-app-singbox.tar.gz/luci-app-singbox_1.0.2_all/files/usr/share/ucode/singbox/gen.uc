// SPDX-License-Identifier: LicenseRef-Proprietary
// Copyright (C) 2026 Danial Rostamani. All rights reserved. See LICENSE.
// luci-app-singbox - sing-box configuration + nftables generator
//
// build(conf, ctx) is pure: it only uses the passed UCI data and runtime
// context, so it can be unit-tested off-device.

import * as u from 'singbox.util';
import * as xray from 'singbox.xray';

export const GITHUB_RAW = 'https://raw.githubusercontent.com/';

export const IRAN_RULES = 'https://raw.githubusercontent.com/Danialrostamani/sing-box-iran-rules/release/';
export const GEOSITE_BASE = 'https://raw.githubusercontent.com/SagerNet/sing-geosite/rule-set/geosite-';
export const GEOIP_BASE = 'https://raw.githubusercontent.com/SagerNet/sing-geoip/rule-set/geoip-';
export const DASHBOARD_URL = 'https://github.com/Zephyruso/zashboard/releases/latest/download/dist.zip';

const PRIVATE4 = [
	'0.0.0.0/8', '10.0.0.0/8', '100.64.0.0/10', '127.0.0.0/8', '169.254.0.0/16',
	'172.16.0.0/12', '192.0.0.0/24', '192.168.0.0/16', '224.0.0.0/4', '240.0.0.0/4'
];
const PRIVATE6 = [ '::/128', '::1/128', '::ffff:0:0/96', '64:ff9b::/96', 'fc00::/7', 'fe80::/10', 'ff00::/8' ];

const DOMAIN_TYPES = {
	domain: true, domain_suffix: true, domain_keyword: true, domain_regex: true
};

// ---------------------------------------------------------------------------
// Rule-set catalogue
// ---------------------------------------------------------------------------

function rs_entry(tag, url, kind, format) {
	return {
		tag: tag,
		url: url,
		kind: kind,			// 'domain' | 'ip' | 'mixed'
		format: format ?? 'binary',
		file: u.RS_DIR + '/' + tag + (format == 'source' ? '.json' : '.srs')
	};
}

function sanitize_tag(s) {
	return replace(lc(trim('' + s)), /[^a-z0-9@!._-]+/g, '-');
}

// Every rule-set the current configuration needs, keyed by tag.
export function required_rulesets(conf) {
	let out = {};
	let route = conf.route ?? {};
	if (u.bool(route.block_ads, true)) {
		out['ads-merged-domains'] = rs_entry('ads-merged-domains', IRAN_RULES + 'ads-merged-domains.srs', 'domain');
		out['ads-merged-ips'] = rs_entry('ads-merged-ips', IRAN_RULES + 'ads-merged-ips.srs', 'ip');
	}
	if (u.bool(route.iran_direct, true)) {
		out['iran-all-domains'] = rs_entry('iran-all-domains', IRAN_RULES + 'iran-all-domains.srs', 'domain');
		out['iran-all-ips'] = rs_entry('iran-all-ips', IRAN_RULES + 'iran-all-ips.srs', 'ip');
	}
	let user = conf.rulesets ?? [];
	for (let i = 0; i < length(user); i++) {
		let r = user[i];
		if (!u.bool(r.enabled, true) || !r.name || !r.url)
			continue;
		let tag = sanitize_tag(r.name);
		out[tag] = rs_entry(tag, r.url, r.kind ?? 'mixed', r.format == 'source' ? 'source' : 'binary');
	}
	let rules = conf.rules ?? [];
	for (let i = 0; i < length(rules); i++) {
		let r = rules[i];
		if (!u.bool(r.enabled, true))
			continue;
		let vals = u.flatlist(r.value);
		for (let j = 0; j < length(vals); j++) {
			let v = sanitize_tag(vals[j]);
			if (r.type == 'geosite')
				out['geosite-' + v] = rs_entry('geosite-' + v, GEOSITE_BASE + v + '.srs', 'domain');
			else if (r.type == 'geoip')
				out['geoip-' + v] = rs_entry('geoip-' + v, GEOIP_BASE + v + '.srs', 'ip');
		}
	}
	return out;
};

// ---------------------------------------------------------------------------
// DNS helpers
// ---------------------------------------------------------------------------

// Parse "https://1.1.1.1/dns-query", "tls://dns.google", "udp://8.8.8.8:53",
// "8.8.8.8", "quic://dns.adguard.com", "h3://...", "tcp://..." into a new-format
// DNS server object (sing-box >= 1.12).
export function parse_dns(url, tag) {
	url = trim('' + (url ?? ''));
	if (url == '')
		return null;
	if (url == 'local')
		return { type: 'local', tag: tag };

	let scheme = 'udp', rest = url;
	let m = match(url, /^([a-z0-9]+):\/\/(.*)$/);
	if (m) {
		scheme = m[1];
		rest = m[2];
	}
	let path = null;
	let sl = index(rest, '/');
	if (sl >= 0) {
		path = substr(rest, sl);
		rest = substr(rest, 0, sl);
	}
	let host = rest, port = null;
	let m6 = match(rest, /^\[([0-9A-Fa-f:.]+)\](:([0-9]+))?$/);
	if (m6) {
		host = m6[1];
		port = m6[3] != null ? int(m6[3]) : null;
	}
	else if (!u.is_ipv6(rest)) {
		let c = rindex(rest, ':');
		if (c > 0 && match(substr(rest, c + 1), /^[0-9]+$/)) {
			host = substr(rest, 0, c);
			port = int(substr(rest, c + 1));
		}
	}

	let types = { udp: 'udp', tcp: 'tcp', tls: 'tls', dot: 'tls', https: 'https', doh: 'https', quic: 'quic', doq: 'quic', h3: 'h3', http3: 'h3' };
	let t = types[scheme];
	if (!t || host == '')
		return null;
	let s = { type: t, tag: tag, server: host };
	if (port != null && u.valid_port(port))
		s.server_port = port;
	if ((t == 'https' || t == 'h3') && path != null && path != '/dns-query')
		s.path = path;
	return s;
};

// ---------------------------------------------------------------------------
// Performance: bandwidth limits and multiplex of nodes
// ---------------------------------------------------------------------------
//
// bandwidth_mode:
//   keep   - use what the link / profile says (default)
//   bbr    - remove Hysteria2 / TCP Brutal limits so the BBR congestion
//            control finds the real speed (Hysteria v1 has no BBR and keeps
//            its values)
//   custom - force the given up / down Mbps on Hysteria, Hysteria2 and Brutal
// mux_mode: keep | off (disable multiplex from links / profiles)

function brutal_fix(mp, mode, up, down) {
	if (type(mp) != 'object' || type(mp.brutal) != 'object')
		return;
	if (mode == 'bbr')
		delete mp.brutal;
	else if (mode == 'custom' && up > 0 && down > 0) {
		mp.brutal.up_mbps = up;
		mp.brutal.down_mbps = down;
	}
}

// Returns a (modified) copy of the outbound / endpoint.
export function apply_performance(o, main) {
	let mode = main?.bandwidth_mode ?? 'bbr';
	let mux = main?.mux_mode ?? 'keep';
	if (type(o) != 'object' || (mode == 'keep' && mux == 'keep'))
		return o;
	o = u.clone(o);
	let up = u.toint(main?.bandwidth_up, 0), down = u.toint(main?.bandwidth_down, 0);

	if (o.type == 'hysteria2') {
		if (mode == 'bbr') {
			delete o.up_mbps;
			delete o.down_mbps;
		}
		else if (mode == 'custom' && up > 0 && down > 0) {
			o.up_mbps = up;
			o.down_mbps = down;
		}
	}
	else if (o.type == 'hysteria' && mode == 'custom' && up > 0 && down > 0) {
		o.up_mbps = up;
		o.down_mbps = down;
	}

	if (mux == 'off' && type(o.multiplex) == 'object')
		delete o.multiplex;
	else
		brutal_fix(o.multiplex, mode, up, down);
	return o;
};

// ---------------------------------------------------------------------------
// Router integration pieces shared by the built-in config and profiles
// ---------------------------------------------------------------------------

// Inbounds that connect sing-box to the router (proxy port, dnsmasq upstream,
// TPROXY / TUN) plus the route options each mode needs.
export function router_inbounds(conf, ver) {
	let main = conf.main ?? {};
	let mode = u.inbound_mode(main);
	let ipv6 = u.bool(main.ipv6, false);
	let inbounds = [
		{
			type: 'mixed',
			tag: 'mixed-in',
			listen: u.bool(main.mixed_allow_lan, false) ? '::' : '127.0.0.1',
			listen_port: u.toint(main.mixed_port, 2080)
		},
		{
			type: 'direct',
			tag: 'dns-in',
			listen: '127.0.0.1',
			listen_port: u.toint(main.dns_port, 1053)
		}
	];
	let route = {};
	let transparent = null;

	if (mode == 'tproxy') {
		push(inbounds, {
			type: 'tproxy',
			tag: 'tproxy-in',
			listen: '::',
			listen_port: u.toint(main.tproxy_port, 7895)
		});
		route.default_mark = u.OUT_MARK;
		transparent = 'tproxy-in';
	}
	else if (mode == 'tun') {
		let addr = [ '172.19.0.1/30' ];
		if (ipv6)
			push(addr, 'fdfe:dcba:9876::1/126');
		let tun = {
			type: 'tun',
			tag: 'tun-in',
			interface_name: u.TUN_NAME,
			address: addr,
			mtu: u.toint(main.tun_mtu, 9000),
			auto_route: true,
			auto_redirect: true,
			strict_route: u.bool(main.tun_strict, false),
			route_exclude_address: ipv6 ? [ ...PRIVATE4, ...PRIVATE6 ] : u.clone(PRIVATE4)
		};
		let stack = main.tun_stack ?? u.DEFAULT_TUN_STACK;
		// gvisor-based stacks need a core built with_gvisor (not the "tiny" package)
		if ((stack == 'mixed' || stack == 'gvisor') && ver && length(ver.tags ?? []) && index(ver.tags, 'with_gvisor') < 0)
			stack = 'system';
		if (stack != '' && !u.ver_ge(ver, 1, 15))
			tun.stack = stack;
		// full-cone UDP (NAT type "Open" / endpoint-independent) for games,
		// calls and P2P: replies from any remote address reach the device
		if ((stack == 'mixed' || stack == 'gvisor') && !u.ver_ge(ver, 1, 15))
			tun.endpoint_independent_nat = true;
		push(inbounds, tun);
		route.auto_detect_interface = true;
		transparent = 'tun-in';
	}
	return { inbounds: inbounds, route: route, transparent: transparent };
};

export function clash_api(main) {
	let api = {
		external_controller: (u.bool(main.api_allow_lan, false) ? '0.0.0.0' : '127.0.0.1') + ':' + u.toint(main.api_port, 9090),
		default_mode: (main.proxy_mode == 'global') ? 'Global' : (main.proxy_mode == 'direct' ? 'Direct' : 'Rule')
	};
	if (main.api_secret != null && main.api_secret != '')
		api.secret = main.api_secret;
	if (u.bool(main.dashboard, false)) {
		api.external_ui = 'ui';
		api.external_ui_download_url = main.dashboard_url ?? DASHBOARD_URL;
		api.external_ui_download_detour = 'proxy';
	}
	return api;
};

// ---------------------------------------------------------------------------
// Main builder
// ---------------------------------------------------------------------------
//
// ctx = {
//   ver:        parsed sing-box version (util.core_version) or null
//   nodes:      [ { outbound, endpoint, source } ] with unique tags
//   resolv:     [ upstream DNS IPs from the WAN ]
//   lan_devs:   [ l3 device names of proxied LAN interfaces ]
//   rulesets:   { tag: true } for rule-set files present on disk
// }

export function build(conf, ctx) {
	let main = conf.main ?? {};
	let dnsc = conf.dns ?? {};
	let route = conf.route ?? {};
	let ver = ctx.ver;
	let warnings = [];

	let mode = u.inbound_mode(main);
	let ipv6 = u.bool(main.ipv6, false);
	let allow_lan = u.bool(main.mixed_allow_lan, false);
	let mixed_port = u.toint(main.mixed_port, 2080);
	let tproxy_port = u.toint(main.tproxy_port, 7895);
	let dns_port = u.toint(main.dns_port, 1053);
	let api_port = u.toint(main.api_port, 9090);
	let fakeip = u.bool(dnsc.fakeip, false);
	let sniff = u.bool(main.sniff, true);

	// ---- nodes -------------------------------------------------------------
	let outbounds = [ { type: 'direct', tag: 'direct' } ];
	let endpoints = [];
	let node_tags = [];
	let has_tag = { direct: true, proxy: true, auto: true };

	let nodes = ctx.nodes ?? [];
	let xray_nodes = [];
	for (let i = 0; i < length(nodes); i++) {
		let n = nodes[i];
		let o = n.outbound;
		if (!o || !o.tag || has_tag[o.tag])
			continue;
		has_tag[o.tag] = true;
		push(node_tags, o.tag);
		if (o.type == 'xray') {
			// run by the Xray sidecar, reached through a local SOCKS port
			let port = u.XRAY_PORT_BASE + length(xray_nodes);
			push(xray_nodes, { outbound: o, port: port });
			push(outbounds, xray.socks_outbound(o.tag, port));
			continue;
		}
		o = apply_performance(o, main);
		if (n.endpoint)
			push(endpoints, o);
		else
			push(outbounds, o);
	}

	let proxy_members = [];
	if (length(node_tags)) {
		push(proxy_members, 'auto');
		for (let i = 0; i < length(node_tags); i++)
			push(proxy_members, node_tags[i]);
	}
	else {
		push(proxy_members, 'direct');
		push(warnings, 'no proxy nodes configured: "proxy" falls back to direct');
	}

	let selector = {
		type: 'selector',
		tag: 'proxy',
		outbounds: proxy_members,
		interrupt_exist_connections: true
	};
	let sel = main.selected;
	if (sel != null && sel != '' && index(proxy_members, sel) >= 0)
		selector.default = sel;
	push(outbounds, selector);

	if (length(node_tags)) {
		let ut = {
			type: 'urltest',
			tag: 'auto',
			outbounds: u.clone(node_tags),
			url: main.urltest_url ?? 'https://www.gstatic.com/generate_204',
			tolerance: u.toint(main.urltest_tolerance, 50),
			interrupt_exist_connections: false
		};
		u.apply_test_interval(ut, main);
		push(outbounds, ut);
	}

	// ---- rule-sets ---------------------------------------------------------
	let wanted = required_rulesets(conf);
	let rule_sets = [];
	let rs_ok = {};
	for (let tag in wanted) {
		let e = wanted[tag];
		if (!ctx.rulesets?.[tag]) {
			push(warnings, 'rule-set "' + tag + '" not downloaded yet; related rules are skipped');
			continue;
		}
		rs_ok[tag] = e;
		push(rule_sets, { tag: tag, type: 'local', format: e.format, path: e.file });
	}
	function have(tags) {
		return filter(tags, (t) => rs_ok[t] != null);
	}

	// ---- DNS ---------------------------------------------------------------
	let dns_servers = [];
	let remote = parse_dns(dnsc.remote ?? u.DEFAULT_REMOTE_DNS, 'dns-remote');
	if (!remote || remote.type == 'local') {
		push(warnings, 'invalid remote DNS, using ' + u.DEFAULT_REMOTE_DNS);
		remote = parse_dns(u.DEFAULT_REMOTE_DNS, 'dns-remote');
	}
	remote.detour = 'proxy';

	let direct_url = dnsc.direct ?? u.DEFAULT_DIRECT_DNS;
	let direct;
	if (direct_url == 'auto' || direct_url == '') {
		let up = filter(ctx.resolv ?? [], (ip) => u.is_ip(ip) && substr(ip, 0, 4) != '127.' && ip != '::1');
		direct = parse_dns(length(up) ? up[0] : '1.1.1.1', 'dns-direct');
	}
	else
		direct = parse_dns(direct_url, 'dns-direct');
	if (!direct) {
		push(warnings, 'invalid direct DNS, using 1.1.1.1');
		direct = parse_dns('1.1.1.1', 'dns-direct');
	}
	if (direct.type == 'local' && u.bool(dnsc.dnsmasq_redirect, true)) {
		// While dnsmasq forwards to sing-box, the system resolver
		// (/etc/resolv.conf -> dnsmasq) would loop back into sing-box, so
		// "local" means the system's upstream (WAN) resolvers here.
		let up = filter(ctx.resolv ?? [], (ip) => u.is_ip(ip) && substr(ip, 0, 4) != '127.' && ip != '::1');
		if (length(up))
			direct = parse_dns(up[0], 'dns-direct');
		else {
			direct = parse_dns('1.1.1.1', 'dns-direct');
			push(warnings, 'direct DNS "local": no WAN DNS servers found, using 1.1.1.1');
		}
	}

	let need_bootstrap = (direct.server != null && !u.is_ip(direct.server));
	if (need_bootstrap) {
		let up = filter(ctx.resolv ?? [], (ip) => u.is_ip(ip) && substr(ip, 0, 4) != '127.');
		push(dns_servers, { type: 'udp', tag: 'dns-bootstrap', server: length(up) ? up[0] : '1.1.1.1' });
		direct.domain_resolver = 'dns-bootstrap';
	}
	if (remote.server != null && !u.is_ip(remote.server))
		remote.domain_resolver = 'dns-direct';

	push(dns_servers, remote);
	push(dns_servers, direct);

	if (fakeip) {
		let f = { type: 'fakeip', tag: 'dns-fake', inet4_range: '198.18.0.0/15' };
		if (ipv6)
			f.inet6_range = 'fc00::/18';
		push(dns_servers, f);
	}

	// Static hosts (UCI "host" sections)
	let hosts = {};
	let nhosts = 0;
	for (let i = 0; i < length(conf.hosts ?? []); i++) {
		let h = conf.hosts[i];
		if (!u.bool(h.enabled, true) || !h.domain)
			continue;
		let ips = filter(u.flatlist(h.ip), (x) => u.is_ip(x));
		if (!length(ips))
			continue;
		hosts[lc(h.domain)] = ips;
		nhosts++;
	}
	if (nhosts)
		unshift(dns_servers, { type: 'hosts', tag: 'dns-hosts', predefined: hosts });

	let dns_rules = [];
	if (nhosts)
		push(dns_rules, { domain: keys(hosts), server: 'dns-hosts' });
	push(dns_rules, { clash_mode: 'Direct', server: 'dns-direct' });
	push(dns_rules, { clash_mode: 'Global', server: 'dns-remote' });
	push(dns_rules, { domain_suffix: [ 'lan', 'local', 'localdomain', 'home.arpa', 'in-addr.arpa', 'ip6.arpa' ], server: 'dns-direct' });

	// ---- route rules -------------------------------------------------------
	let rules = [];
	if (sniff)
		push(rules, { action: 'sniff' });
	push(rules, { inbound: [ 'dns-in' ], action: 'hijack-dns' });
	push(rules, { protocol: 'dns', action: 'hijack-dns' });
	if (length(xray_nodes) && u.inbound_mode(main) == 'tun')
		// safety net: the sidecar's own connections to its servers never loop
		// back into a proxy (it also binds to the WAN device and carries the
		// sing-box output mark)
		push(rules, { process_name: [ 'xray' ], outbound: 'direct' });
	push(rules, { ip_is_private: true, outbound: 'direct' });
	push(rules, { clash_mode: 'Direct', outbound: 'direct' });
	push(rules, { clash_mode: 'Global', outbound: 'proxy' });

	// custom user rules (evaluated before built-in policy)
	let crules = conf.rules ?? [];
	for (let i = 0; i < length(crules); i++) {
		let r = crules[i];
		if (!u.bool(r.enabled, true))
			continue;
		let label = r.name ?? r.id ?? ('rule #' + (i + 1));
		let vals = u.flatlist(r.value);
		let t = r.type ?? 'domain_suffix';
		let m = {};
		let dns_ok = false;

		if (!length(vals) && t != 'network') {
			push(warnings, label + ': no values, skipped');
			continue;
		}
		switch (t) {
		case 'domain':
		case 'domain_suffix':
		case 'domain_keyword':
		case 'domain_regex':
			m[t] = vals;
			dns_ok = true;
			break;
		case 'ip_cidr':
		case 'source_ip_cidr':
			m[t] = filter(vals, (v) => u.is_cidr(v));
			if (length(m[t]) != length(vals))
				push(warnings, label + ': invalid CIDR values dropped');
			if (!length(m[t]))
				continue;
			break;
		case 'port':
		case 'source_port':
			m[t] = filter(map(vals, (v) => int(v)), (v) => u.valid_port(v));
			if (!length(m[t]))
				continue;
			break;
		case 'port_range':
			m.port_range = filter(map(vals, (v) => replace(v, '-', ':')), (v) => !!match(v, /^[0-9]*:[0-9]*$/));
			if (!length(m.port_range))
				continue;
			break;
		case 'protocol':
			m.protocol = vals;
			break;
		case 'network':
			m.network = vals[0] ?? 'tcp';
			break;
		case 'source_mac':
			if (!u.ver_ge(ver, 1, 14)) {
				push(warnings, label + ': MAC matching needs sing-box >= 1.14, use access control instead');
				continue;
			}
			m.source_mac_address = map(filter(vals, (v) => u.is_mac(v)), (v) => lc(v));
			break;
		case 'geosite':
		case 'geoip':
		case 'rule_set': {
			let tags = map(vals, (v) => (t == 'rule_set' ? '' : t + '-') + sanitize_tag(v));
			let ok = have(tags);
			if (!length(ok)) {
				push(warnings, label + ': rule-set not available yet, skipped');
				continue;
			}
			m.rule_set = ok;
			dns_ok = (t == 'geosite') || length(filter(ok, (x) => rs_ok[x].kind == 'domain')) == length(ok);
			break;
		}
		default:
			push(warnings, label + ': unknown rule type "' + t + '"');
			continue;
		}

		if (r.network != null && r.network != '' && t != 'network')
			m.network = r.network;

		let target = r.outbound ?? 'proxy';
		let rr = u.clone(m);
		if (target == 'block')
			rr.action = 'reject';
		else if (target == 'direct' || target == 'proxy' || target == 'auto' || has_tag[target])
			rr.outbound = target;
		else {
			push(warnings, label + ': outbound "' + target + '" not found, using proxy');
			rr.outbound = 'proxy';
		}
		push(rules, rr);

		// Matching DNS policy so names resolve via the right path
		if (dns_ok && !m.network && !m.port && !m.source_ip_cidr && !m.source_port && !m.port_range) {
			let dr = u.clone(m);
			if (target == 'block') {
				dr.action = 'predefined';
				dr.rcode = 'NXDOMAIN';
			}
			else if (target == 'direct')
				dr.server = 'dns-direct';
			else
				dr.server = 'dns-remote';
			if (target != 'proxy' && target != 'auto' && target != 'block' && target != 'direct')
				dr.server = 'dns-remote';
			push(dns_rules, dr);
		}
	}

	// ads / malware block
	if (u.bool(route.block_ads, true)) {
		let s = have([ 'ads-merged-domains', 'ads-merged-ips' ]);
		if (length(s))
			push(rules, { rule_set: s, action: 'reject' });
		if (rs_ok['ads-merged-domains'])
			push(dns_rules, { rule_set: [ 'ads-merged-domains' ], action: 'predefined', rcode: 'NXDOMAIN' });
	}

	// Iran direct
	if (u.bool(route.iran_direct, true)) {
		push(rules, { domain_suffix: [ 'ir' ], outbound: 'direct' });
		push(dns_rules, { domain_suffix: [ 'ir' ], server: 'dns-direct' });
		let s = have([ 'iran-all-domains', 'iran-all-ips' ]);
		if (length(s))
			push(rules, { rule_set: s, outbound: 'direct' });
		if (rs_ok['iran-all-domains'])
			push(dns_rules, { rule_set: [ 'iran-all-domains' ], server: 'dns-direct' });
	}

	// QUIC through the proxy is often throttled; block it so apps fall back to TCP
	if (u.bool(route.block_quic, false))
		push(rules, { network: 'udp', port: 443, action: 'reject' });

	if (fakeip) {
		let fr = { query_type: [ 'A' ], server: 'dns-fake' };
		if (ipv6)
			fr.query_type = [ 'A', 'AAAA' ];
		push(dns_rules, fr);
	}

	let final_out = route.final ?? 'proxy';
	if (final_out != 'direct' && final_out != 'proxy' && final_out != 'auto' && !has_tag[final_out])
		final_out = 'proxy';

	// ---- inbounds ----------------------------------------------------------
	let ri = router_inbounds(conf, ver);
	let inbounds = ri.inbounds;

	let route_obj = {
		rules: rules,
		rule_set: rule_sets,
		final: final_out,
		default_domain_resolver: 'dns-direct'
	};
	for (let k in ri.route)
		route_obj[k] = ri.route[k];

	// ---- assemble ----------------------------------------------------------
	let cfg = {
		log: u.log_options(main),
		dns: {
			servers: dns_servers,
			rules: dns_rules,
			final: 'dns-remote',
			strategy: (dnsc.strategy != null && dnsc.strategy != '') ? dnsc.strategy : (ipv6 ? 'prefer_ipv4' : 'ipv4_only')
		},
		inbounds: inbounds,
		outbounds: outbounds,
		route: route_obj,
		experimental: {
			cache_file: {
				enabled: true,
				path: 'cache.db'
			},
			clash_api: clash_api(main)
		}
	};
	if (length(endpoints))
		cfg.endpoints = endpoints;
	if (u.bool(dnsc.disable_cache, false))
		cfg.dns.disable_cache = true;
	if (fakeip)
		cfg.experimental.cache_file.store_fakeip = true;

	if (length(xray_nodes))
		for (let i = 0; i < length(cfg.inbounds ?? []); i++)
			if (cfg.inbounds[i].type == 'tun' && cfg.inbounds[i].auto_redirect)
				cfg.inbounds[i].auto_redirect_output_mark = u.TUN_OUT_MARK;
	return { config: cfg, warnings: warnings, node_tags: node_tags, xray: xray_nodes };
};

// ---------------------------------------------------------------------------
// Profiles: full sing-box configurations (remote or local)
// ---------------------------------------------------------------------------

// Inbound types that belong to the client device in mobile/desktop profiles.
// On the router they are replaced by our own integration inbounds.
const CLIENT_INBOUNDS = { tun: true, tproxy: true, redirect: true, mixed: true, socks: true, http: true };

export const PROXY_TYPES = {
	shadowsocks: true, vmess: true, vless: true, trojan: true, hysteria: true, hysteria2: true,
	tuic: true, anytls: true, shadowtls: true, socks: true, http: true, ssh: true, wireguard: true,
	snell: true, naive: true, tor: true, tailscale: true
};

export function profile_stats(cfg) {
	let nodes = 0, groups = 0;
	let lists = [ cfg?.outbounds ?? [], cfg?.endpoints ?? [] ];
	for (let l = 0; l < 2; l++)
		for (let i = 0; i < length(lists[l]); i++) {
			let t = lists[l][i]?.type;
			if (PROXY_TYPES[t] || t == 'xray')
				nodes++;
			else if (t == 'selector' || t == 'urltest')
				groups++;
		}
	return { nodes: nodes, groups: groups };
};

// Basic sanity check that a document is a sing-box configuration.
export function profile_validate(js) {
	if (type(js) != 'object')
		return 'not a JSON object';
	if (xray.is_xray_json(js))
		return 'this is an Xray configuration - add it under Subscriptions (URL or paste); its nodes then run through the Xray core';
	if (type(js.outbounds) != 'array' && type(js.endpoints) != 'array')
		return 'no "outbounds" - not a sing-box configuration';
	return null;
};

// The selector users switch in the UI: route.final when it is a group,
// otherwise the first selector.
export function main_group(cfg) {
	let groups = {};
	let first = null;
	let obs = cfg?.outbounds ?? [];
	for (let i = 0; i < length(obs); i++) {
		let o = obs[i];
		if (o?.type == 'selector' || o?.type == 'urltest') {
			groups[o.tag] = o.type;
			if (first == null && o.type == 'selector')
				first = o.tag;
		}
	}
	let fin = cfg?.route?.final;
	if (fin != null && groups[fin] == 'selector')
		return fin;
	return first ?? fin;
};

function map_inbound_refs(rule, removed, repl) {
	if (type(rule) != 'object')
		return;
	if (rule.inbound != null) {
		let list = u.tolist(rule.inbound);
		let out = [];
		for (let i = 0; i < length(list); i++) {
			if (removed[list[i]]) {
				for (let j = 0; j < length(repl); j++)
					if (index(out, repl[j]) < 0)
						push(out, repl[j]);
			}
			else if (index(out, list[i]) < 0)
				push(out, list[i]);
		}
		rule.inbound = out;
	}
	// logical rules
	if (type(rule.rules) == 'array')
		for (let i = 0; i < length(rule.rules); i++)
			map_inbound_refs(rule.rules[i], removed, repl);
}

// Adapt a full profile for router use. `profile` is the UCI section.
// ctx = { ver, resolv }
export function adapt_profile(src, conf, profile, ctx) {
	let cfg = u.clone(src);
	let warnings = [];
	let notes = [];		// routine adjustments, shown in "Check" only
	let main = conf.main ?? {};

	if (!u.bool(profile?.integrate, true)) {
		push(notes, 'profile runs as-is: firewall/DNS integration only works if it has matching inbounds');
		return { config: cfg, warnings: warnings, notes: notes };
	}

	let ri = router_inbounds(conf, ctx.ver);
	let ours = {};
	let our_ports = {};
	for (let i = 0; i < length(ri.inbounds); i++) {
		ours[ri.inbounds[i].tag] = true;
		our_ports[ri.inbounds[i].listen_port] = true;
	}

	// ---- inbounds: drop client-side ones, keep servers, add ours
	let removed = {};
	let kept = [];
	let src_in = cfg.inbounds ?? [];
	for (let i = 0; i < length(src_in); i++) {
		let ib = src_in[i];
		if (type(ib) != 'object')
			continue;
		let tag = ib.tag ?? (ib.type + '-' + i);
		if (CLIENT_INBOUNDS[ib.type]) {
			removed[tag] = true;
			continue;
		}
		if (ib.listen_port != null && our_ports[ib.listen_port]) {
			removed[tag] = true;
			push(warnings, 'inbound "' + tag + '" removed: port ' + ib.listen_port + ' is used by the router integration');
			continue;
		}
		if (ours[tag]) {
			removed[tag] = true;
			push(warnings, 'inbound "' + tag + '" removed: tag is reserved');
			continue;
		}
		push(kept, ib);
	}
	cfg.inbounds = [ ...ri.inbounds, ...kept ];

	let repl = [ 'mixed-in' ];
	if (ri.transparent)
		unshift(repl, ri.transparent);

	// ---- route
	if (type(cfg.route) != 'object')
		cfg.route = {};
	if (type(cfg.route.rules) != 'array')
		cfg.route.rules = [];
	for (let i = 0; i < length(cfg.route.rules); i++)
		map_inbound_refs(cfg.route.rules[i], removed, repl);
	// DNS that a client's TUN used to capture now arrives through dnsmasq (dns-in)
	let dns_repl = [ ...repl, 'dns-in' ];
	if (type(cfg.dns?.rules) == 'array')
		for (let i = 0; i < length(cfg.dns.rules); i++)
			map_inbound_refs(cfg.dns.rules[i], removed, dns_repl);

	let has_sniff = false, has_dns_hijack = false;
	for (let i = 0; i < length(cfg.route.rules); i++) {
		let r = cfg.route.rules[i];
		if (r?.action == 'sniff' && r.inbound == null)
			has_sniff = true;
		if (r?.action == 'hijack-dns' && (r.protocol == 'dns' || index(u.tolist(r.protocol), 'dns') >= 0))
			has_dns_hijack = true;
	}
	let head = [];
	if (!has_sniff && u.bool(main.sniff, true))
		push(head, { action: 'sniff' });
	push(head, { inbound: [ 'dns-in' ], action: 'hijack-dns' });
	if (!has_dns_hijack)
		push(head, { protocol: 'dns', action: 'hijack-dns' });
	cfg.route.rules = [ ...head, ...cfg.route.rules ];

	for (let k in ri.route) {
		if (k == 'default_mark' && cfg.route.default_mark != null && cfg.route.default_mark != ri.route[k])
			push(notes, 'route.default_mark replaced (needed to avoid TPROXY loops)');
		cfg.route[k] = ri.route[k];
	}
	// mobile-only options
	delete cfg.route.override_android_vpn;

	// ---- DNS: "local" would resolve through dnsmasq -> sing-box (loop)
	if (u.bool(conf.dns?.dnsmasq_redirect, true) && type(cfg.dns?.servers) == 'array') {
		let up = filter(ctx.resolv ?? [], (ip) => u.is_ip(ip) && substr(ip, 0, 4) != '127.' && ip != '::1');
		let wan = length(up) ? up[0] : '1.1.1.1';
		for (let i = 0; i < length(cfg.dns.servers); i++) {
			let s = cfg.dns.servers[i];
			if (s?.type == 'local') {
				cfg.dns.servers[i] = { type: 'udp', tag: s.tag, server: wan };
				push(notes, 'DNS server "' + s.tag + '" (local) uses ' + wan + ' (the router\'s system resolver would loop through dnsmasq)');
			}
			else if (s?.address == 'local') {
				s.address = wan;
				push(notes, 'DNS server "' + (s.tag ?? i) + '" (local) uses ' + wan + ' (the router\'s system resolver would loop through dnsmasq)');
			}
		}
	}

	// ---- experimental: our Clash API (the UI depends on it) + persistent cache
	if (type(cfg.experimental) != 'object')
		cfg.experimental = {};
	let pa = cfg.experimental.clash_api ?? {};
	let api = clash_api(main);
	if (pa.default_mode != null)
		api.default_mode = pa.default_mode;
	if (pa.external_ui != null && api.external_ui == null) {
		api.external_ui = pa.external_ui;
		if (pa.external_ui_download_url != null)
			api.external_ui_download_url = pa.external_ui_download_url;
		if (pa.external_ui_download_detour != null)
			api.external_ui_download_detour = pa.external_ui_download_detour;
	}
	cfg.experimental.clash_api = api;
	let cf = cfg.experimental.cache_file ?? {};
	cf.enabled = true;
	cf.path = 'cache.db';
	cfg.experimental.cache_file = cf;

	// ---- log goes to the system log
	cfg.log = u.log_options(main);

	// bandwidth / multiplex overrides from Settings -> Performance
	cfg.outbounds = map(cfg.outbounds ?? [], (o) => PROXY_TYPES[o?.type] ? apply_performance(o, main) : o);
	if (type(cfg.endpoints) == 'array')
		cfg.endpoints = map(cfg.endpoints, (o) => apply_performance(o, main));

	return { config: cfg, warnings: warnings, notes: notes };
};

// ---------------------------------------------------------------------------
// nftables (TPROXY mode)
// ---------------------------------------------------------------------------

function nft_set_elems(list) {
	return join(', ', list);
}

export function build_nft(conf, ctx) {
	let main = conf.main ?? {};
	let ipv6 = u.bool(main.ipv6, false);
	let port = u.toint(main.tproxy_port, 7895);
	let devs = ctx.lan_devs ?? [];
	let access = main.access_mode ?? 'all';
	let ips4 = [], ips6 = [], macs = [];

	let alist = u.flatlist(main.access_ips);
	for (let i = 0; i < length(alist); i++) {
		let a = alist[i];
		if (!u.is_cidr(a))
			continue;
		if (u.is_ipv6(split(a, '/')[0]))
			push(ips6, a);
		else
			push(ips4, a);
	}
	macs = map(filter(u.flatlist(main.access_macs), (m) => u.is_mac(m)), (m) => lc(m));

	let bypass4 = u.clone(PRIVATE4);
	let bypass6 = u.clone(PRIVATE6);
	let extra = u.flatlist(main.bypass_dst);
	for (let i = 0; i < length(extra); i++) {
		if (!u.is_cidr(extra[i]))
			continue;
		if (u.is_ipv6(split(extra[i], '/')[0]))
			push(bypass6, extra[i]);
		else
			push(bypass4, extra[i]);
	}

	let L = [];
	push(L, 'table inet singbox {');
	push(L, '\tset bypass4 {\n\t\ttype ipv4_addr\n\t\tflags interval\n\t\tauto-merge\n\t\telements = { ' + nft_set_elems(bypass4) + ' }\n\t}');
	push(L, '\tset bypass6 {\n\t\ttype ipv6_addr\n\t\tflags interval\n\t\tauto-merge\n\t\telements = { ' + nft_set_elems(bypass6) + ' }\n\t}');
	push(L, '\tset acl4 {\n\t\ttype ipv4_addr\n\t\tflags interval\n\t\tauto-merge' + (length(ips4) ? '\n\t\telements = { ' + nft_set_elems(ips4) + ' }' : '') + '\n\t}');
	push(L, '\tset acl6 {\n\t\ttype ipv6_addr\n\t\tflags interval\n\t\tauto-merge' + (length(ips6) ? '\n\t\telements = { ' + nft_set_elems(ips6) + ' }' : '') + '\n\t}');
	push(L, '\tset aclmac {\n\t\ttype ether_addr' + (length(macs) ? '\n\t\telements = { ' + nft_set_elems(macs) + ' }' : '') + '\n\t}');

	// Shared destination filter: "accept" ends the base chain => not proxied.
	push(L, '\tchain filter_dst {');
	push(L, '\t\tfib daddr type { local, broadcast, anycast, multicast } accept');
	push(L, '\t\tip daddr @bypass4 accept');
	if (ipv6)
		push(L, '\t\tip6 daddr @bypass6 accept');
	else
		push(L, '\t\tmeta nfproto ipv6 accept');
	let tcp_ports = u.flatlist(main.proxy_ports);
	if (length(tcp_ports))
		push(L, '\t\tmeta l4proto tcp th dport != { ' + join(', ', map(tcp_ports, (p) => replace(p, ':', '-'))) + ' } accept');
	push(L, '\t}');

	push(L, '\tchain prerouting {');
	push(L, '\t\ttype filter hook prerouting priority mangle; policy accept;');
	push(L, '\t\tmeta l4proto != { tcp, udp } return');
	// packets re-routed from the router itself (output chain) arrive on lo with our mark
	push(L, sprintf('\t\tiifname "lo" meta mark 0x%x meta l4proto { tcp, udp } tproxy to :%d accept', u.TPROXY_MARK, port));
	if (length(devs))
		push(L, '\t\tiifname != { ' + join(', ', map(devs, (d) => '"' + d + '"')) + ' } return');
	else
		push(L, '\t\treturn');
	if (access == 'include') {
		push(L, '\t\tether saddr @aclmac jump filter_dst_proxy');
		push(L, '\t\tip saddr @acl4 jump filter_dst_proxy');
		if (ipv6)
			push(L, '\t\tip6 saddr @acl6 jump filter_dst_proxy');
		push(L, '\t\treturn');
	}
	else {
		if (access == 'exclude') {
			push(L, '\t\tether saddr @aclmac return');
			push(L, '\t\tip saddr @acl4 return');
			push(L, '\t\tip6 saddr @acl6 return');
		}
		push(L, '\t\tjump filter_dst_proxy');
	}
	push(L, '\t}');

	push(L, '\tchain filter_dst_proxy {');
	push(L, '\t\tjump filter_dst');
	push(L, sprintf('\t\tmeta l4proto { tcp, udp } meta mark set 0x%x tproxy to :%d accept', u.TPROXY_MARK, port));
	push(L, '\t}');

	if (u.bool(main.proxy_router, true)) {
		push(L, '\tchain output {');
		push(L, '\t\ttype route hook output priority mangle; policy accept;');
		push(L, '\t\tmeta l4proto != { tcp, udp } return');
		push(L, sprintf('\t\tmeta mark 0x%x return', u.OUT_MARK));
		push(L, '\t\toifname != { ' + join(', ', [ '"lo"', ...map(devs, (d) => '"' + d + '"') ]) + ' } jump output_mark');
		push(L, '\t}');
		push(L, '\tchain output_mark {');
		push(L, '\t\tjump filter_dst');
		// do not touch DHCP / NTP-from-router style system ports
		push(L, '\t\tudp sport { 67, 68, 123 } return');
		push(L, sprintf('\t\tmeta mark set 0x%x', u.TPROXY_MARK));
		push(L, '\t}');
	}

	push(L, '}');
	return join('\n', L) + '\n';
};
