#!/bin/sh
# luci-app-singbox installer for OpenWrt 25.12+ (apk) — also works on 24.10 (opkg)
#
#   sh install.sh              install / upgrade (keeps your settings)
#   sh install.sh uninstall    remove the app (keeps /etc/singbox and /etc/config/singbox)
#   sh install.sh purge        remove the app and all its data
#   NO_DEPS=1 sh install.sh    skip package installation (offline upgrade)

set -e
# files must be world-readable for the web server, also when run from the
# in-app updater (rpcd uses a restrictive umask)
umask 022

SRC="$(cd "$(dirname "$0")" && pwd)"
FILES="$SRC/files"
LIST="/usr/share/singbox/files.list"
DEPS="curl ca-bundle ucode ucode-mod-fs ucode-mod-uci ucode-mod-ubus rpcd-mod-ucode nftables kmod-nft-tproxy kmod-nft-fib kmod-tun ip-full luci-base"

msg()  { printf '\033[1;32m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m!!\033[0m %s\n' "$*"; }
die()  { printf '\033[1;31mxx\033[0m %s\n' "$*"; exit 1; }

[ -f /etc/openwrt_release ] || die "This is not OpenWrt."
[ "$(id -u)" = "0" ] || die "Run as root."

pkg_install() {
	if command -v apk >/dev/null 2>&1; then
		apk update || warn "apk update failed"
		# shellcheck disable=SC2086
		apk add $1
	elif command -v opkg >/dev/null 2>&1; then
		opkg update || warn "opkg update failed"
		# shellcheck disable=SC2086
		opkg install $1
	else
		die "No package manager found."
	fi
}

uninstall() {
	msg "Stopping service"
	[ -x /etc/init.d/singbox ] && { /etc/init.d/singbox stop; /etc/init.d/singbox disable; } >/dev/null 2>&1 || true
	[ -x /usr/bin/singbox-ctl ] && { /usr/bin/singbox-ctl fw-down; /usr/bin/singbox-ctl dns-down; uci -q set singbox.main.max_perf='0'; /usr/bin/singbox-ctl perf-apply; } >/dev/null 2>&1 || true
	sed -i '/# singbox-begin/,/# singbox-end/d' /etc/crontabs/root 2>/dev/null || true
	/etc/init.d/cron restart >/dev/null 2>&1 || true
	if [ -f "$LIST" ]; then
		msg "Removing files"
		while read -r f; do
			case "$f" in
				/etc/config/singbox) [ "$1" = "purge" ] && rm -f "$f" ;;
				*) rm -f "$f" ;;
			esac
		done < "$LIST"
		rm -f "$LIST"
	fi
	# AmneziaWG interfaces of our nodes (the AmneziaWG packages stay installed)
	for s in $(uci -q show network | sed -n "s/^network\.\(sbawg[0-9a-f]*\)=interface$/\1/p"); do
		uci -q delete "network.$s"; uci -q delete "network.${s}_peer"
	done
	uci -q commit network
	rm -rf /usr/share/ucode/singbox /www/luci-static/resources/view/singbox /www/luci-static/resources/singbox
	rm -f /usr/share/rpcd/ucode/luci.singbox /usr/share/rpcd/ucode/luci.sbclient
	if [ "$1" = "purge" ]; then
		rm -rf /etc/singbox /etc/config/singbox
		uci -q delete firewall.singbox; uci -q delete firewall.singbox_lan; uci -q delete firewall.singbox_lan_in; uci -q commit firewall
	fi
	rm -rf /tmp/luci-indexcache* /tmp/luci-modulecache 2>/dev/null
	/etc/init.d/rpcd restart >/dev/null 2>&1 || true
	msg "Done."
}

case "$1" in
	uninstall) uninstall keep; exit 0 ;;
	purge) uninstall purge; exit 0 ;;
esac

[ -d "$FILES" ] || die "files/ not found next to install.sh — extract the release archive first."

. /etc/openwrt_release
msg "luci-app-singbox $(cat "$SRC/VERSION" 2>/dev/null) by Danial Rostamani - https://t.me/Drostamani"
msg "OpenWrt ${DISTRIB_RELEASE:-?} (${DISTRIB_ARCH:-?})"

if [ -z "$NO_DEPS" ]; then
	msg "Installing dependencies"
	pkg_install "$DEPS" || die "Dependency installation failed."
	# optional speed-ups for "Maximum performance" (not available on every target)
	for p in kmod-tcp-bbr irqbalance; do
		if command -v apk >/dev/null 2>&1; then apk add "$p" >/dev/null 2>&1; else opkg install "$p" >/dev/null 2>&1; fi || warn "optional package $p not installed"
	done
fi

# keep the stock sing-box service from fighting over ports
if [ -x /etc/init.d/sing-box ]; then
	/etc/init.d/sing-box stop >/dev/null 2>&1 || true
	/etc/init.d/sing-box disable >/dev/null 2>&1 || true
fi

was_running=0
/etc/init.d/singbox running >/dev/null 2>&1 && was_running=1

# earlier versions of this app used the ubus name luci.singbox, which other
# sing-box LuCI apps use too
rm -f /usr/share/rpcd/ucode/luci.singbox
# pages removed in 1.2.0 (subscriptions moved to the Profiles page)
rm -f /www/luci-static/resources/view/singbox/subscriptions.js

for f in /usr/libexec/rpcd/luci.singbox /usr/libexec/rpcd/singbox /usr/libexec/rpcd/sing-box; do
	[ -e "$f" ] && warn "Another sing-box app is installed ($f). It can run in parallel, but disable its service so only one sing-box controls the network."
done

msg "Copying files"
mkdir -p /usr/share/singbox
: > "$LIST.new"
( cd "$FILES" && find . -type f ) | sed 's|^\.||' | while read -r f; do
	if [ "$f" = "/etc/config/singbox" ] && [ -f /etc/config/singbox ]; then
		echo "$f" >> "$LIST.new"
		continue	# keep user settings
	fi
	mkdir -p "$(dirname "$f")"
	chmod 755 "$(dirname "$f")"
	cp -f "$FILES$f" "$f"
	chmod 644 "$f"
	echo "$f" >> "$LIST.new"
done
mv "$LIST.new" "$LIST"
chmod 755 /etc/init.d/singbox /usr/bin/singbox-ctl

msg "Initial setup"
if [ -f /etc/uci-defaults/80_luci-app-singbox ]; then
	( . /etc/uci-defaults/80_luci-app-singbox ) && rm -f /etc/uci-defaults/80_luci-app-singbox
fi

# sing-box core: the latest stable official release from GitHub (static musl
# build). Kept as it is when a downloaded core already exists or the user
# picked the OpenWrt package under Settings. The package is only the fallback.
core_pkg_fallback() {
	[ -n "$NO_DEPS" ] && return 0
	if [ ! -x /usr/bin/sing-box ] && [ ! -x /etc/singbox/bin/sing-box ]; then
		msg "Installing the OpenWrt sing-box package (fallback)"
		pkg_install sing-box || warn "Package sing-box not available — install a core later under Services → sing-box → Settings → sing-box core."
	fi
}
if [ -x /etc/singbox/bin/sing-box ]; then
	msg "sing-box core kept: $(/etc/singbox/bin/sing-box version 2>/dev/null | head -n 1)"
elif [ "$(uci -q get singbox.main.core_source)" = "package" ] && [ -x /usr/bin/sing-box ]; then
	msg "sing-box core kept (OpenWrt package, chosen in Settings): $(/usr/bin/sing-box version 2>/dev/null | head -n 1)"
elif [ -n "$NO_CORE_UPDATE" ]; then
	core_pkg_fallback
else
	msg "Installing the latest stable sing-box release from GitHub"
	if out="$(/usr/bin/singbox-ctl core-update latest 2>&1)"; then
		ver="$(echo "$out" | sed -n 's/.*"version": *"\([^"]*\)".*/\1/p' | head -n 1)"
		msg "sing-box ${ver:-latest} installed"
	else
		warn "Could not download the latest core: $(echo "$out" | sed -n 's/.*"error": *"\([^"]*\)".*/\1/p' | head -n 1)"
		core_pkg_fallback
	fi
fi

rm -rf /tmp/luci-indexcache* /tmp/luci-modulecache 2>/dev/null
/etc/init.d/rpcd restart >/dev/null 2>&1 || true
/etc/init.d/singbox enable >/dev/null 2>&1 || true

msg "Checking the backend"
selftest="$(/usr/bin/singbox-ctl rpc status </dev/null 2>&1)"
case "$selftest" in
	*'@@SINGBOX-RPC@@'*'"running"'*) msg "Backend OK" ;;
	*)
		warn "Backend self-test failed. Output:"
		echo "$selftest" | tail -n 30
		warn "Please send this output to the developer."
		;;
esac
if command -v ubus >/dev/null 2>&1; then
	if ubus -t 15 wait_for luci.sbclient >/dev/null 2>&1; then
		msg "LuCI backend registered (luci.sbclient)"
	else
		warn "rpcd did not register luci.sbclient. rpcd messages:"
		logread 2>/dev/null | grep -i -E 'rpcd|ucode' | tail -n 20
	fi
fi

if [ "$was_running" = "1" ]; then
	msg "Restarting service"
	/etc/init.d/singbox restart || true
fi

msg "Installed. Open LuCI → Services → sing-box (reload the browser page)."
