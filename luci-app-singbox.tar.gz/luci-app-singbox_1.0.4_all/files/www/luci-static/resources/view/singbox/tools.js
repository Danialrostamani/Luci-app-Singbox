'use strict';
'require view';
'require ui';
'require singbox.common as sb';

// Tools: Network Quality (Apple RPM test) and STUN / NAT type test, the same
// tests as in the sing-box apps. They run on the router through one node.
return view.extend({
	load() {
		return L.resolveDefault(sb.callToolResults(), {});
	},

	nodeSelect(data) {
		const sel = E('select', { 'class': 'cbi-input-select', 'style': 'min-width:220px;max-width:100%' }, [
			E('option', { 'value': 'direct' }, _('Direct (no proxy)'))
		]);
		(data.nodes || []).forEach((t) => sel.appendChild(E('option', { 'value': t }, t)));
		if (data.selected && (data.nodes || []).indexOf(data.selected) >= 0)
			sel.value = data.selected;
		else if ((data.nodes || []).length)
			sel.value = data.nodes[0];
		return sel;
	},

	/* friendly name for the NAT behaviour (RFC 4787 terms from STUN) */
	natType(r) {
		const m = (r.mapping || '').toLowerCase(), f = (r.filtering || '').toLowerCase();
		if (!m || !f)
			return null;
		if (m.indexOf('endpoint independent') < 0)
			return [ _('Symmetric'), 'bad', _('Calls, games and P2P often fail.') ];
		if (f.indexOf('endpoint independent') >= 0)
			return [ _('Open (full cone)'), 'ok', _('Best for games, calls and P2P.') ];
		if (f.indexOf('port') >= 0)
			return [ _('Port-restricted cone'), 'warn', _('Most apps work; some games and P2P connections may not.') ];
		return [ _('Restricted cone'), 'warn', _('Most games and calls work.') ];
	},

	row(label, value, extra) {
		return E('tr', [ E('td', { 'style': 'width:40%' }, label), E('td', { 'class': 'sb-ltr' }, [ value || '-', extra ? E('span', { 'class': 'sb-sub' }, '  ' + extra) : '' ]) ]);
	},

	resultTable(tool, r) {
		if (!r)
			return E('div', { 'class': 'sb-sub' }, _('Not run yet.'));
		const when = r.time ? new Date(r.time * 1000).toLocaleString() : '';
		const via = r.node == 'direct' ? _('Direct (no proxy)') : r.node;
		if (!r.ok)
			return E('div', { 'class': 'sb-alert bad' }, [ _('Test failed: %s').format(r.error || '?'), E('div', { 'class': 'sb-sub' }, '%s · %s'.format(via, when)) ]);
		let rows;
		if (tool == 'stun') {
			const nt = this.natType(r);
			rows = [
				nt ? E('tr', [ E('td', _('NAT type')), E('td', [ E('strong', { 'style': 'color:var(--sb-' + nt[1] + ')' }, nt[0]), E('div', { 'class': 'sb-sub' }, nt[2]) ]) ]) : '',
				this.row(_('External address'), r.external),
				this.row(_('Latency'), r.latency),
				this.row(_('NAT mapping'), r.mapping),
				this.row(_('NAT filtering'), r.filtering),
				r.nat_note ? E('tr', [ E('td', { 'colspan': 2, 'class': 'sb-sub' }, r.nat_note) ]) : ''
			];
		}
		else {
			rows = [
				this.row(_('Download capacity'), r.download, r.download_accuracy ? _('accuracy: %s').format(r.download_accuracy) : null),
				this.row(_('Upload capacity'), r.upload, r.upload_accuracy ? _('accuracy: %s').format(r.upload_accuracy) : null),
				this.row(_('Download responsiveness'), r.download_rpm),
				this.row(_('Upload responsiveness'), r.upload_rpm),
				this.row(_('Idle latency'), r.idle_latency)
			];
		}
		return E('div', [
			E('table', { 'class': 'sb-table', 'style': 'max-width:640px' }, rows),
			E('div', { 'class': 'sb-sub', 'style': 'margin-top:4px' }, _('Through: %s · %s').format(via, when))
		]);
	},

	toolCard(data, tool, title, icon, descr, runLabel) {
		const sel = this.nodeSelect(data);
		const out = E('div', { 'style': 'margin-top:10px' }, this.resultTable(tool, (data.results || {})[tool]));
		const run = E('button', {
			'class': 'btn cbi-button-action',
			'disabled': data.supported ? null : '',
			'click': ui.createHandlerFn(this, () => {
				const tag = sel.value;
				return sb.runTask('net-tool', tool + ':' + tag, runLabel).then(() =>
					L.resolveDefault(sb.callToolResults(), {}).then((d) => {
						out.innerHTML = '';
						out.appendChild(this.resultTable(tool, (d.results || {})[tool]));
					}));
			})
		}, '▶ ' + _('Run test'));
		return E('div', { 'class': 'cbi-section' }, [
			E('h3', [ icon, ' ', title ]),
			E('div', { 'class': 'sb-sub', 'style': 'margin-bottom:8px' }, descr),
			E('div', { 'class': 'sb-toolbar' }, [ E('strong', _('Through:')), sel, run ]),
			out
		]);
	},

	render(data) {
		data = data || {};
		return sb.wrap([
			E('h2', _('Tools')),
			E('div', { 'class': 'cbi-map-descr' }, _('Network tests from the sing-box apps, run on the router through the node you choose. “Direct” tests the router’s own internet connection without a proxy.')),
			data.supported ? '' : E('div', { 'class': 'sb-alert warn' }, [
				_('These tools need sing-box 1.14 or newer (installed: %s).').format(data.version || '-'), ' ',
				E('a', { 'href': L.url('admin/services/singbox/update') }, _('Update the core') + ' →')
			]),
			this.toolCard(data, 'networkquality', _('Network Quality'), '🌐',
				_('Apple’s network quality test: download and upload capacity plus responsiveness under load (RPM, round-trips per minute; higher is better). Takes about 20 seconds.'),
				_('Running the network quality test…')),
			this.toolCard(data, 'stun', _('STUN Test'), '⇅',
				_('Finds the public address and the NAT type (mapping and filtering) as seen through the node: “Open” is best for games, calls and P2P. Through a proxy this is the NAT of the proxy server; “Direct” shows your own line (double NAT shows up here).'),
				_('Running the STUN test…'))
		]);
	},

	handleSave: null,
	handleSaveApply: null,
	handleReset: null
});
