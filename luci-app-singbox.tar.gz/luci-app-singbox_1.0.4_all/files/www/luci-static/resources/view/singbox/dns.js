'use strict';
'require view';
'require form';
'require ui';
'require singbox.common as sb';

const REMOTE_PRESETS = [
	[ 'tcp://1.1.1.1', 'Cloudflare TCP (default)' ],
	[ 'https://1.1.1.1/dns-query', 'Cloudflare DoH' ],
	[ 'https://8.8.8.8/dns-query', 'Google DoH' ],
	[ 'https://dns.google/dns-query', 'Google DoH (dns.google)' ],
	[ 'https://9.9.9.9/dns-query', 'Quad9 DoH' ],
	[ 'tls://1.1.1.1', 'Cloudflare DoT' ],
	[ 'tls://8.8.8.8', 'Google DoT' ],
	[ 'https://dns.adguard-dns.com/dns-query', 'AdGuard DoH' ],
	[ 'quic://dns.adguard-dns.com', 'AdGuard DoQ' ],
	[ 'h3://dns.google/dns-query', 'Google DoH3' ],
	[ 'udp://8.8.8.8', 'Google UDP' ]
];

const DIRECT_PRESETS = [
	[ 'local', _('local — system resolver (default)') ],
	[ 'auto', _('Automatic (DNS from your ISP / WAN)') ],
	[ '178.22.122.100', 'Shecan' ],
	[ '78.157.42.100', 'Electro' ],
	[ '10.202.10.10', 'Radar Game' ],
	[ '10.202.10.202', '403.online' ],
	[ '185.55.226.26', 'Begzar' ],
	[ '1.1.1.1', 'Cloudflare' ],
	[ '8.8.8.8', 'Google' ],
	[ 'https://1.1.1.1/dns-query', 'Cloudflare DoH (direct)' ]
];

return view.extend({
	load() {
		return L.resolveDefault(sb.callStatus(), {});
	},

	render(st) {
		const m = new form.Map('singbox', _('DNS'),
			_('sing-box answers DNS for the whole network: Iranian and LAN names are resolved directly, everything else through an encrypted resolver over the proxy (no DNS leaks, no poisoning).'));

		const s = m.section(form.NamedSection, 'dns', 'dns');
		s.addremove = false;

		let o = s.option(form.Value, 'remote', _('Remote DNS (through the proxy)'),
			_('Formats: https://host/dns-query, tls://host, quic://host, h3://host/dns-query, tcp://ip, udp://ip, or a plain IP.'));
		REMOTE_PRESETS.forEach(([ v, l ]) => o.value(v, '%s — %s'.format(l, v)));
		o.default = 'tcp://1.1.1.1';
		o.rmempty = false;
		o.validate = (sid, v) => /^((https|tls|quic|h3|tcp|udp):\/\/)?[\w.:\[\]-]+(\/\S*)?$/.test(v || '') ? true : _('Invalid DNS server');

		o = s.option(form.Value, 'direct', _('Direct DNS'),
			_('Used for Iranian, LAN and direct-routed names, and to resolve proxy server addresses. “Automatic” uses the DNS servers of your WAN connection. “local” uses the router’s system resolver; while “Use sing-box for the whole network” is on, that is the WAN DNS (the system resolver would otherwise loop back into sing-box).'));
		DIRECT_PRESETS.forEach(([ v, l ]) => o.value(v, (v == 'auto' || v == 'local') ? l : '%s — %s'.format(l, v)));
		o.default = 'local';
		o.rmempty = false;
		o.validate = (sid, v) => (v == 'auto' || v == 'local' || /^((https|tls|quic|h3|tcp|udp):\/\/)?[\w.:\[\]-]+(\/\S*)?$/.test(v || '')) ? true : _('Invalid DNS server');

		o = s.option(form.Flag, 'dnsmasq_redirect', _('Use sing-box for the whole network'),
			_('Points dnsmasq (the router\'s DNS server) at sing-box while the service runs, and restores it when stopped. Recommended.'));
		o.default = '1';
		o.rmempty = false;

		o = s.option(form.Flag, 'fakeip', _('FakeIP'),
			_('Answers proxied names with fake addresses from 198.18.0.0/15 for faster connections. Iranian / direct names always get real addresses. Disable if some apps misbehave.'));
		o.default = '0';

		o = s.option(form.ListValue, 'strategy', _('Address family'));
		o.value('', _('Automatic (IPv4 only unless IPv6 proxying is enabled)'));
		o.value('prefer_ipv4', _('Prefer IPv4'));
		o.value('prefer_ipv6', _('Prefer IPv6'));
		o.value('ipv4_only', _('IPv4 only'));
		o.value('ipv6_only', _('IPv6 only'));

		o = s.option(form.Flag, 'disable_cache', _('Disable DNS cache'));
		o.default = '0';

		o = s.option(form.Button, '_flush', _('DNS cache'));
		o.inputtitle = _('Flush now');
		o.inputstyle = 'reset';
		o.onclick = () => sb.callClash('flush_dns').then((r) => r.ok ? sb.notify(_('DNS cache flushed')) : sb.error(_('Service not running')));

		return m.render().then((node) => sb.wrap([ sb.profileBanner(st, _('The profile’s own DNS servers are used; only “Use sing-box for the whole network” applies.')), node ]));
	}
});
