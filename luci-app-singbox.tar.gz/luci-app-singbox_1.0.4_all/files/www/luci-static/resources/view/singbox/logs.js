'use strict';
'require view';
'require poll';
'require ui';
'require uci';
'require singbox.common as sb';

return view.extend({
	lines: 300,
	level: '',
	follow: true,

	load() {
		return Promise.all([
			L.resolveDefault(sb.callLogs(this.lines), { log: '' }),
			uci.load('singbox')
		]).then(([ log ]) => log);
	},

	/* logging on/off + level, saved and applied right away (service reloads) */
	loggingCard() {
		const enabled = uci.get('singbox', 'main', 'log_enabled') != '0' && uci.get('singbox', 'main', 'log_level') != 'off';
		const level = uci.get('singbox', 'main', 'log_level') || 'warn';
		const sw = E('input', { 'type': 'checkbox', 'id': 'sb-log-enabled' });
		sw.checked = enabled;
		const lv = E('select', { 'class': 'cbi-input-select', 'style': 'width:auto' },
			[ 'trace', 'debug', 'info', 'warn', 'error', 'fatal', 'panic' ].map((l) => E('option', { 'value': l, 'selected': l == (level == 'off' ? 'warn' : level) ? '' : null }, l)));
		lv.disabled = !enabled;
		sw.addEventListener('change', () => { lv.disabled = !sw.checked; });
		const apply = E('button', {
			'class': 'btn cbi-button-positive',
			'click': ui.createHandlerFn(this, () => {
				uci.set('singbox', 'main', 'log_enabled', sw.checked ? '1' : '0');
				uci.set('singbox', 'main', 'log_level', lv.value);
				return uci.save().then(() => ui.changes.apply(true));
			})
		}, _('Save & Apply'));
		this.loggingEnabled = enabled;
		return E('div', { 'class': 'sb-card', 'style': 'margin-bottom:12px' }, [
			E('div', { 'class': 'sb-row' }, [
				E('label', { 'for': 'sb-log-enabled', 'style': 'display:flex;align-items:center;gap:8px;font-weight:600' }, [ sw, _('Logging enabled') ]),
				E('span', { 'class': 'sb-sub' }, _('Level')), lv,
				apply
			]),
			E('div', { 'class': 'sb-sub', 'style': 'margin-top:6px' }, enabled
				? _('Turn off if you do not want sing-box to keep writing logs (saves CPU and memory on small routers).')
				: _('Logging is off: sing-box writes no logs. Turn it on to see new entries here.'))
		]);
	},

	colorize(text) {
		const frag = document.createDocumentFragment();
		const levels = { TRACE: 0, DEBUG: 1, INFO: 2, WARN: 3, ERROR: 4, FATAL: 5, PANIC: 6 };
		const min = this.level ? levels[this.level] : -1;
		text.split('\n').forEach((line) => {
			if (!line)
				return;
			const m = line.match(/\b(TRACE|DEBUG|INFO|WARN|ERROR|FATAL|PANIC)\b/);
			const lv = m ? m[1] : null;
			if (min >= 0 && lv && levels[lv] < min)
				return;
			if (min >= 0 && !lv)
				return;
			frag.appendChild(E('div', { 'class': lv ? 'lv-' + lv.toLowerCase() : '' }, line));
		});
		return frag;
	},

	draw(data) {
		const box = this.box;
		box.innerHTML = '';
		const txt = (data.log || '').trim();
		if (!txt)
			box.appendChild(E('div', { 'class': 'sb-sub' }, _('No log entries yet.')));
		else
			box.appendChild(this.colorize(txt));
		if (this.follow)
			box.scrollTop = box.scrollHeight;
	},

	refresh() {
		return L.resolveDefault(sb.callLogs(this.lines), { log: '' }).then((d) => {
			this.last = d;
			this.draw(d);
		});
	},

	render(data) {
		this.last = data;
		this.box = E('pre', { 'class': 'sb-pre sb-log', 'style': 'min-height:50vh' });

		const lines = E('select', { 'class': 'cbi-input-select', 'change': (ev) => { this.lines = +ev.target.value; this.refresh(); } },
			[ 100, 300, 1000, 3000 ].map((n) => E('option', { 'value': n, 'selected': n == this.lines ? '' : null }, _('Last %d lines').format(n))));
		const level = E('select', { 'class': 'cbi-input-select', 'change': (ev) => { this.level = ev.target.value; this.draw(this.last); } }, [
			E('option', { 'value': '' }, _('All levels')),
			E('option', { 'value': 'INFO' }, _('Info and above')),
			E('option', { 'value': 'WARN' }, _('Warnings and errors')),
			E('option', { 'value': 'ERROR' }, _('Errors only'))
		]);
		const follow = E('label', {}, [ E('input', { 'type': 'checkbox', 'checked': '', 'change': (ev) => { this.follow = ev.target.checked; } }), ' ', _('Auto-scroll') ]);

		const page = sb.wrap([
			E('h2', _('Logs')),
			E('div', { 'class': 'cbi-map-descr' }, _('Log output of sing-box and the controller (system log). Set the log level under Settings.')),
			E('div', { 'class': 'sb-toolbar' }, [
				lines, level, follow,
				E('button', { 'class': 'btn cbi-button', 'click': ui.createHandlerFn(this, () => this.refresh()) }, '⟳ ' + _('Refresh')),
				E('button', { 'class': 'btn cbi-button', 'click': () => sb.copyText(this.last?.log || '') }, _('Copy'))
			]),
			this.box
		]);
		page.insertBefore(this.loggingCard(), page.querySelector('.sb-toolbar'));
		this.draw(data);
		if (this.loggingEnabled)
			poll.add(() => this.refresh(), 5);
		return page;
	},

	handleSaveApply: null,
	handleSave: null,
	handleReset: null
});
