'use strict';
'require view';
'require poll';
'require ui';
'require singbox.common as sb';
'require rpc';

const callHostHints = rpc.declare({ object: 'luci-rpc', method: 'getHostHints', expect: { '': {} } });

return view.extend({
	filter: '',
	paused: false,
	prev: {},

	load() {
		return Promise.all([
			L.resolveDefault(sb.callClash('connections'), { ok: false }),
			L.resolveDefault(callHostHints(), {})
		]).then(([ c, hints ]) => {
			this.names = {};
			Object.keys(hints || {}).forEach((mac) => {
				const h = hints[mac];
				(h.ipaddrs || []).concat(h.ip6addrs || []).forEach((ip) => { this.names[ip] = h.name || mac; });
			});
			return c;
		});
	},

	/* per device (source IP): connections, traffic of open connections, live speed */
	drawDevices(list, rates) {
		const body = this.dbody;
		while (body.firstChild)
			body.removeChild(body.firstChild);
		const dev = {};
		list.forEach((c) => {
			const ip = (c.metadata || {}).sourceIP || '?';
			const d = dev[ip] || (dev[ip] = { ip: ip, n: 0, up: 0, down: 0, rup: 0, rdown: 0 });
			d.n++;
			d.up += c.upload || 0;
			d.down += c.download || 0;
			const r = rates[c.id];
			if (r) {
				d.rup += r.u;
				d.rdown += r.d;
			}
		});
		const rows = Object.values(dev).sort((a, b) => (b.rdown + b.rup) - (a.rdown + a.rup) || (b.down + b.up) - (a.down + a.up));
		rows.forEach((d) => {
			const name = this.names[d.ip] || (/^(127\.|172\.19\.0\.|::1$)/.test(d.ip) ? _('this router') : '');
			body.appendChild(E('tr', { 'style': 'cursor:pointer', 'title': _('Show this device’s connections'), 'click': () => {
				this.filter = d.ip;
				this.search.value = d.ip;
				this.refresh();
			} }, [
				E('td', [ E('div', {}, name || d.ip), name ? E('div', { 'class': 'sb-sub sb-ltr' }, d.ip) : '' ]),
				E('td', { 'class': 'num' }, String(d.n)),
				E('td', { 'class': 'num sb-ltr' }, '↓ %s ↑ %s'.format(sb.fmtSpeed(d.rdown), sb.fmtSpeed(d.rup))),
				E('td', { 'class': 'num sb-ltr' }, '↓ %s ↑ %s'.format(sb.fmtBytes(d.down), sb.fmtBytes(d.up)))
			]));
		});
		if (!rows.length)
			body.appendChild(E('tr', [ E('td', { 'colspan': 4, 'class': 'sb-sub', 'style': 'text-align:center' }, _('No devices.')) ]));
	},

	host(c) {
		const m = c.metadata || {};
		const h = m.host || m.destinationIP || '';
		const p = m.destinationPort ? ':' + m.destinationPort : '';
		return h.includes(':') && !m.host ? '[' + h + ']' + p : h + p;
	},

	draw(data) {
		const body = this.tbody;
		while (body.firstChild)
			body.removeChild(body.firstChild);

		if (!data.ok) {
			this.drawDevices([], {});
			this.summary.textContent = _('Service not running or Clash API not reachable.');
			return;
		}
		const now = Date.now();
		const q = this.filter.toLowerCase();
		const list = (data.connections || []).filter((c) => {
			if (!q)
				return true;
			const m = c.metadata || {};
			return [ m.host, m.destinationIP, m.sourceIP, c.rule, (c.chains || []).join(' ') ].join(' ').toLowerCase().includes(q);
		}).sort((a, b) => (b.download + b.upload) - (a.download + a.upload));

		const cur = {};
		const rates = {};
		(data.connections || []).forEach((c) => {
			const prev = this.prev[c.id];
			if (prev) {
				const dt = (now - prev.t) / 1000;
				rates[c.id] = { d: Math.max(0, (c.download - prev.d) / dt), u: Math.max(0, (c.upload - prev.u) / dt) };
			}
		});
		this.drawDevices(data.connections || [], rates);
		list.forEach((c) => {
			const m = c.metadata || {};
			const prev = this.prev[c.id];
			let rate = '';
			if (prev) {
				const dt = (now - prev.t) / 1000;
				const dl = Math.max(0, (c.download - prev.d) / dt), ul = Math.max(0, (c.upload - prev.u) / dt);
				if (dl + ul > 0)
					rate = '↓%s ↑%s'.format(sb.fmtSpeed(dl), sb.fmtSpeed(ul));
			}
			const age = c.start ? (now - Date.parse(c.start)) / 1000 : null;
			const chain = (c.chains || []).slice().reverse().join(' → ');
			body.appendChild(E('tr', [
				E('td', [
					E('div', { 'class': 'sb-ltr', 'style': 'word-break:break-all' }, this.host(c)),
					E('div', { 'class': 'sb-sub sb-ltr' }, '%s · %s%s'.format((m.network || '').toUpperCase(), m.sourceIP || '', m.sourcePort ? ':' + m.sourcePort : ''))
				]),
				E('td', [ E('div', { 'style': 'unicode-bidi:plaintext' }, chain), E('div', { 'class': 'sb-sub' }, c.rule + (c.rulePayload ? ' (' + c.rulePayload + ')' : '')) ]),
				E('td', { 'class': 'num sb-ltr' }, [ E('div', '↓ ' + sb.fmtBytes(c.download)), E('div', '↑ ' + sb.fmtBytes(c.upload)), E('div', { 'class': 'sb-sub' }, rate) ]),
				E('td', { 'class': 'num' }, sb.fmtDuration(age)),
				E('td', { 'class': 'num' }, E('button', {
					'class': 'btn cbi-button-negative',
					'style': 'padding:0 8px',
					'title': _('Close connection'),
					'click': ui.createHandlerFn(this, () => sb.callClash('close', '', c.id).then(() => this.refresh()))
				}, '✕'))
			]));
		});
		(data.connections || []).forEach((c) => { cur[c.id] = { t: now, d: c.download, u: c.upload }; });
		this.prev = cur;
		if (!list.length)
			body.appendChild(E('tr', [ E('td', { 'colspan': 5, 'class': 'sb-sub', 'style': 'text-align:center' }, _('No connections.')) ]));
		this.summary.textContent = _('%d connections · total ↓ %s ↑ %s').format((data.connections || []).length, sb.fmtBytes(data.downloadTotal), sb.fmtBytes(data.uploadTotal));
	},

	refresh() {
		if (this.paused)
			return Promise.resolve();
		return L.resolveDefault(sb.callClash('connections'), { ok: false }).then((d) => this.draw(d));
	},

	render(data) {
		this.tbody = E('tbody');
		this.dbody = E('tbody');
		this.summary = E('div', { 'class': 'sb-sub' });
		const search = E('input', { 'type': 'search', 'class': 'cbi-input-text', 'placeholder': _('Filter by host, IP, rule or node…') });
		this.search = search;
		search.addEventListener('input', () => { this.filter = search.value; this.refresh(); });
		const pause = E('button', { 'class': 'btn cbi-button', 'click': (ev) => {
			this.paused = !this.paused;
			ev.target.textContent = this.paused ? '▶ ' + _('Resume') : '⏸ ' + _('Pause');
		} }, '⏸ ' + _('Pause'));

		const page = sb.wrap([
			E('h2', _('Connections')),
			E('div', { 'class': 'cbi-map-descr' }, _('Live connections handled by sing-box, refreshed every 2 seconds.')),
			E('div', { 'class': 'sb-toolbar' }, [
				search, pause,
				E('button', {
					'class': 'btn cbi-button-negative',
					'click': ui.createHandlerFn(this, () => {
						if (confirm(_('Close all connections?')))
							return sb.callClash('close').then(() => this.refresh());
					})
				}, _('Close all'))
			]),
			E('h3', { 'style': 'margin-top:12px' }, _('Devices')),
			E('div', { 'class': 'sb-sub' }, _('Traffic of the open connections of each device; click a device to see its connections.')),
			E('div', { 'class': 'sb-card', 'style': 'padding:0;overflow-x:auto;margin:6px 0 12px' }, [
				E('table', { 'class': 'sb-table' }, [
					E('thead', [ E('tr', [ E('th', _('Device')), E('th', { 'class': 'num' }, _('Connections')), E('th', { 'class': 'num' }, _('Speed')), E('th', { 'class': 'num' }, _('Traffic')) ]) ]),
					this.dbody
				])
			]),
			E('h3', _('Connections')),
			this.summary,
			E('div', { 'class': 'sb-card', 'style': 'padding:0;overflow-x:auto;margin-top:8px' }, [
				E('table', { 'class': 'sb-table' }, [
					E('thead', [ E('tr', [ E('th', _('Destination')), E('th', _('Route')), E('th', { 'class': 'num' }, _('Traffic')), E('th', { 'class': 'num' }, _('Duration')), E('th') ]) ]),
					this.tbody
				])
			])
		]);
		this.draw(data);
		poll.add(() => this.refresh(), 2);
		return page;
	},

	handleSaveApply: null,
	handleSave: null,
	handleReset: null
});
