'use strict';
'require view';
'require poll';
'require ui';
'require singbox.common as sb';

return view.extend({
	traffic: null,

	load() {
		return Promise.all([
			sb.callStatus(),
			L.resolveDefault(sb.callNodes(), { nodes: [], subs: [] }),
			L.resolveDefault(sb.callProfiles(), { profiles: [], active: '' })
		]);
	},

	modeLabel(m) {
		return { tproxy: _('Transparent proxy (TPROXY)'), tun: _('TUN'), mixed_only: _('Proxy port only') }[m] || m;
	},

	renderStatus(st) {
		const running = !!st.running;
		const power = E('button', {
			'class': 'sb-power' + (running ? ' on' : ''),
			'title': running ? _('Stop') : _('Start'),
			'click': ui.createHandlerFn(this, () => {
				power.setAttribute('disabled', 'disabled');
				return sb.callService(running ? 'stop' : 'start').then((r) => {
					if (!r.ok)
						sb.error(_('Failed to start: %s').format(r.error || '?'));
					return this.refresh();
				});
			})
		}, [ '⏻' ]);

		const pills = [];
		pills.push(running ? sb.pill(_('Running'), 'ok', true) : sb.pill(_('Stopped'), st.enabled ? 'bad' : '', true));
		if (running && st.mode == 'tproxy')
			pills.push(st.fw ? sb.pill(_('Firewall OK'), 'ok') : sb.pill(_('Firewall rules missing'), 'warn'));
		if (running)
			pills.push(st.dns ? sb.pill(_('DNS via sing-box'), 'ok') : sb.pill(_('DNS not redirected'), ''));
		pills.push(st.profile ? sb.pill(_('Profile: %s').format(st.profile), '') : sb.pill(_('Built-in configuration'), ''));

		const restart = E('button', {
			'class': 'btn cbi-button',
			'disabled': running ? null : true,
			'click': ui.createHandlerFn(this, () => sb.callService('restart').then((r) => {
				if (!r.ok) sb.error(r.error || _('Restart failed'));
				return this.refresh();
			}))
		}, [ _('Restart') ]);

		return E('div', { 'class': 'sb-card' }, [
			E('div', { 'class': 'sb-row' }, [
				power,
				E('div', { 'style': 'flex:1;min-width:0' }, [
					E('div', { 'class': 'sb-big' }, running ? _('Connected') : _('Disconnected')),
					E('div', { 'class': 'sb-row', 'style': 'margin-top:6px' }, pills),
					E('div', { 'class': 'sb-sub', 'style': 'margin-top:6px' }, [
						_('Mode: %s').format(this.modeLabel(st.mode)), ' · ',
						_('Core: %s').format(st.core?.version ? 'sing-box ' + st.core.version : _('not installed'))
					])
				]),
				restart
			])
		]);
	},

	/* Configuration picker: built-in configuration or one of the profiles */
	renderProfile(st, profs) {
		const list = (profs && profs.profiles) || [];
		const active = (profs && profs.active) || '';
		const sel = E('select', { 'class': 'cbi-input-select', 'style': 'width:100%' }, [
			E('option', { 'value': '' }, _('Built-in configuration')),
			...list.map((p) => E('option', { 'value': p.id, 'selected': p.id == active ? '' : null }, p.name + (p.type == 'remote' ? '' : ' (' + _('local') + ')')))
		]);
		sel.value = active;
		sel.addEventListener('change', ui.createHandlerFn(this, () => {
			const id = sel.value;
			const name = id ? (list.find((p) => p.id == id)?.name || id) : _('Built-in configuration');
			sel.disabled = true;
			ui.showModal(_('Switching profile…'), [ E('p', { 'class': 'spinning' }, _('Validating and starting “%s”…').format(name)) ]);
			return sb.callProfileActivate(id).then((r) => {
				ui.hideModal();
				if (!r.ok) {
					sb.error(_('Could not switch: %s').format(r.error || '?'));
					sel.value = active;
				}
				else
					sb.notify(r.running === false ? _('Saved. It will be used when the service starts.') : _('Now running “%s”.').format(name));
			}).finally(() => {
				sel.disabled = false;
				return this.refresh();
			});
		}));
		const cur = list.find((p) => p.id == active);
		const info = cur?.info || {};
		return E('div', { 'class': 'sb-card' }, [
			E('h4', _('Profile')),
			sel,
			E('div', { 'class': 'sb-sub', 'style': 'margin-top:8px' }, cur
				? _('%d nodes · %d groups · updated %s').format(info.nodes ?? 0, info.groups ?? 0, sb.fmtAgo(info.updated))
				: _('Subscriptions, nodes and routing settings of this app.')),
			E('div', { 'style': 'margin-top:8px' }, [
				E('a', { 'href': L.url('admin/services/singbox/profiles') }, list.length ? _('Manage profiles & subscriptions') : _('Add a profile or subscription'))
			])
		]);
	},

	renderMode(st) {
		const cur = (st.clash_mode || '').toLowerCase();
		const buttons = [ [ 'rule', _('Rule') ], [ 'global', _('Global') ], [ 'direct', _('Direct') ] ].map(([ m, label ]) =>
			E('button', {
				'class': cur == m ? 'active' : '',
				'disabled': st.running ? null : true,
				'click': ui.createHandlerFn(this, () => sb.callClash('set_mode', '', '', m).then(() => this.refresh()))
			}, [ label ]));
		const desc = {
			rule: _('Iranian & private destinations go direct, everything else through the proxy.'),
			global: _('All traffic (except LAN) goes through the proxy.'),
			direct: _('Everything goes direct; the proxy is bypassed.')
		};
		return E('div', { 'class': 'sb-card' }, [
			E('h4', _('Routing mode')),
			E('div', { 'class': 'sb-seg' }, buttons),
			E('div', { 'class': 'sb-sub', 'style': 'margin-top:8px' }, st.running ? (desc[cur] || '') : _('Start the service to switch modes.')),
			st.profile ? E('div', { 'class': 'sb-sub', 'style': 'margin-top:4px' }, _('With a profile, modes only take effect if the profile uses clash_mode rules.')) : ''
		]);
	},

	renderNode(st, px) {
		const body = [ E('h4', (st.profile && px?.group) ? _('Current node · %s').format(px.group) : _('Current node')) ];
		if (!st.running || !px || !px.ok) {
			body.push(E('div', { 'class': 'sb-big' }, '—'));
			body.push(E('div', { 'class': 'sb-sub' }, st.running ? _('Clash API not reachable') : _('Service stopped')));
		}
		else {
			const sel = px.selected;
			/* when the selection is itself a group, px.auto is what it resolved to */
			const real = (px.auto && px.auto != sel && (sel == 'auto' || st.profile)) ? px.auto : sel;
			const d = px.delays?.[real];
			body.push(E('div', { 'class': 'sb-big', 'style': 'unicode-bidi:plaintext' }, (sel == 'auto' && !st.profile) ? _('Auto (best)') : (sel || '—')));
			body.push(E('div', { 'class': 'sb-row', 'style': 'margin-top:6px' }, [
				real != sel ? E('span', { 'class': 'sb-sub', 'style': 'unicode-bidi:plaintext' }, '→ ' + real) : '',
				E('span', { 'class': 'sb-delay ' + sb.delayClass(d) }, sb.delayText(d))
			]));
		}
		body.push(E('div', { 'style': 'margin-top:10px' }, [
			E('a', { 'class': 'btn cbi-button cbi-button-action', 'href': L.url('admin/services/singbox/nodes') }, [ _('Change node') ])
		]));
		return E('div', { 'class': 'sb-card' }, body);
	},

	renderTraffic() {
		this.trafficEls = {
			up: E('div', { 'class': 'sb-speed sb-ltr' }, '—'),
			down: E('div', { 'class': 'sb-speed sb-ltr' }, '—'),
			tot: E('div', { 'class': 'sb-sub sb-ltr' }, ''),
			conns: E('div', { 'class': 'sb-sub' }, ''),
			chart: E('div', { 'class': 'sb-chart' })
		};
		this.drawChart();
		return E('div', { 'class': 'sb-card' }, [
			E('h4', _('Traffic')),
			E('div', { 'class': 'sb-row sb-between' }, [
				E('div', {}, [ E('div', { 'class': 'sb-sub' }, '↑ ' + _('Upload')), this.trafficEls.up ]),
				E('div', {}, [ E('div', { 'class': 'sb-sub' }, '↓ ' + _('Download')), this.trafficEls.down ])
			]),
			this.trafficEls.chart,
			E('div', { 'style': 'margin-top:8px' }, [ this.trafficEls.tot, this.trafficEls.conns ])
		]);
	},

	/* speed of the last 5 minutes (kept while the page is open) */
	drawChart() {
		const el = this.trafficEls && this.trafficEls.chart;
		if (!el)
			return;
		const h = this.hist || [];
		const N = 150, W = 300, H = 56;
		let max = 1;
		h.forEach((p) => { max = Math.max(max, p.down, p.up); });
		const pts = (key) => h.map((p, i) => '%.1f,%.1f'.format((N - h.length + i) * W / (N - 1), H - 2 - (p[key] / max) * (H - 6))).join(' ');
		const ns = 'http://www.w3.org/2000/svg';
		const svg = document.createElementNS(ns, 'svg');
		svg.setAttribute('viewBox', '0 0 %d %d'.format(W, H));
		svg.setAttribute('preserveAspectRatio', 'none');
		[ [ 'down', 'var(--sb-acc, #2f81f7)' ], [ 'up', 'var(--sb-ok, #2da44e)' ] ].forEach(([ k, c ]) => {
			if (h.length < 2)
				return;
			const pl = document.createElementNS(ns, 'polyline');
			pl.setAttribute('points', pts(k));
			pl.setAttribute('fill', 'none');
			pl.setAttribute('stroke', c);
			pl.setAttribute('stroke-width', '1.6');
			pl.setAttribute('vector-effect', 'non-scaling-stroke');
			svg.appendChild(pl);
		});
		el.innerHTML = '';
		el.appendChild(svg);
		el.appendChild(E('div', { 'class': 'sb-chart-legend' }, [
			E('span', { 'style': 'color:var(--sb-acc, #2f81f7)' }, '— ' + _('Download')), ' ',
			E('span', { 'style': 'color:var(--sb-ok, #2da44e)' }, '— ' + _('Upload')), ' · ',
			_('peak %s').format(sb.fmtSpeed(max)), ' · ', _('last 5 min')
		]));
	},

	renderSystem(st) {
		const p = st.proc || {};
		return E('div', { 'class': 'sb-card', 'id': 'sb-proc-card' }, [
			E('h4', [ _('Process'), E('span', { 'class': 'sb-sub', 'style': 'font-weight:normal;margin-left:6px' }, _('(updates every 10 s)')) ]),
			E('table', { 'class': 'sb-table' }, [
				E('tr', [ E('td', _('PID')), E('td', { 'class': 'num' }, st.pid || '-') ]),
				E('tr', [ E('td', _('Uptime')), E('td', { 'class': 'num' }, st.running ? sb.fmtDuration(p.uptime) : '-') ]),
				E('tr', [ E('td', _('Memory (RSS)')), E('td', { 'class': 'num' }, p.rss_kb ? sb.fmtBytes(p.rss_kb * 1024) : '-') ]),
				E('tr', [ E('td', _('CPU (sing-box)')), E('td', { 'class': 'num' }, st.running && p.cpu != null ? '%.1f%%'.format(p.cpu) : (st.running ? '…' : '-')) ]),
				p.cpu_xray != null ? E('tr', [ E('td', _('CPU (Xray)')), E('td', { 'class': 'num' }, '%.1f%%'.format(p.cpu_xray)) ]) : '',
				p.mem_total_kb ? E('tr', [ E('td', _('RAM (router)')), E('td', { 'class': 'num' }, '%s / %s (%d%%)'.format(sb.fmtBytes(p.mem_used_kb * 1024), sb.fmtBytes(p.mem_total_kb * 1024), Math.round(p.mem_used_kb * 100 / p.mem_total_kb))) ]) : '',
				E('tr', [ E('td', _('CPU (router)')), E('td', { 'class': 'num' }, p.cpu_system != null ? '%.1f%%'.format(p.cpu_system) + (p.cpu_cores ? ' · ' + _('%d cores').format(p.cpu_cores) : '') : '…') ]),
				st.profile ? '' : E('tr', [ E('td', _('Nodes')), E('td', { 'class': 'num' }, st.state?.nodes ?? '-') ]),
				E('tr', [ E('td', _('Config generated')), E('td', { 'class': 'num' }, sb.fmtAgo(st.state?.generated)) ])
			])
		]);
	},

	renderSubs(nodes) {
		const subs = (nodes.subs || []).filter((s) => s.enabled);
		if (!subs.length)
			return E('div');
		const cards = subs.map((s) => {
			const info = s.info?.info || {};
			const used = (info.upload || 0) + (info.download || 0);
			const total = info.total || 0;
			const pct = total ? Math.min(100, used / total * 100) : 0;
			return E('div', { 'class': 'sb-card' }, [
				E('div', { 'class': 'sb-row sb-between' }, [
					E('strong', { 'style': 'unicode-bidi:plaintext' }, s.name),
					E('span', { 'class': 'sb-sub' }, _('%d nodes').format(s.info?.count || 0))
				]),
				total ? E('div', { 'class': 'sb-bar' + (pct > 90 ? ' hi' : '') }, [ E('div', { 'style': 'width:%.1f%%'.format(pct) }) ]) : '',
				E('div', { 'class': 'sb-sub sb-row sb-between' }, [
					total ? E('span', { 'class': 'sb-ltr' }, '%s / %s'.format(sb.fmtBytes(used), sb.fmtBytes(total))) : E('span', _('No usage info')),
					info.expire ? E('span', _('Expires: %s').format(sb.fmtDate(info.expire))) : ''
				]),
				E('div', { 'class': 'sb-sub' }, _('Updated %s').format(sb.fmtAgo(s.info?.updated)))
			]);
		});
		return E('div', {}, [
			E('div', { 'class': 'sb-group-h' }, [ E('h3', _('Subscriptions')) ]),
			E('div', { 'class': 'sb-grid' }, cards)
		]);
	},

	renderAlerts(st) {
		const out = [];
		if (!st.core?.path)
			out.push(E('div', { 'class': 'sb-alert bad' }, [
				_('sing-box is not installed. Install the "sing-box" package or download the core in Settings → Core.')
			]));
		const state = st.state;
		if (state && state.ok === false && st.enabled)
			out.push(E('div', { 'class': 'sb-alert bad' }, [
				E('strong', _('Configuration check failed:')), E('pre', { 'class': 'sb-pre', 'style': 'margin-top:6px' }, state.check || '')
			]));
		if (state?.warnings?.length)
			out.push(E('div', { 'class': 'sb-alert warn' }, [
				E('strong', _('Warnings')), E('ul', state.warnings.map((w) => E('li', w)))
			]));
		out.push(sb.taskBanner(st.task));
		return E('div', {}, out);
	},

	updateTraffic() {
		if (!this.trafficEls)
			return Promise.resolve();
		return sb.callClash('traffic').then((t) => {
			const now = Date.now();
			if (!t.ok) {
				this.trafficEls.up.textContent = '—';
				this.trafficEls.down.textContent = '—';
				this.trafficEls.tot.textContent = '';
				this.trafficEls.conns.textContent = '';
				this.traffic = null;
				return;
			}
			if (this.traffic) {
				const dt = (now - this.traffic.t) / 1000;
				const up = Math.max(0, (t.up - this.traffic.up) / dt);
				const down = Math.max(0, (t.down - this.traffic.down) / dt);
				this.trafficEls.up.textContent = sb.fmtSpeed(up);
				this.trafficEls.down.textContent = sb.fmtSpeed(down);
				this.hist = (this.hist || []).concat([ { up: up, down: down } ]).slice(-150);
				this.drawChart();
			}
			this.traffic = { t: now, up: t.up, down: t.down };
			this.trafficEls.tot.textContent = _('Total: ↑ %s  ↓ %s').format(sb.fmtBytes(t.up), sb.fmtBytes(t.down));
			this.trafficEls.conns.textContent = _('%d active connections').format(t.count || 0) +
				(t.memory ? ' · ' + _('core memory %s').format(sb.fmtBytes(t.memory)) : '');
		});
	},

	refresh() {
		return Promise.all([
			sb.callStatus(),
			L.resolveDefault(sb.callNodes(), { nodes: [], subs: [] }),
			L.resolveDefault(sb.callProfiles(), { profiles: [], active: '' })
		]).then((data) => this.draw(data));
	},

	draw([ st, nodes, profs ]) {
		const pxp = st.running ? L.resolveDefault(sb.callClash('proxies'), null) : Promise.resolve(null);
		return pxp.then((px) => {
			const content = [
				this.renderAlerts(st),
				E('div', { 'class': 'sb-grid sb-wide' }, [ this.renderStatus(st), this.renderProfile(st, profs), this.renderMode(st) ]),
				E('div', { 'class': 'sb-grid sb-fit' }, [ this.renderNode(st, px), this.renderTraffic(), this.renderSystem(st) ]),
				st.profile ? '' : this.renderSubs(nodes)
			];
			const root = this.root;
			while (root.firstChild)
				root.removeChild(root.firstChild);
			content.forEach((c) => root.appendChild(c));
			this.traffic = null;
			return this.updateTraffic();
		});
	},

	render(data) {
		this.root = E('div');
		const page = sb.wrap([
			E('h2', _('sing-box')),
			E('div', { 'class': 'cbi-map-descr' }, _('Universal proxy for your whole network: subscriptions, node selection, smart routing for Iran and ad blocking.')),
			this.root
		]);
		this.draw(data);
		poll.add(() => this.updateTraffic(), 2);
		poll.add(() => sb.callStatus().then((st) => {
			if (!!st.running != !!this.lastRunning || (st.task?.running != this.lastTask)) {
				this.lastRunning = !!st.running;
				this.lastTask = st.task?.running;
				return this.refresh();
			}
			/* live RAM / CPU numbers */
			const card = document.getElementById('sb-proc-card');
			if (card)
				card.replaceWith(this.renderSystem(st));
		}), 10);
		this.lastRunning = !!data[0].running;
		this.lastTask = data[0].task?.running;
		return page;
	},

	handleSaveApply: null,
	handleSave: null,
	handleReset: null
});
