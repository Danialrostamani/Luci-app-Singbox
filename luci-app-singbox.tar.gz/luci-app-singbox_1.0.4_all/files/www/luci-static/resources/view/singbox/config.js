'use strict';
'require view';
'require ui';
'require uci';
'require singbox.common as sb';

return view.extend({
	load() {
		return Promise.all([
			L.resolveDefault(sb.callConfig(), {}),
			L.resolveDefault(sb.callCustomGet(), { text: '' }),
			uci.load('singbox')
		]);
	},

	pretty(text) {
		try {
			return JSON.stringify(JSON.parse(text), null, 2);
		}
		catch (e) {
			return text || '';
		}
	},

	stateBox(state) {
		if (!state)
			return E('div', { 'class': 'sb-alert info' }, _('No configuration generated yet. Click “Regenerate & check”.'));
		const parts = [];
		parts.push(E('div', { 'class': 'sb-row' }, [
			state.ok ? sb.pill(_('Check passed'), 'ok', true) : sb.pill(_('Check failed'), 'bad', true),
			E('span', { 'class': 'sb-sub' }, _('Generated %s · sing-box %s').format(sb.fmtAgo(state.generated), state.version || '?')),
			sb.pill(state.profile ? _('Profile: %s').format(state.profile.name) : (state.source == 'custom' ? _('Custom configuration') : _('Built-in configuration')), '')
		]));
		if (!state.ok && state.check)
			parts.push(E('pre', { 'class': 'sb-pre', 'style': 'margin-top:8px' }, state.check));
		if (state.warnings?.length)
			parts.push(E('div', { 'class': 'sb-alert warn', 'style': 'margin-top:8px' }, [ E('strong', _('Warnings')), E('ul', state.warnings.map((w) => E('li', w))) ]));
		return E('div', { 'class': 'sb-card', 'style': 'margin-bottom:12px' }, parts);
	},

	render([ cfg, custom ]) {
		const stateEl = E('div', {}, [ this.stateBox(cfg.state) ]);
		const pre = E('pre', { 'class': 'sb-pre' }, this.pretty(cfg.config) || _('(empty)'));
		const nft = E('pre', { 'class': 'sb-pre' }, cfg.nft || _('(no firewall rules — not in TPROXY mode)'));

		const regen = E('button', {
			'class': 'btn cbi-button-action',
			'click': ui.createHandlerFn(this, () => sb.callRegenerate().then((r) => sb.callConfig().then((c) => {
				stateEl.innerHTML = '';
				stateEl.appendChild(this.stateBox(c.state));
				pre.textContent = this.pretty(c.config);
				nft.textContent = c.nft || _('(no firewall rules — not in TPROXY mode)');
				if (r.ok)
					sb.notify(_('Configuration is valid. Restart the service to use it.'));
			})))
		}, _('Regenerate & check'));

		const useCustom = uci.get('singbox', 'main', 'use_custom') == '1';
		const ta = E('textarea', { 'class': 'sb-modal-ta', 'style': 'min-height:360px', 'spellcheck': 'false' }, [ custom.text || '' ]);
		const saveCustom = E('button', {
			'class': 'btn cbi-button-positive',
			'click': ui.createHandlerFn(this, () => sb.callCustomSet(ta.value).then((r) => {
				if (!r.ok)
					return sb.error(r.error);
				if (r.check_ok === false)
					sb.error(_('Saved, but sing-box reports: %s').format(r.check));
				else
					sb.notify(_('Custom configuration saved.'));
			}))
		}, _('Save custom config'));
		const fromGenerated = E('button', {
			'class': 'btn cbi-button',
			'click': () => { ta.value = this.pretty(pre.textContent); }
		}, _('Start from generated config'));

		return sb.wrap([
			E('h2', _('Configuration')),
			E('div', { 'class': 'cbi-map-descr' }, _('The sing-box configuration generated from your settings, validated with “sing-box check”.')),
			stateEl,
			E('div', { 'class': 'sb-toolbar' }, [
				regen,
				E('button', { 'class': 'btn cbi-button', 'click': () => sb.copyText(pre.textContent) }, _('Copy JSON')),
				E('button', { 'class': 'btn cbi-button', 'click': () => {
					const blob = new Blob([ pre.textContent ], { type: 'application/json' });
					const a = E('a', { 'href': URL.createObjectURL(blob), 'download': 'sing-box-config.json' });
					document.body.appendChild(a); a.click(); document.body.removeChild(a);
				} }, _('Download'))
			]),
			E('div', { 'class': 'cbi-section' }, [ E('h3', _('Generated config.json')), pre ]),
			E('div', { 'class': 'cbi-section' }, [ E('h3', _('Firewall rules (nftables)')), nft ]),
			E('div', { 'class': 'cbi-section' }, [
				E('h3', _('Custom configuration (advanced)')),
				E('div', { 'class': useCustom ? 'sb-alert warn' : 'sb-alert info' }, useCustom
					? _('Custom configuration is ACTIVE (Settings → Advanced). The generated configuration is ignored.')
					: _('Not active. Enable “Use custom configuration” under Settings → Advanced to run this file instead of the generated one.')),
				ta,
				E('div', { 'class': 'sb-toolbar', 'style': 'margin-top:8px' }, [ saveCustom, fromGenerated ])
			])
		]);
	},

	handleSaveApply: null,
	handleSave: null,
	handleReset: null
});
