// luci-app-singbox - AmneziaWG support (optional)
// Copyright (C) 2026 Danial Rostamani. All rights reserved. See LICENSE.
//
// sing-box has no AmneziaWG. When the optional AmneziaWG packages are
// installed (kernel module + tools from github.com/Slava-Shchipunov/awg-openwrt),
// each AmneziaWG node becomes a system interface ("sbawgXXXXXX", no routes)
// and sing-box reaches it through a "direct" outbound bound to that interface.
// Nodes use the pseudo type "amneziawg" until then (like the Xray nodes).

import { readfile, stat } from 'fs';
import * as u from 'singbox.util';

export const PREFIX = 'sbawg';
export const AWG_KEYS = [ 'jc', 'jmin', 'jmax', 's1', 's2', 's3', 's4', 'h1', 'h2', 'h3', 'h4', 'i1', 'i2', 'i3', 'i4', 'i5' ];
const REPO = 'Slava-Shchipunov/awg-openwrt';

// stable interface name from the keys and server (max 15 characters)
export function ifname(o) {
	let s = '' + (o.private_key ?? '') + '|' + (o.peers?.[0]?.public_key ?? '') + '|' + (o.peers?.[0]?.address ?? '');
	let h = 5381;
	for (let i = 0; i < length(s); i++)
		h = (h * 33 + ord(s, i)) % 16777216;
	return PREFIX + sprintf('%06x', h);
};

// what sing-box sees: a direct outbound through the interface
export function as_direct(o) {
	return { type: 'direct', tag: o.tag, bind_interface: ifname(o) };
};

export function installed() {
	return u.exec('command -v awg >/dev/null 2>&1 && { [ -d /sys/module/amneziawg ] || ls /lib/modules/*/amneziawg.ko >/dev/null 2>&1; }').code == 0;
};

function board() {
	let b = u.exec("ubus call system board 2>/dev/null").out;
	let js = null;
	try { js = json(b); } catch (e) { js = null; }
	let rel = js?.release ?? {};
	let t = split(rel.target ?? '', '/');
	let arch = rel.arch ?? trim(u.exec('apk --print-arch 2>/dev/null').out);
	return { version: rel.version, target: t[0], subtarget: t[1], arch: arch, kernel: trim(u.exec('uname -r').out) };
}

// package file names of this firmware ("kmod-amneziawg_v25.12.5_x86_64_x86_64.apk")
export function packages() {
	let b = board();
	if (!b.version || !b.target || !b.subtarget || !b.arch)
		return { ok: false, error: 'cannot read the firmware version / target', board: b };
	if (match(b.version, /SNAPSHOT|-rc/))
		return { ok: false, error: 'prebuilt AmneziaWG packages exist only for stable OpenWrt releases (this is ' + b.version + ')', board: b };
	let post = '_v' + b.version + '_' + b.arch + '_' + b.target + '_' + b.subtarget + '.apk';
	let base = 'https://github.com/' + REPO + '/releases/download/v' + b.version + '/';
	return {
		ok: true, board: b,
		files: map([ 'kmod-amneziawg', 'amneziawg-tools' ], (p) => ({ name: p, file: p + post, url: base + p + post }))
	};
};

export function free_kb() {
	let l = split(trim(u.exec("df -k /overlay 2>/dev/null | tail -n 1").out), /[ \t]+/);
	return length(l) >= 4 ? int(l[3]) : null;
};

export function status() {
	let p = packages();
	return {
		installed: installed(),
		free_kb: free_kb(),
		need_kb: 1024,
		board: p.board,
		available: p.ok,
		error: p.error,
		packages: p.files ? map(p.files, (f) => f.file) : [],
		interfaces: filter(map(split(u.exec("ls /sys/class/net 2>/dev/null").out, '\n'), (l) => trim(l)), (l) => substr(l, 0, length(PREFIX)) == PREFIX)
	};
};

// UCI network sections for the nodes; returns the interface names in use.
// opts.mark: firewall mark so the tunnel's own UDP is not proxied again.
export function sync(list, opts) {
	let want = {};
	let changed = false;
	let cur = trim(u.exec('uci -q show network').out);
	let script = [];
	for (let i = 0; i < length(list); i++) {
		let o = list[i];
		let n = ifname(o);
		if (want[n])
			continue;
		want[n] = true;
		let p = o.peers?.[0] ?? {};
		let L = [
			'set network.' + n + '=interface',
			'set network.' + n + ".proto='amneziawg'",
			'set network.' + n + '.private_key=' + u.shq(o.private_key),
			'delete network.' + n + '.addresses'
		];
		for (let j = 0; j < length(o.address ?? []); j++)
			push(L, 'add_list network.' + n + '.addresses=' + u.shq(o.address[j]));
		if (o.mtu)
			push(L, 'set network.' + n + '.mtu=' + u.shq('' + o.mtu));
		if (opts?.mark)
			push(L, 'set network.' + n + '.fwmark=' + u.shq(sprintf('0x%x', opts.mark)));
		for (let j = 0; j < length(AWG_KEYS); j++) {
			let k = AWG_KEYS[j];
			if (o.awg?.[k] != null && o.awg[k] != '')
				push(L, 'set network.' + n + '.awg_' + k + '=' + u.shq('' + o.awg[k]));
			else
				push(L, 'delete network.' + n + '.awg_' + k);
		}
		// one peer, never touches the routing table
		push(L, 'delete network.' + n + '_peer');
		push(L, 'set network.' + n + '_peer=amneziawg_' + n);
		push(L, 'set network.' + n + '_peer.public_key=' + u.shq(p.public_key));
		if (p.pre_shared_key)
			push(L, 'set network.' + n + '_peer.preshared_key=' + u.shq(p.pre_shared_key));
		push(L, 'set network.' + n + '_peer.endpoint_host=' + u.shq(p.address));
		push(L, 'set network.' + n + '_peer.endpoint_port=' + u.shq('' + p.port));
		push(L, "set network." + n + "_peer.route_allowed_ips='0'");
		push(L, 'add_list network.' + n + "_peer.allowed_ips='0.0.0.0/0'");
		push(L, 'add_list network.' + n + "_peer.allowed_ips='::/0'");
		push(L, 'set network.' + n + '_peer.persistent_keepalive=' + u.shq('' + (p.persistent_keepalive_interval ?? 25)));
		// compare with what is there (cheap: one rebuild only when something differs)
		let probe = u.exec('uci -q get network.' + n + '.private_key').out;
		if (trim(probe) != o.private_key || index(cur, 'network.' + n + '_peer.endpoint_host=\'' + p.address + '\'') < 0 ||
		    index(cur, 'network.' + n + '_peer.public_key=\'' + p.public_key + '\'') < 0)
			changed = true;
		script = [ ...script, ...L ];
	}
	// interfaces of nodes that are gone
	let names = match(cur, /network\.(sbawg[0-9a-f]+)=interface/g) ?? [];
	for (let i = 0; i < length(names); i++) {
		let n = names[i][1];
		if (!want[n]) {
			push(script, 'delete network.' + n);
			push(script, 'delete network.' + n + '_peer');
			changed = true;
		}
	}
	if (!changed)
		return { changed: false, interfaces: keys(want) };
	let f = u.RUN_DIR + '/awg-uci.batch';
	u.mkdirp(u.RUN_DIR);
	u.writeatomic(f, join('\n', script) + '\ncommit network\n');
	u.exec('uci -q batch < ' + u.shq(f));
	u.remove(f);
	u.exec('/etc/init.d/network reload >/dev/null 2>&1');
	// bring them up (reload does it too; ifup makes sure after a key change)
	for (let n in want)
		u.exec('ifup ' + u.shq(n) + ' >/dev/null 2>&1');
	return { changed: true, interfaces: keys(want) };
};
