// SPDX-License-Identifier: LicenseRef-Proprietary
// Copyright (C) 2026 Danial Rostamani. All rights reserved. See LICENSE.
// luci-app-singbox - share-link / subscription parser
//
// Converts v2rayN-style share links, base64 subscriptions, sing-box JSON and
// Clash/Mihomo YAML into sing-box outbound (or endpoint) objects.

import * as u from 'singbox.util';
import * as xray from 'singbox.xray';
import * as awg from 'singbox.awg';

// Core chosen for the content being parsed (parse_content opts.core):
//   auto    - sing-box, Xray only for what sing-box lacks
//   xray    - VLESS / VMess / Trojan / Shadowsocks through Xray as well
//   singbox - no Xray: such nodes are skipped
const PARSE = { core: 'auto' };

// Outbound types we accept verbatim from sing-box JSON subscriptions.
const SB_PROXY_TYPES = {
	shadowsocks: true, vmess: true, vless: true, trojan: true, hysteria: true,
	hysteria2: true, tuic: true, anytls: true, shadowtls: true, socks: true,
	http: true, ssh: true, wireguard: true, snell: true
};

const SS_METHODS = {
	'none': true, 'plain': true,
	'aes-128-gcm': true, 'aes-192-gcm': true, 'aes-256-gcm': true,
	'chacha20-ietf-poly1305': true, 'xchacha20-ietf-poly1305': true,
	'2022-blake3-aes-128-gcm': true, '2022-blake3-aes-256-gcm': true,
	'2022-blake3-chacha20-poly1305': true,
	'aes-128-ctr': true, 'aes-192-ctr': true, 'aes-256-ctr': true,
	'aes-128-cfb': true, 'aes-192-cfb': true, 'aes-256-cfb': true,
	'rc4-md5': true, 'chacha20-ietf': true, 'xchacha20': true
};

function fail(msg) {
	return { error: msg };
}

function csv(v) {
	if (v == null || v == '')
		return [];
	if (type(v) == 'array')
		return filter(map(v, (x) => trim('' + x)), (x) => x != '');
	return filter(map(split('' + v, ','), (x) => trim(x)), (x) => x != '');
}

function truthy(v) {
	if (v == null)
		return false;
	if (type(v) == 'bool')
		return v;
	v = lc('' + v);
	return v == '1' || v == 'true' || v == 'yes';
}

// Split "host:port" honoring [ipv6]:port
function split_hostport(s) {
	s = '' + s;
	let m = match(s, /^\[([0-9A-Fa-f:.]+)\]:([0-9]+)$/);
	if (m)
		return { host: m[1], port: int(m[2]) };
	m = match(s, /^\[([0-9A-Fa-f:.]+)\]$/);
	if (m)
		return { host: m[1], port: null };
	let i = rindex(s, ':');
	if (i < 0)
		return { host: s, port: null };
	let p = substr(s, i + 1);
	if (!match(p, /^[0-9]+$/))
		return { host: s, port: null, port_raw: p };
	return { host: substr(s, 0, i), port: int(p) };
}

// Generic URI splitter: scheme://userinfo@host:port/path?query#fragment
function parse_uri(link) {
	let m = match(link, /^([A-Za-z][A-Za-z0-9+.-]*):\/\/(.*)$/);
	if (!m)
		return null;
	let r = { scheme: lc(m[1]), user: null, host: null, port: null, path: '', query: {}, name: null, raw_query: '' };
	let rest = m[2];

	let h = index(rest, '#');
	if (h >= 0) {
		r.name = trim(u.urldecode(substr(rest, h + 1)));
		rest = substr(rest, 0, h);
	}
	let q = index(rest, '?');
	if (q >= 0) {
		r.raw_query = substr(rest, q + 1);
		r.query = u.parse_qs(r.raw_query);
		rest = substr(rest, 0, q);
	}
	let at = rindex(rest, '@');
	if (at >= 0) {
		r.user = substr(rest, 0, at);
		rest = substr(rest, at + 1);
	}
	let sl = index(rest, '/');
	if (sl >= 0) {
		r.path = substr(rest, sl);
		rest = substr(rest, 0, sl);
	}
	let hp = split_hostport(rest);
	r.host = hp.host;
	r.port = hp.port;
	r.port_raw = hp.port_raw;
	return r;
}

// ---------------------------------------------------------------------------
// Normalized node -> sing-box outbound
// ---------------------------------------------------------------------------
//
// Normalized fields (n):
//   proto, name, server, port, ports (hop ranges), uuid, password, username,
//   method, alter_id, flow, packet_encoding,
//   net, host, path, service_name, header_type, early_data, early_data_header,
//   security (tls|reality|none), sni, alpn[], fp, insecure, pbk, sid, ech,
//   plugin, plugin_opts, obfs, obfs_password, up, down, auth_str,
//   congestion, udp_relay_mode, disable_sni, uot, wg {...}

function build_transport(n) {
	let net = lc(n.net ?? '');
	if (net == 'raw')
		net = 'tcp';
	let path = n.path ?? '';

	switch (net) {
	case '':
	case 'tcp':
	case 'none':
		if (lc(n.header_type ?? '') == 'http') {
			let t = { type: 'http', method: 'GET' };
			let hosts = csv(n.host);
			if (length(hosts))
				t.host = hosts;
			if (path != '')
				t.path = split(path, ',')[0];
			return { transport: t };
		}
		return { transport: null };

	case 'ws':
	case 'websocket': {
		let t = { type: 'ws' };
		let ed = n.early_data;
		// "?ed=2048" embedded in the path (v2rayN convention)
		let m = match(path, /^([^?]*)\?(.*)$/);
		if (m) {
			let qs = u.parse_qs(m[2]);
			if (qs.ed != null && match(qs.ed, /^[0-9]+$/)) {
				ed = int(qs.ed);
				delete qs.ed;
				let rest = [];
				for (let k in qs)
					push(rest, u.urlencode(k) + '=' + u.urlencode(qs[k]));
				path = m[1] + (length(rest) ? '?' + join('&', rest) : '');
			}
		}
		t.path = path != '' ? path : '/';
		if (n.host != null && n.host != '')
			t.headers = { Host: n.host };
		if (ed != null && int(ed) > 0) {
			t.max_early_data = int(ed);
			t.early_data_header_name = n.early_data_header ?? 'Sec-WebSocket-Protocol';
		}
		return { transport: t };
	}

	case 'grpc': {
		let t = { type: 'grpc' };
		let sn = n.service_name ?? n.path ?? '';
		if (sn != '')
			t.service_name = sn;
		return { transport: t };
	}

	case 'h2':
	case 'http': {
		let t = { type: 'http' };
		let hosts = csv(n.host);
		if (length(hosts))
			t.host = hosts;
		if (path != '')
			t.path = path;
		return { transport: t };
	}

	case 'httpupgrade': {
		let t = { type: 'httpupgrade' };
		if (n.host != null && n.host != '')
			t.host = n.host;
		t.path = path != '' ? path : '/';
		return { transport: t };
	}

	case 'quic':
		return { transport: { type: 'quic' } };

	default:
		return { error: 'unsupported transport: ' + net };
	}
}

function build_tls(n, force, default_alpn) {
	let sec = lc(n.security ?? '');
	if (!force && sec != 'tls' && sec != 'reality' && sec != 'xtls')
		return null;

	let tls = { enabled: true };
	let sni = n.sni;
	if (sni == null || sni == '') {
		if (n.host != null && n.host != '' && lc(n.net ?? '') != 'grpc')
			sni = split('' + n.host, ',')[0];
		else if (!u.is_ip(n.server))
			sni = n.server;
	}
	if (sni != null && sni != '')
		tls.server_name = sni;
	if (truthy(n.insecure))
		tls.insecure = true;
	if (truthy(n.disable_sni))
		tls.disable_sni = true;

	let alpn = csv(n.alpn);
	if (length(alpn))
		tls.alpn = alpn;
	else if (default_alpn)
		tls.alpn = default_alpn;

	let fp = n.fp;
	if (sec == 'reality') {
		if (n.pbk == null || n.pbk == '')
			return { error: 'reality without public key' };
		tls.reality = { enabled: true, public_key: n.pbk };
		if (n.sid != null && n.sid != '')
			tls.reality.short_id = n.sid;
		if (fp == null || fp == '' || fp == 'none')
			fp = 'chrome';
	}
	if (fp != null && fp != '' && fp != 'none')
		tls.utls = { enabled: true, fingerprint: lc(fp) };

	return tls;
}

function base_out(t, n) {
	return {
		type: t,
		tag: n.name,
		server: n.server,
		server_port: n.port
	};
}

function apply_tls_transport(o, n, tls_force, default_alpn) {
	let tr = build_transport(n);
	if (tr.error)
		return tr.error;
	let tls = build_tls(n, tls_force, default_alpn);
	if (tls?.error)
		return tls.error;
	if (tls)
		o.tls = tls;
	if (tr.transport)
		o.transport = tr.transport;
	return null;
}

export function build_outbound(n) {
	let proto = lc(n.proto ?? '');

	if (proto != 'wireguard') {
		if (n.server == null || n.server == '')
			return fail('missing server');
		if (!u.valid_port(n.port) && !(proto == 'hysteria2' && length(n.ports ?? [])))
			return fail('invalid port');
	}
	if (n.name == null || n.name == '')
		n.name = proto + '-' + n.server + ':' + n.port;

	// XHTTP, mKCP and VLESS encryption run through the Xray core
	if ((proto == 'vless' || proto == 'vmess' || proto == 'trojan' || proto == 'shadowsocks') && xray.needs_xray(n))
		return xray.from_node(n);
	// "Xray" chosen for this subscription: everything Xray can carry the same way
	if (PARSE.core == 'xray' && (proto == 'vless' || proto == 'vmess' || proto == 'trojan' ||
	    (proto == 'shadowsocks' && (n.plugin == null || n.plugin == ''))) &&
	    !match(lc(n.net ?? ''), /^(h2|http|quic)$/))
		return xray.from_node(n);

	let o, err;

	switch (proto) {
	case 'vless': {
		if (n.uuid == null || n.uuid == '')
			return fail('missing uuid');
		o = base_out('vless', n);
		o.uuid = n.uuid;
		if (n.flow != null && n.flow != '' && n.flow != 'none')
			o.flow = replace(n.flow, /-udp443$/, '');
		o.packet_encoding = n.packet_encoding ?? 'xudp';
		if (o.packet_encoding == '' || o.packet_encoding == 'none')
			delete o.packet_encoding;
		err = apply_tls_transport(o, n, false);
		break;
	}

	case 'vmess': {
		if (n.uuid == null || n.uuid == '')
			return fail('missing uuid');
		o = base_out('vmess', n);
		o.uuid = n.uuid;
		let sec = lc(n.method ?? 'auto');
		if (sec == '' || sec == 'chacha20-ietf-poly1305')
			sec = (sec == '') ? 'auto' : 'chacha20-poly1305';
		o.security = sec;
		let aid = u.toint(n.alter_id, 0);
		if (aid > 0)
			o.alter_id = aid;
		if (n.packet_encoding != null && n.packet_encoding != 'none' && n.packet_encoding != '')
			o.packet_encoding = n.packet_encoding;
		else
			o.packet_encoding = 'xudp';
		err = apply_tls_transport(o, n, false);
		break;
	}

	case 'trojan': {
		if (n.password == null || n.password == '')
			return fail('missing password');
		o = base_out('trojan', n);
		o.password = n.password;
		if (lc(n.security ?? '') == 'none')
			err = apply_tls_transport(o, n, false);
		else {
			if (lc(n.security ?? '') != 'reality')
				n.security = 'tls';
			err = apply_tls_transport(o, n, true);
		}
		break;
	}

	case 'shadowsocks': {
		let method = lc(n.method ?? '');
		if (!SS_METHODS[method])
			return fail('unsupported shadowsocks method: ' + method);
		o = base_out('shadowsocks', n);
		o.method = method;
		o.password = n.password ?? '';
		if (n.plugin != null && n.plugin != '') {
			let pl = n.plugin;
			if (pl == 'simple-obfs' || pl == 'obfs')
				pl = 'obfs-local';
			if (pl != 'obfs-local' && pl != 'v2ray-plugin')
				return fail('unsupported shadowsocks plugin: ' + pl);
			o.plugin = pl;
			if (n.plugin_opts != null && n.plugin_opts != '')
				o.plugin_opts = n.plugin_opts;
		}
		if (truthy(n.uot))
			o.udp_over_tcp = true;
		break;
	}

	case 'hysteria2': {
		o = base_out('hysteria2', n);
		if (!u.valid_port(n.port))
			o.server_port = 443;
		if (n.password != null && n.password != '')
			o.password = n.password;
		if (length(n.ports ?? []))
			o.server_ports = n.ports;
		if (n.obfs != null && n.obfs != '' && n.obfs != 'none') {
			o.obfs = { type: n.obfs };
			if (n.obfs_password != null)
				o.obfs.password = n.obfs_password;
		}
		if (u.toint(n.up, 0) > 0)
			o.up_mbps = u.toint(n.up, 0);
		if (u.toint(n.down, 0) > 0)
			o.down_mbps = u.toint(n.down, 0);
		if (n.hop_interval != null && n.hop_interval != '')
			o.hop_interval = match('' + n.hop_interval, /^[0-9]+$/) ? n.hop_interval + 's' : n.hop_interval;
		n.net = '';
		let tls = build_tls(n, true, null);
		if (tls?.error)
			return fail(tls.error);
		delete tls.utls;
		o.tls = tls;
		break;
	}

	case 'hysteria': {
		o = base_out('hysteria', n);
		// Hysteria v1 always needs a bandwidth; without one in the link use a
		// value that does not cap a typical line (adjustable under Settings -> Performance)
		let up = u.toint(n.up, 0), down = u.toint(n.down, 0);
		o.up_mbps = up > 0 ? up : 100;
		o.down_mbps = down > 0 ? down : 1000;
		if (n.auth_str != null && n.auth_str != '')
			o.auth_str = n.auth_str;
		if (n.obfs != null && n.obfs != '')
			o.obfs = n.obfs;
		if (n.protocol != null && n.protocol != '' && n.protocol != 'udp')
			return fail('unsupported hysteria protocol: ' + n.protocol);
		n.net = '';
		let tls = build_tls(n, true, null);
		if (tls?.error)
			return fail(tls.error);
		delete tls.utls;
		o.tls = tls;
		break;
	}

	case 'tuic': {
		if (n.uuid == null || n.uuid == '')
			return fail('missing uuid');
		o = base_out('tuic', n);
		o.uuid = n.uuid;
		if (n.password != null)
			o.password = n.password;
		if (n.congestion != null && n.congestion != '')
			o.congestion_control = n.congestion;
		if (n.udp_relay_mode != null && n.udp_relay_mode != '')
			o.udp_relay_mode = n.udp_relay_mode;
		if (truthy(n.zero_rtt))
			o.zero_rtt_handshake = true;
		n.net = '';
		let tls = build_tls(n, true, [ 'h3' ]);
		if (tls?.error)
			return fail(tls.error);
		delete tls.utls;
		o.tls = tls;
		break;
	}

	case 'anytls': {
		if (n.password == null || n.password == '')
			return fail('missing password');
		o = base_out('anytls', n);
		o.password = n.password;
		n.net = '';
		if (lc(n.security ?? '') != 'reality')
			n.security = 'tls';
		let tls = build_tls(n, true, null);
		if (tls?.error)
			return fail(tls.error);
		o.tls = tls;
		break;
	}

	case 'socks': {
		o = base_out('socks', n);
		o.version = '5';
		if (n.username != null && n.username != '') {
			o.username = n.username;
			o.password = n.password ?? '';
		}
		break;
	}

	case 'http': {
		o = base_out('http', n);
		if (n.username != null && n.username != '') {
			o.username = n.username;
			o.password = n.password ?? '';
		}
		if (lc(n.security ?? '') == 'tls') {
			n.net = '';
			o.tls = build_tls(n, true, null);
		}
		break;
	}

	case 'wireguard': {
		let wg = n.wg ?? {};
		if (wg.private_key == null || wg.private_key == '')
			return fail('missing wireguard private key');
		if (wg.public_key == null || wg.public_key == '')
			return fail('missing wireguard peer public key');
		if (n.server == null || n.server == '' || !u.valid_port(n.port))
			return fail('missing wireguard peer address');
		let addr = csv(wg.address);
		if (!length(addr))
			addr = [ '172.16.0.2/32' ];
		addr = map(addr, (a) => index(a, '/') >= 0 ? a : (u.is_ipv6(a) ? a + '/128' : a + '/32'));
		let peer = {
			address: n.server,
			port: n.port,
			public_key: wg.public_key,
			allowed_ips: [ '0.0.0.0/0', '::/0' ]
		};
		if (wg.psk != null && wg.psk != '')
			peer.pre_shared_key = wg.psk;
		let rsv = csv(wg.reserved);
		if (length(rsv) == 3)
			peer.reserved = map(rsv, (x) => int(x));
		if (u.toint(wg.keepalive, 0) > 0)
			peer.persistent_keepalive_interval = u.toint(wg.keepalive, 0);
		o = {
			type: 'wireguard',
			tag: n.name,
			system: false,
			mtu: u.toint(wg.mtu, 1408),
			address: addr,
			private_key: wg.private_key,
			peers: [ peer ]
		};
		return { outbound: o, endpoint: true };
	}

	default:
		return fail('unsupported protocol: ' + (proto ?? ''));
	}

	if (err)
		return fail(err);

	if (truthy(n.mux)) {
		o.multiplex = { enabled: true, protocol: n.mux_protocol ?? 'h2mux', max_connections: 4 };
		if (truthy(n.mux_padding))
			o.multiplex.padding = true;
	}

	return { outbound: o };
};

// ---------------------------------------------------------------------------
// Share links
// ---------------------------------------------------------------------------

function common_params(n, q) {
	n.net = q.type ?? q.net ?? q.network ?? '';
	n.host = q.host ?? '';
	n.path = q.path ?? '';
	n.service_name = q.serviceName ?? q.servicename ?? q.service_name;
	n.header_type = q.headerType ?? q.headertype;
	n.security = q.security ?? '';
	n.sni = q.sni ?? q.peer ?? q.servername;
	n.alpn = q.alpn;
	n.fp = q.fp ?? q.fingerprint;
	n.insecure = q.allowInsecure ?? q.allowinsecure ?? q.insecure ?? q.skip_cert_verify;
	n.pbk = q.pbk ?? q.publicKey ?? q.publickey;
	n.sid = q.sid ?? q.shortId ?? q.shortid;
	n.spx = q.spx;
	n.pqv = q.pqv;
	n.ech = q.ech;
	n.xhttp_mode = q.mode;
	n.xhttp_extra = q.extra;
	n.kcp_seed = q.seed;
	if (lc(q.mode ?? '') == 'multi')
		n.grpc_multi = true;
	if (q.ed != null)
		n.early_data = q.ed;
	if (q.eh != null)
		n.early_data_header = q.eh;
	if (n.net == 'grpc' && (n.service_name == null || n.service_name == ''))
		n.service_name = n.path;
	if (lc(q.mode ?? '') == 'multi' && n.net == 'grpc')
		n.service_name = n.service_name;	// multi-mode is transparent for sing-box
	return n;
}

function parse_vless(uri) {
	let n = common_params({ proto: 'vless', name: uri.name, server: uri.host, port: uri.port }, uri.query);
	n.uuid = u.urldecode(uri.user);
	n.flow = uri.query.flow;
	n.encryption = uri.query.encryption;
	n.packet_encoding = uri.query.packetEncoding;
	return build_outbound(n);
}

function parse_trojan(uri) {
	let n = common_params({ proto: 'trojan', name: uri.name, server: uri.host, port: uri.port }, uri.query);
	n.password = u.urldecode(uri.user);
	return build_outbound(n);
}

function parse_vmess(link) {
	let body = substr(link, 8);
	let frag = null;
	let h = index(body, '#');
	if (h >= 0) {
		frag = trim(u.urldecode(substr(body, h + 1)));
		body = substr(body, 0, h);
	}
	let dec = u.b64d(body);
	let js = null;
	if (dec != null) {
		try { js = json(dec); } catch (e) { js = null; }
	}
	if (type(js) != 'object') {
		// Shadowrocket-like "vmess://uuid@host:port?..." form
		let uri = parse_uri(link);
		if (!uri || !uri.user)
			return fail('invalid vmess link');
		let n = common_params({ proto: 'vmess', name: uri.name, server: uri.host, port: uri.port }, uri.query);
		n.uuid = u.urldecode(uri.user);
		n.method = uri.query.encryption ?? uri.query.scy ?? 'auto';
		n.alter_id = uri.query.aid ?? uri.query.alterId;
		return build_outbound(n);
	}
	let n = {
		proto: 'vmess',
		name: trim('' + (js.ps ?? frag ?? '')),
		server: trim('' + (js.add ?? '')),
		port: u.toint(js.port, 0),
		uuid: trim('' + (js.id ?? '')),
		alter_id: js.aid,
		method: js.scy ?? 'auto',
		net: js.net ?? '',
		header_type: js.type,
		host: js.host ?? '',
		path: js.path ?? '',
		security: js.tls ?? '',
		sni: js.sni,
		alpn: js.alpn,
		fp: js.fp,
		insecure: js.allowInsecure ?? js.insecure ?? js.skip_cert_verify,
		pbk: js.pbk,
		sid: js.sid
	};
	if (lc(n.net) == 'grpc') {
		n.service_name = n.path;
		n.path = '';
	}
	if (frag != null && frag != '' && n.name == '')
		n.name = frag;
	return build_outbound(n);
}

function parse_ss(link) {
	let body = substr(link, 5);
	let name = null;
	let h = index(body, '#');
	if (h >= 0) {
		name = trim(u.urldecode(substr(body, h + 1)));
		body = substr(body, 0, h);
	}
	let query = {};
	let q = index(body, '?');
	if (q >= 0) {
		query = u.parse_qs(substr(body, q + 1));
		body = substr(body, 0, q);
	}
	body = replace(body, /\/$/, '');

	let userinfo, hostport;
	let at = rindex(body, '@');
	if (at < 0) {
		// Legacy: base64(method:password@host:port)
		let dec = u.b64d(body);
		if (dec == null)
			return fail('invalid ss link');
		at = rindex(dec, '@');
		if (at < 0)
			return fail('invalid ss link');
		userinfo = substr(dec, 0, at);
		hostport = substr(dec, at + 1);
	}
	else {
		userinfo = substr(body, 0, at);
		hostport = substr(body, at + 1);
		let raw = u.urldecode(userinfo);
		if (index(raw, ':') < 0) {
			let dec = u.b64d(raw);
			if (dec == null)
				return fail('invalid ss userinfo');
			userinfo = dec;
		}
		else
			userinfo = raw;
	}
	let c = index(userinfo, ':');
	if (c < 0)
		return fail('invalid ss userinfo');
	let hp = split_hostport(hostport);
	let n = {
		proto: 'shadowsocks',
		name: name,
		server: hp.host,
		port: hp.port,
		method: substr(userinfo, 0, c),
		password: substr(userinfo, c + 1),
		uot: query.uot
	};
	if (query.plugin != null && query.plugin != '') {
		let parts = split(query.plugin, ';');
		n.plugin = parts[0];
		n.plugin_opts = join(';', slice(parts, 1));
	}
	return build_outbound(n);
}

function parse_hy2(uri) {
	let q = uri.query;
	let n = {
		proto: 'hysteria2',
		name: uri.name,
		server: uri.host,
		port: uri.port,
		password: uri.user != null ? u.urldecode(uri.user) : (q.auth ?? q.password),
		sni: q.sni ?? q.peer,
		insecure: q.insecure ?? q.allowInsecure,
		alpn: q.alpn,
		obfs: q.obfs,
		obfs_password: q['obfs-password'] ?? q.obfs_password ?? q.obfsParam,
		up: q.upmbps ?? q.up,
		down: q.downmbps ?? q.down,
		hop_interval: q.hop_interval ?? q.hopInterval,
		ports: []
	};
	// "host:443,20000-30000" style multi-port in authority
	let pr = uri.port_raw;
	let hopspec = q.mport ?? q.ports ?? pr;
	if (hopspec != null && hopspec != '') {
		let parts = split('' + hopspec, ',');
		for (let i = 0; i < length(parts); i++) {
			let p = trim(parts[i]);
			if (match(p, /^[0-9]+$/)) {
				if (!u.valid_port(n.port))
					n.port = int(p);
				else if (int(p) != n.port)
					push(n.ports, p + ':' + p);
			}
			else if (match(p, /^[0-9]+[-:][0-9]+$/))
				push(n.ports, replace(p, '-', ':'));
		}
	}
	if (!u.valid_port(n.port) && length(n.ports))
		n.port = int(split(n.ports[0], ':')[0]);
	return build_outbound(n);
}

function parse_hysteria(uri) {
	let q = uri.query;
	return build_outbound({
		proto: 'hysteria',
		name: uri.name,
		server: uri.host,
		port: uri.port,
		auth_str: q.auth ?? q.auth_str,
		protocol: q.protocol,
		sni: q.peer ?? q.sni,
		insecure: q.insecure ?? q.allowInsecure,
		alpn: q.alpn,
		obfs: q.obfsParam ?? q.obfs,
		up: q.upmbps ?? q.up,
		down: q.downmbps ?? q.down
	});
}

function parse_tuic(uri) {
	let q = uri.query;
	let user = u.urldecode(uri.user ?? '');
	let c = index(user, ':');
	return build_outbound({
		proto: 'tuic',
		name: uri.name,
		server: uri.host,
		port: uri.port,
		uuid: c >= 0 ? substr(user, 0, c) : user,
		password: c >= 0 ? substr(user, c + 1) : q.password,
		congestion: q.congestion_control ?? q.congestion,
		udp_relay_mode: q.udp_relay_mode,
		sni: q.sni,
		alpn: q.alpn,
		insecure: q.allow_insecure ?? q.allowInsecure ?? q.insecure,
		disable_sni: q.disable_sni
	});
}

function parse_anytls(uri) {
	let q = uri.query;
	return build_outbound({
		proto: 'anytls',
		name: uri.name,
		server: uri.host,
		port: uri.port,
		password: u.urldecode(uri.user ?? ''),
		security: q.security ?? 'tls',
		sni: q.sni ?? q.peer,
		insecure: q.insecure ?? q.allowInsecure,
		alpn: q.alpn,
		fp: q.fp,
		pbk: q.pbk,
		sid: q.sid
	});
}

function parse_socks_http(uri, proto) {
	let user = null, pass = null;
	if (uri.user != null && uri.user != '') {
		let raw = u.urldecode(uri.user);
		if (index(raw, ':') < 0) {
			let dec = u.b64d(raw);
			if (dec != null && index(dec, ':') >= 0)
				raw = dec;
		}
		let c = index(raw, ':');
		user = c >= 0 ? substr(raw, 0, c) : raw;
		pass = c >= 0 ? substr(raw, c + 1) : '';
	}
	return build_outbound({
		proto: proto,
		name: uri.name,
		server: uri.host,
		port: uri.port,
		username: user,
		password: pass,
		security: uri.scheme == 'https' ? 'tls' : '',
		sni: uri.query.sni
	});
}

function parse_wireguard(uri) {
	let q = uri.query;
	return build_outbound({
		proto: 'wireguard',
		name: uri.name,
		server: uri.host,
		port: uri.port,
		wg: {
			private_key: (uri.user != null && uri.user != '') ? u.urldecode(uri.user) : q.privatekey,
			public_key: q.publickey ?? q.publicKey ?? q.peer_public_key,
			psk: q.presharedkey ?? q.psk,
			address: q.address ?? q.ip,
			reserved: q.reserved,
			mtu: q.mtu,
			keepalive: q.keepalive
		}
	});
}

export function parse_link(line) {
	line = trim('' + line);
	if (line == '')
		return null;
	let m = match(line, /^([A-Za-z][A-Za-z0-9+.-]*):\/\//);
	if (!m)
		return fail('not a link');
	let scheme = lc(m[1]);

	if (scheme == 'vmess')
		return parse_vmess(line);
	if (scheme == 'ss')
		return parse_ss(line);

	let uri = parse_uri(line);
	if (!uri)
		return fail('malformed link');

	switch (scheme) {
	case 'vless':
		return parse_vless(uri);
	case 'trojan':
	case 'trojan-go':
		return parse_trojan(uri);
	case 'hysteria2':
	case 'hy2':
		return parse_hy2(uri);
	case 'hysteria':
	case 'hy':
		return parse_hysteria(uri);
	case 'tuic':
		return parse_tuic(uri);
	case 'anytls':
		return parse_anytls(uri);
	case 'socks':
	case 'socks5':
	case 'socks5h':
		return parse_socks_http(uri, 'socks');
	case 'http':
	case 'https':
		return parse_socks_http(uri, 'http');
	case 'wireguard':
	case 'wg':
		return parse_wireguard(uri);
	case 'ssr':
		return fail('ShadowsocksR is not supported by sing-box');
	default:
		return fail('unsupported scheme: ' + scheme);
	}
};

// ---------------------------------------------------------------------------
// Minimal YAML (subset sufficient for Clash/Mihomo "proxies:" sections)
// ---------------------------------------------------------------------------

// ucode does not hoist function declarations: mutually recursive YAML
// helpers call each other through this table, filled in below.
const Y = {};

function yaml_unquote(s) {
	let l = length(s);
	if (l >= 2 && substr(s, 0, 1) == '"' && substr(s, l - 1) == '"') {
		s = substr(s, 1, l - 2);
		s = replace(s, /\\(["\\\/nrt])/g, (m, c) => (c == 'n' ? '\n' : c == 'r' ? '\r' : c == 't' ? '\t' : c));
		return s;
	}
	if (l >= 2 && substr(s, 0, 1) == "'" && substr(s, l - 1) == "'")
		return replace(substr(s, 1, l - 2), "''", "'");
	return s;
}

function yaml_scalar(s) {
	s = trim(s);
	if (s == '' || s == '~' || s == 'null' || s == 'Null' || s == 'NULL')
		return null;
	let c = substr(s, 0, 1);
	if (c == '"' || c == "'")
		return yaml_unquote(s);
	if (c == '{' || c == '[')
		return Y.flow(s);
	if (s == 'true' || s == 'True' || s == 'TRUE')
		return true;
	if (s == 'false' || s == 'False' || s == 'FALSE')
		return false;
	if (match(s, /^-?[0-9]+$/) && length(s) < 16)
		return int(s);
	return s;
}

// Flow-style collections: {a: b, c: [1, 2]}
function yaml_flow(src) {
	let pos = 0;
	let len = length(src);

	function ch() { return substr(src, pos, 1); }
	function ws() { while (pos < len && index(' \t\r\n', ch()) >= 0) pos++; }

	function token() {
		ws();
		let c = ch();
		if (c == '"' || c == "'") {
			let start = pos;
			pos++;
			while (pos < len) {
				let d = ch();
				if (c == '"' && d == '\\') { pos += 2; continue; }
				if (d == c) {
					if (c == "'" && substr(src, pos + 1, 1) == "'") { pos += 2; continue; }
					pos++;
					break;
				}
				pos++;
			}
			return { q: true, v: yaml_unquote(substr(src, start, pos - start)) };
		}
		let start = pos;
		let depth = 0;
		while (pos < len) {
			let d = ch();
			if (d == ',' || d == '}' || d == ']')
				break;
			if (d == ':' && (pos + 1 >= len || index(' \t,}]', substr(src, pos + 1, 1)) >= 0))
				break;
			pos++;
		}
		return { q: false, v: trim(substr(src, start, pos - start)) };
	}

	function value() {
		ws();
		let c = ch();
		if (c == '{') {
			pos++;
			let obj = {};
			while (pos < len) {
				ws();
				if (ch() == '}') { pos++; break; }
				let k = token();
				ws();
				let v = null;
				if (ch() == ':') {
					pos++;
					v = value();
				}
				obj['' + k.v] = v;
				ws();
				if (ch() == ',') pos++;
			}
			return obj;
		}
		if (c == '[') {
			pos++;
			let arr = [];
			while (pos < len) {
				ws();
				if (ch() == ']') { pos++; break; }
				push(arr, value());
				ws();
				if (ch() == ',') pos++;
			}
			return arr;
		}
		let t = token();
		return t.q ? t.v : yaml_scalar(t.v);
	}

	return value();
}

function strip_comment(line) {
	let q = null;
	let l = length(line);
	for (let i = 0; i < l; i++) {
		let c = substr(line, i, 1);
		if (q) {
			if (c == q)
				q = null;
			continue;
		}
		if (c == '"' || c == "'") {
			q = c;
			continue;
		}
		if (c == '#' && (i == 0 || index(' \t', substr(line, i - 1, 1)) >= 0))
			return substr(line, 0, i);
	}
	return line;
}

// Split "key: value" at the first ": " / trailing ":" outside quotes.
function yaml_kv(text) {
	let q = null;
	let l = length(text);
	let depth = 0;
	for (let i = 0; i < l; i++) {
		let c = substr(text, i, 1);
		if (q) {
			if (c == q)
				q = null;
			continue;
		}
		if (c == '"' || c == "'") {
			q = c;
			continue;
		}
		if (c == '{' || c == '[') depth++;
		if (c == '}' || c == ']') depth--;
		if (c == ':' && depth == 0 && (i + 1 == l || index(' \t', substr(text, i + 1, 1)) >= 0))
			return { key: yaml_unquote(trim(substr(text, 0, i))), rest: trim(substr(text, i + 1)) };
	}
	return null;
}

function is_seq_item(t) {
	return t == '-' || substr(t, 0, 2) == '- ';
}

function yaml_lines(text) {
	let out = [];
	let raw = split(replace(text, /\r/g, ''), '\n');
	for (let i = 0; i < length(raw); i++) {
		let line = rtrim(strip_comment(raw[i]));
		let t = ltrim(line);
		if (t == '' || t == '---' || t == '...')
			continue;
		push(out, { ind: length(line) - length(t), text: t });
	}
	return out;
}

function yaml_node(L, st, ind) {
	if (st.i >= length(L))
		return null;
	if (is_seq_item(L[st.i].text))
		return Y.seq(L, st, L[st.i].ind);
	return Y.map(L, st, L[st.i].ind);
}

function yaml_seq(L, st, ind) {
	let arr = [];
	while (st.i < length(L) && L[st.i].ind == ind && is_seq_item(L[st.i].text)) {
		let t = L[st.i].text;
		let rest = ltrim(substr(t, 1));
		if (rest == '') {
			st.i++;
			if (st.i < length(L) && L[st.i].ind > ind)
				push(arr, yaml_node(L, st, L[st.i].ind));
			else
				push(arr, null);
			continue;
		}
		let c = substr(rest, 0, 1);
		if (c != '{' && c != '[' && c != '"' && c != "'" && yaml_kv(rest)) {
			// inline mapping start: "- key: value" ; continue at virtual indent
			let vind = ind + (length(t) - length(rest));
			L[st.i] = { ind: vind, text: rest };
			push(arr, Y.map(L, st, vind));
			continue;
		}
		if (is_seq_item(rest)) {
			let vind = ind + (length(t) - length(rest));
			L[st.i] = { ind: vind, text: rest };
			push(arr, yaml_seq(L, st, vind));
			continue;
		}
		push(arr, yaml_scalar(rest));
		st.i++;
	}
	return arr;
}

function yaml_block_scalar(L, st, ind, folded) {
	let parts = [];
	while (st.i < length(L) && L[st.i].ind > ind) {
		push(parts, L[st.i].text);
		st.i++;
	}
	return join(folded ? ' ' : '\n', parts);
}

function yaml_map(L, st, ind) {
	let obj = {};
	while (st.i < length(L) && L[st.i].ind == ind && !is_seq_item(L[st.i].text)) {
		let kv = yaml_kv(L[st.i].text);
		st.i++;
		if (!kv)
			continue;
		if (kv.rest == '|' || kv.rest == '>' || kv.rest == '|-' || kv.rest == '>-') {
			obj[kv.key] = yaml_block_scalar(L, st, ind, substr(kv.rest, 0, 1) == '>');
			continue;
		}
		if (kv.rest != '') {
			obj[kv.key] = yaml_scalar(kv.rest);
			continue;
		}
		if (st.i < length(L) && (L[st.i].ind > ind || (L[st.i].ind == ind && is_seq_item(L[st.i].text))))
			obj[kv.key] = yaml_node(L, st, L[st.i].ind);
		else
			obj[kv.key] = null;
	}
	return obj;
}

Y.flow = yaml_flow;
Y.seq = yaml_seq;
Y.map = yaml_map;

export function parse_yaml(text) {
	let L = yaml_lines(text);
	if (!length(L))
		return null;
	return yaml_node(L, { i: 0 }, L[0].ind);
};

// ---------------------------------------------------------------------------
// Clash proxy -> normalized node
// ---------------------------------------------------------------------------

function cget(o, k) {
	return type(o) == 'object' ? o[k] : null;
}

function clash_to_node(p) {
	if (type(p) != 'object')
		return fail('invalid proxy entry');
	let t = lc('' + (p.type ?? ''));
	let n = {
		name: p.name != null ? '' + p.name : null,
		server: p.server != null ? '' + p.server : null,
		port: u.toint(p.port, 0),
		sni: p.servername ?? p.sni ?? p.peer,
		insecure: p['skip-cert-verify'],
		alpn: p.alpn,
		fp: p['client-fingerprint'],
		net: p.network ?? '',
		security: truthy(p.tls) ? 'tls' : ''
	};
	let ro = p['reality-opts'];
	if (type(ro) == 'object') {
		n.security = 'reality';
		n.pbk = ro['public-key'];
		n.sid = ro['short-id'];
	}
	let ws = p['ws-opts'];
	if (type(ws) == 'object') {
		n.path = ws.path;
		let hd = ws.headers;
		n.host = cget(hd, 'Host') ?? cget(hd, 'host');
		n.early_data = ws['max-early-data'];
		n.early_data_header = ws['early-data-header-name'];
	}
	let go = p['grpc-opts'];
	if (type(go) == 'object')
		n.service_name = go['grpc-service-name'];
	let h2 = p['h2-opts'];
	if (type(h2) == 'object') {
		n.host = h2.host;
		n.path = h2.path;
	}
	let ho = p['http-opts'];
	if (type(ho) == 'object') {
		let paths = ho.path;
		n.path = type(paths) == 'array' ? paths[0] : paths;
		let hh = cget(ho.headers, 'Host') ?? cget(ho.headers, 'host');
		n.host = type(hh) == 'array' ? join(',', hh) : hh;
		if (n.net == 'http') {
			n.net = 'tcp';
			n.header_type = 'http';
		}
	}
	let hu = p['httpupgrade-opts'];
	if (type(hu) == 'object') {
		n.path = hu.path;
		n.host = hu.host;
	}
	let xo = p['xhttp-opts'];
	if (type(xo) == 'object') {
		n.path = xo.path;
		n.host = xo.host;
		n.xhttp_mode = xo.mode;
	}
	if (p.smux != null && type(p.smux) == 'object' && truthy(p.smux.enabled)) {
		n.mux = true;
		n.mux_protocol = p.smux.protocol;
		n.mux_padding = p.smux.padding;
	}

	switch (t) {
	case 'ss':
		n.proto = 'shadowsocks';
		n.method = p.cipher;
		n.password = '' + (p.password ?? '');
		n.uot = p['udp-over-tcp'];
		if (p.plugin != null) {
			let po = p['plugin-opts'] ?? {};
			if (p.plugin == 'obfs') {
				n.plugin = 'obfs-local';
				let opts = [ 'obfs=' + (po.mode ?? 'http') ];
				if (po.host != null)
					push(opts, 'obfs-host=' + po.host);
				n.plugin_opts = join(';', opts);
			}
			else if (p.plugin == 'v2ray-plugin') {
				n.plugin = 'v2ray-plugin';
				let opts = [ 'mode=' + (po.mode ?? 'websocket') ];
				if (truthy(po.tls))
					push(opts, 'tls');
				if (po.host != null)
					push(opts, 'host=' + po.host);
				if (po.path != null)
					push(opts, 'path=' + po.path);
				n.plugin_opts = join(';', opts);
			}
			else
				n.plugin = p.plugin;
		}
		break;
	case 'vmess':
		n.proto = 'vmess';
		n.uuid = p.uuid;
		n.alter_id = p.alterId;
		n.method = p.cipher ?? 'auto';
		n.packet_encoding = truthy(p.xudp) ? 'xudp' : (p['packet-encoding'] ?? null);
		break;
	case 'vless':
		n.proto = 'vless';
		n.uuid = p.uuid;
		n.flow = p.flow;
		n.packet_encoding = p['packet-encoding'];
		n.encryption = p.encryption;
		break;
	case 'trojan':
		n.proto = 'trojan';
		n.password = '' + (p.password ?? '');
		if (n.security == '')
			n.security = 'tls';
		break;
	case 'hysteria2':
	case 'hy2':
		n.proto = 'hysteria2';
		n.password = p.password != null ? '' + p.password : null;
		n.obfs = p.obfs;
		n.obfs_password = p['obfs-password'];
		n.up = int(p.up);
		n.down = int(p.down);
		n.ports = [];
		if (p.ports != null) {
			let parts = split('' + p.ports, ',');
			for (let i = 0; i < length(parts); i++) {
				let r = trim(parts[i]);
				if (match(r, /^[0-9]+[-:][0-9]+$/))
					push(n.ports, replace(r, '-', ':'));
				else if (match(r, /^[0-9]+$/))
					push(n.ports, r + ':' + r);
			}
		}
		n.hop_interval = p['hop-interval'];
		break;
	case 'hysteria':
		n.proto = 'hysteria';
		n.auth_str = p['auth-str'] ?? p.auth_str;
		n.obfs = p.obfs;
		n.protocol = p.protocol;
		n.up = int(p.up);
		n.down = int(p.down);
		break;
	case 'tuic':
		n.proto = 'tuic';
		n.uuid = p.uuid;
		n.password = p.password;
		n.congestion = p['congestion-controller'];
		n.udp_relay_mode = p['udp-relay-mode'];
		n.disable_sni = p['disable-sni'];
		n.zero_rtt = p['reduce-rtt'];
		break;
	case 'anytls':
		n.proto = 'anytls';
		n.password = '' + (p.password ?? '');
		if (n.security != 'reality')
			n.security = 'tls';
		break;
	case 'socks5':
		n.proto = 'socks';
		n.username = p.username;
		n.password = p.password;
		break;
	case 'http':
		n.proto = 'http';
		n.username = p.username;
		n.password = p.password;
		break;
	case 'wireguard': {
		n.proto = 'wireguard';
		let addr = [];
		if (p.ip != null) push(addr, '' + p.ip);
		if (p.ipv6 != null) push(addr, '' + p.ipv6);
		n.wg = {
			private_key: p['private-key'],
			public_key: p['public-key'],
			psk: p['pre-shared-key'],
			address: addr,
			reserved: p.reserved,
			mtu: p.mtu
		};
		break;
	}
	default:
		return fail('unsupported clash proxy type: ' + t);
	}
	return n;
}

// ---------------------------------------------------------------------------
// Whole-subscription parsing
// ---------------------------------------------------------------------------

function from_singbox_json(js) {
	let res = { nodes: [], errors: [] };
	let list = [];
	if (type(js) == 'array')
		list = js;
	else if (type(js) == 'object') {
		if (type(js.outbounds) == 'array')
			list = js.outbounds;
		if (type(js.endpoints) == 'array')
			for (let i = 0; i < length(js.endpoints); i++)
				push(list, js.endpoints[i]);
		if (!length(list) && js.type != null)
			list = [ js ];
	}
	for (let i = 0; i < length(list); i++) {
		let o = list[i];
		if (type(o) != 'object' || !SB_PROXY_TYPES[o.type])
			continue;
		o = u.clone(o);
		if (o.tag == null || o.tag == '')
			o.tag = o.type + '-' + (o.server ?? i);
		delete o.detour;
		if (o.type == 'wireguard' && o.peers == null && o.server != null) {
			push(res.errors, (o.tag) + ': legacy wireguard outbound not supported');
			continue;
		}
		push(res.nodes, { outbound: o, endpoint: o.type == 'wireguard' });
	}
	return res;
}

function from_clash(doc) {
	let res = { nodes: [], errors: [] };
	let proxies = doc?.proxies;
	if (type(proxies) != 'array')
		return res;
	for (let i = 0; i < length(proxies); i++) {
		let n = clash_to_node(proxies[i]);
		if (n.error) {
			push(res.errors, (proxies[i]?.name ?? ('#' + i)) + ': ' + n.error);
			continue;
		}
		let r = build_outbound(n);
		if (r.error)
			push(res.errors, (n.name ?? ('#' + i)) + ': ' + r.error);
		else
			push(res.nodes, r);
	}
	return res;
}

// A line that is a subscription link rather than an HTTP proxy share link:
// http(s) with a path or query and neither credentials nor an explicit port.
export function is_sub_url(line) {
	let uri = parse_uri(line);
	if (!uri || (uri.scheme != 'http' && uri.scheme != 'https'))
		return false;
	if (uri.user != null && uri.user != '')
		return false;
	if (uri.port != null)
		return length(uri.path) > 1 || uri.raw_query != '';
	return true;
};

function from_lines(text) {
	let res = { nodes: [], errors: [], sub_urls: [] };
	let lines = split(replace(text, /\r/g, ''), '\n');
	for (let i = 0; i < length(lines); i++) {
		let l = trim(lines[i]);
		if (l == '' || substr(l, 0, 1) == '#' || substr(l, 0, 2) == '//')
			continue;
		if (is_sub_url(l)) {
			if (index(res.sub_urls, l) < 0)
				push(res.sub_urls, l);
			continue;
		}
		let r = parse_link(l);
		if (!r)
			continue;
		if (r.error) {
			if (r.error != 'not a link')
				push(res.errors, substr(l, 0, 48) + '...: ' + r.error);
			continue;
		}
		push(res.nodes, r);
	}
	return res;
}

// Returns { nodes: [ {outbound, endpoint} ], errors: [ string ], format }
// ---------------------------------------------------------------------------
// WireGuard configuration files (wg-quick .conf: [Interface] / [Peer])
// ---------------------------------------------------------------------------

export function is_wg_conf(text) {
	return match('' + text, /(^|\n)[ \t]*\[[Ii]nterface\][ \t]*(\r?\n|$)/) != null &&
		match('' + text, /(^|\n)[ \t]*\[[Pp]eer\]/) != null;
};

function wg_endpoint(v) {
	v = trim('' + (v ?? ''));
	let m = match(v, /^\[([^\]]+)\]:([0-9]+)$/) ?? match(v, /^([^:]+):([0-9]+)$/);
	return m ? [ m[1], int(m[2]) ] : null;
}

// One [Interface] block with its [Peer] blocks -> { outbound, endpoint } or { error }
function wg_conf_one(block, idx) {
	let iface = {}, peers = [], cur = null, name = null;
	let lines = split(replace(block, /\r/g, ''), '\n');
	for (let i = 0; i < length(lines); i++) {
		let l = trim(lines[i]);
		let nm = match(l, /^#+[ \t]*[Nn]ame[ \t]*[=:][ \t]*(.+)$/);
		if (nm) {
			name = trim(nm[1]);
			continue;
		}
		if (l == '' || substr(l, 0, 1) == '#' || substr(l, 0, 1) == ';')
			continue;
		let sec = match(l, /^\[([A-Za-z]+)\]$/);
		if (sec) {
			let t = lc(sec[1]);
			if (t == 'interface')
				cur = iface;
			else if (t == 'peer') {
				cur = {};
				push(peers, cur);
			}
			else
				cur = null;
			continue;
		}
		let kv = match(l, /^([A-Za-z0-9_]+)[ \t]*=[ \t]*(.*)$/);
		if (kv && cur != null) {
			let k = lc(kv[1]), v = trim(kv[2]);
			// several Address / AllowedIPs lines add up
			if ((k == 'address' || k == 'allowedips') && cur[k] != null)
				cur[k] += ',' + v;
			else
				cur[k] = v;
		}
	}
	let awgp = null;
	for (let i = 0; i < length(awg.AWG_KEYS); i++)
		if (iface[awg.AWG_KEYS[i]] != null && iface[awg.AWG_KEYS[i]] != '') {
			if (!awgp)
				awgp = {};
			awgp[awg.AWG_KEYS[i]] = iface[awg.AWG_KEYS[i]];
		}
	if (!iface.privatekey)
		return fail('WireGuard config without PrivateKey');
	if (!length(peers))
		return fail('WireGuard config without [Peer]');
	let p0 = peers[0];
	let ep = wg_endpoint(p0.endpoint);
	if (!ep)
		return fail('WireGuard peer without Endpoint (host:port)');
	if (name == null || name == '')
		name = (awgp ? 'AmneziaWG ' : 'WireGuard ') + ep[0] + (idx > 0 ? ' #' + (idx + 1) : '');
	let r = build_outbound({
		proto: 'wireguard', name: name, server: ep[0], port: ep[1],
		wg: {
			private_key: iface.privatekey,
			public_key: p0.publickey,
			psk: p0.presharedkey,
			address: iface.address,
			reserved: p0.reserved ?? iface.reserved,
			mtu: iface.mtu,
			keepalive: p0.persistentkeepalive
		}
	});
	if (!r.error && awgp) {
		// AmneziaWG: runs as a system interface (optional packages), not in sing-box
		let w = r.outbound;
		return { outbound: { type: 'amneziawg', tag: w.tag, private_key: w.private_key, address: w.address, mtu: w.mtu,
			peers: [ w.peers[0] ], awg: awgp } };
	}
	if (r.error || length(peers) < 2)
		return r;
	// several peers: keep each peer's AllowedIPs so traffic is split as in the file
	let out = [];
	for (let i = 0; i < length(peers); i++) {
		let p = peers[i], e = wg_endpoint(p.endpoint);
		if (!p.publickey || !e)
			continue;
		let pr = { address: e[0], port: e[1], public_key: p.publickey, allowed_ips: csv(p.allowedips ?? '0.0.0.0/0, ::/0') };
		if (p.presharedkey)
			pr.pre_shared_key = p.presharedkey;
		if (u.toint(p.persistentkeepalive, 0) > 0)
			pr.persistent_keepalive_interval = u.toint(p.persistentkeepalive, 0);
		push(out, pr);
	}
	r.outbound.peers = out;
	return r;
}

// One or more wg-quick configurations (pasted one after another)
function from_wg_conf(text) {
	let res = { nodes: [], errors: [] };
	let parts = [];
	let lines = split(replace('' + text, /\r/g, ''), '\n');
	let cur = [];
	for (let i = 0; i < length(lines); i++) {
		if (match(trim(lines[i]), /^\[[Ii]nterface\]$/) && length(filter(cur, (l) => match(trim(l), /^\[[Ii]nterface\]$/)))) {
			push(parts, join('\n', cur));
			cur = [];
		}
		push(cur, lines[i]);
	}
	push(parts, join('\n', cur));
	for (let i = 0; i < length(parts); i++) {
		let r = wg_conf_one(parts[i], i);
		if (r.error)
			push(res.errors, 'WireGuard config ' + (i + 1) + ': ' + r.error);
		else
			push(res.nodes, r);
	}
	return res;
}

// ---------------------------------------------------------------------------
// OpenVPN client files (.ovpn) -> sing-box "openvpn-client" endpoint (1.14+)
// ---------------------------------------------------------------------------

export function is_ovpn(text) {
	text = '' + text;
	return match(text, /(^|\n)[ \t]*remote[ \t]+[^ \t\r\n]+/) != null &&
		(index(text, '<ca>') >= 0 || match(text, /(^|\n)[ \t]*(client|tls-client|dev[ \t]+tun[0-9]*|ca[ \t]+[^ \t\r\n]+)[ \t]*(\r?\n|$)/) != null);
};

function ovpn_net(p) {
	p = lc('' + (p ?? ''));
	if (substr(p, 0, 3) == 'tcp')
		return 'tcp';
	if (substr(p, 0, 3) == 'udp')
		return 'udp';
	return null;
}

function ovpn_secs(v) {
	let n = u.toint(v, -1);
	return n >= 0 ? n + 's' : null;
}

function ovpn_pem(v) {
	return filter(map(split(replace('' + v, /\r/g, ''), '\n'), (l) => trim(l)), (l) => l != '');
}

function from_ovpn(text) {
	text = replace('' + text, /\r/g, '');
	let blocks = {};
	let rest = [];
	let lines = split(text, '\n');
	let name = null;
	for (let i = 0; i < length(lines); i++) {
		let l = trim(lines[i]);
		let bm = match(l, /^<([a-z0-9-]+)>$/);
		if (bm) {
			let body = [];
			let j = i + 1;
			for (; j < length(lines) && trim(lines[j]) != '</' + bm[1] + '>'; j++)
				push(body, lines[j]);
			blocks[bm[1]] = join('\n', body);
			i = j;
			continue;
		}
		let nm = match(l, /^#+[ \t]*[Nn]ame[ \t]*[=:][ \t]*(.+)$/);
		if (nm)
			name = trim(nm[1]);
		if (l == '' || substr(l, 0, 1) == '#' || substr(l, 0, 1) == ';')
			continue;
		push(rest, l);
	}

	let opt = {};		// last value of each directive (arguments)
	let remotes = [];
	let proto = null, port = 1194;
	for (let i = 0; i < length(rest); i++) {
		let w = filter(split(rest[i], /[ \t]+/), (x) => x != '');
		let k = lc(w[0]);
		let args = slice(w, 1);
		if (k == 'remote')
			push(remotes, args);
		else
			opt[k] = args;
		if (k == 'proto')
			proto = ovpn_net(args[0]);
		if (k == 'port' || k == 'rport')
			port = u.toint(args[0], port);
	}

	if (opt['dev'] && match(lc(opt['dev'][0] ?? ''), /^tap/))
		return fail('OpenVPN: "dev tap" (layer 2) is not supported by sing-box, only "dev tun"');
	if (opt['secret'] || blocks['secret'])
		return fail('OpenVPN: static-key ("secret") configurations are not supported here');
	if (opt['pkcs12'] || blocks['pkcs12'])
		return fail('OpenVPN: PKCS#12 files are not supported; export the profile with inline <ca>, <cert> and <key>');
	if (!length(remotes))
		return fail('OpenVPN: no "remote" line');
	let ca = blocks['ca'];
	if (!ca)
		return fail(opt['ca'] ? 'OpenVPN: the CA is a separate file (' + opt['ca'][0] + '); use a profile with the certificates inline (<ca>…</ca>)' : 'OpenVPN: no CA certificate (<ca>)');
	if (!blocks['cert'] && opt['cert'])
		return fail('OpenVPN: the client certificate is a separate file; use a profile with <cert> and <key> inline');

	let servers = [];
	for (let i = 0; i < length(remotes); i++) {
		let r = remotes[i];
		let sp = u.toint(r[1], port);
		let net = ovpn_net(r[2]) ?? proto ?? 'udp';
		if (r[0] && u.valid_port(sp))
			push(servers, { server: r[0], server_port: sp, network: net });
	}
	if (!length(servers))
		return fail('OpenVPN: no valid "remote" server');

	let o = { type: 'openvpn-client', tag: name ?? ('OpenVPN ' + servers[0].server), system: false };
	if (length(servers) == 1) {
		o.server = servers[0].server;
		o.server_port = servers[0].server_port;
		o.network = servers[0].network;
	}
	else {
		o.servers = servers;
		o.network = proto ?? 'udp';
		if (opt['remote-random'])
			o.remote_random = true;
	}

	let tls = { certificate: ovpn_pem(ca) };
	if (blocks['cert'])
		tls.client_certificate = ovpn_pem(blocks['cert']);
	if (blocks['key'])
		tls.client_key = ovpn_pem(blocks['key']);
	if (opt['verify-x509-name']) {
		let v = opt['verify-x509-name'];
		tls.server_name = v[0];
		let t = lc(v[1] ?? '');
		// OpenVPN's default type is the full subject
		tls.server_name_type = (t == 'name' || t == 'name-prefix') ? t : 'subject';
	}
	if (opt['remote-cert-tls'])
		tls.remote_certificate_tls = opt['remote-cert-tls'][0];
	if (opt['tls-version-min'])
		tls.version_min = opt['tls-version-min'][0];
	if (opt['tls-cipher'])
		tls.cipher = opt['tls-cipher'][0];
	let kd = opt['key-direction'] ? opt['key-direction'][0] : null;
	if (blocks['tls-crypt-v2'])
		tls.control_wrap = { type: 'tls_crypt_v2', key: ovpn_pem(blocks['tls-crypt-v2']) };
	else if (blocks['tls-crypt'])
		tls.control_wrap = { type: 'tls_crypt', key: ovpn_pem(blocks['tls-crypt']) };
	else if (blocks['tls-auth']) {
		tls.control_wrap = { type: 'tls_auth', key: ovpn_pem(blocks['tls-auth']) };
		if (kd == '1')
			tls.control_wrap.direction = 'client';
		else if (kd == '0')
			tls.control_wrap.direction = 'server';
	}
	else if (opt['tls-auth'] || opt['tls-crypt'])
		return fail('OpenVPN: the tls-auth / tls-crypt key is a separate file; use a profile with the key inline');
	o.tls = tls;

	if (opt['data-ciphers'])
		o.data_ciphers = split(opt['data-ciphers'][0], ':');
	else if (opt['ncp-ciphers'])
		o.data_ciphers = split(opt['ncp-ciphers'][0], ':');
	if (opt['cipher'])
		o.data_ciphers_fallback = opt['cipher'][0];
	if (opt['data-ciphers-fallback'])
		o.data_ciphers_fallback = opt['data-ciphers-fallback'][0];
	if (opt['auth'])
		o.auth = opt['auth'][0];

	// compression: framing only (sing-box never compresses outgoing data)
	if (opt['comp-lzo'])
		o.compression_lzo = length(opt['comp-lzo']) ? lc(opt['comp-lzo'][0]) : 'adaptive';
	if (opt['compress'])
		o.compression = length(opt['compress']) ? lc(opt['compress'][0]) : 'stub';
	if (opt['comp-lzo'] || opt['compress'])
		o.allow_compression = 'asym';

	if (opt['mssfix'] && u.toint(opt['mssfix'][0], 0) > 0)
		o.mss_fix = u.toint(opt['mssfix'][0], 0);
	if (opt['fragment'] && u.toint(opt['fragment'][0], 0) >= 68)
		o.fragment = u.toint(opt['fragment'][0], 0);
	if (opt['tun-mtu'] && u.toint(opt['tun-mtu'][0], 0) > 0)
		o.mtu = u.toint(opt['tun-mtu'][0], 0);
	if (opt['ping'])
		o.ping_interval = ovpn_secs(opt['ping'][0]);
	if (opt['ping-restart'])
		o.ping_restart = ovpn_secs(opt['ping-restart'][0]);
	if (opt['reneg-sec']) {
		if (u.toint(opt['reneg-sec'][0], -1) == 0)
			o.renegotiate_disabled = true;
		else
			o.renegotiate_interval = ovpn_secs(opt['reneg-sec'][0]);
	}
	// the whole node is used as one outbound: send everything through it
	o.redirect_gateway = true;

	if (opt['auth-user-pass'] != null) {
		let up = blocks['auth-user-pass'];
		let creds = up ? filter(map(split(up, '\n'), (l) => trim(l)), (l) => l != '') : [];
		if (length(creds) < 2)
			return fail('OpenVPN: this profile needs a username and password (auth-user-pass)');
		o.username = creds[0];
		o.password = creds[1];
	}
	for (let k in o)
		if (o[k] == null)
			delete o[k];
	return { outbound: o, endpoint: true };
}

function parse_content_inner(text) {
	if (text == null)
		return { nodes: [], errors: [ 'empty content' ], format: null };
	text = trim('' + text);
	// strip UTF-8 BOM
	if (substr(text, 0, 3) == '\xef\xbb\xbf')
		text = substr(text, 3);
	if (text == '')
		return { nodes: [], errors: [ 'empty content' ], format: null };

	let c = substr(text, 0, 1);
	if (c == '{' || c == '[') {
		let js = null;
		try { js = json(text); } catch (e) { js = null; }
		if (js != null && xray.is_xray_json(js)) {
			let r = xray.from_json(js);
			r.format = 'xray';
			return r;
		}
		if (js != null) {
			let r = from_singbox_json(js);
			r.format = 'sing-box';
			// a complete configuration (routing / DNS / inbounds), not just a node list
			r.full_config = type(js) == 'object' && (type(js.route) == 'object' || type(js.dns) == 'object' || type(js.inbounds) == 'array');
			return r;
		}
	}

	if (is_ovpn(text)) {
		let r = from_ovpn(text);
		return r.error ? { nodes: [], errors: [ r.error ], format: 'openvpn' } : { nodes: [ r ], errors: [], format: 'openvpn' };
	}
	if (is_wg_conf(text)) {
		let r = from_wg_conf(text);
		r.format = 'wireguard';
		return r;
	}

	if (match(text, /(^|\n)proxies:/)) {
		let doc = null;
		try { doc = parse_yaml(text); } catch (e) { doc = null; }
		if (doc) {
			let r = from_clash(doc);
			r.format = 'clash';
			return r;
		}
	}

	if (!match(text, /[a-zA-Z0-9]:\/\//)) {
		let dec = u.b64d(text);
		if (dec != null && match(dec, /[a-zA-Z0-9]:\/\//)) {
			let r = from_lines(dec);
			r.format = 'base64';
			return r;
		}
	}

	let r = from_lines(text);
	r.format = 'links';
	return r;
};

// Make tags unique; `taken` is an object used across calls.
export function unique_tag(tag, taken) {
	tag = trim(replace('' + (tag ?? 'node'), /[\r\n\t]+/g, ' '));
	if (tag == '')
		tag = 'node';
	let base = tag;
	let i = 2;
	while (taken[tag])
		tag = base + ' (' + (i++) + ')';
	taken[tag] = true;
	return tag;
};

// One share link with a chosen core: 'auto' | 'xray' | 'singbox'
export function parse_link_core(line, core) {
	let prev = PARSE.core;
	PARSE.core = (core == 'xray' || core == 'singbox') ? core : 'auto';
	let r = parse_link(line);
	PARSE.core = prev;
	if (core == 'singbox' && r?.outbound?.type == 'xray')
		return fail('needs the Xray core (Core is set to sing-box)');
	return r;
};

// Returns { nodes: [ {outbound, endpoint} ], errors: [ string ], format, ... }
// opts.core: 'auto' (default) | 'xray' | 'singbox'
export function parse_content(text, opts) {
	let prev = PARSE.core;
	let core = opts?.core ?? 'auto';
	PARSE.core = (core == 'xray' || core == 'singbox') ? core : 'auto';
	let r = parse_content_inner(text);
	if (PARSE.core == 'singbox') {
		let keep = [];
		for (let i = 0; i < length(r.nodes); i++) {
			if (r.nodes[i].outbound?.type == 'xray')
				push(r.errors, (r.nodes[i].outbound.tag ?? '?') + ': needs the Xray core (Core is set to sing-box)');
			else
				push(keep, r.nodes[i]);
		}
		r.nodes = keep;
	}
	PARSE.core = prev;
	return r;
};
