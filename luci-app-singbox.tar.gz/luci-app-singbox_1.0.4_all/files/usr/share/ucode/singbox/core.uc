// SPDX-License-Identifier: LicenseRef-Proprietary
// Copyright (C) 2026 Danial Rostamani. All rights reserved. See LICENSE.
// luci-app-singbox - runtime operations shared by singbox-ctl and rpcd

import { readfile, writefile, stat, lsdir, unlink, rename, access, chmod } from 'fs';
import { cursor } from 'uci';
import * as ubus from 'ubus';
import * as u from 'singbox.util';
import * as parser from 'singbox.parser';
import * as gen from 'singbox.gen';
import * as xray from 'singbox.xray';
import * as awg from 'singbox.awg';

export const UA_DEFAULT = 'v2rayNG/1.9.30';
export const PROFILE_UA = 'sing-box/1.13.0 (SFA)';
export const CTL = '/usr/bin/singbox-ctl';

// ---------------------------------------------------------------------------
// Service / process state
// ---------------------------------------------------------------------------

export function service_status() {
	let st = { running: false, pid: null, enabled: false };
	let conn = ubus.connect();
	if (conn) {
		let res = conn.call('service', 'list', { name: 'singbox' });
		let inst = res?.singbox?.instances?.singbox;
		if (inst?.running) {
			st.running = true;
			st.pid = inst.pid;
		}
	}
	let c = cursor();
	c.load(u.PKG);
	st.enabled = u.bool(c.get(u.PKG, 'main', 'enabled'), false);
	return st;
};

// CPU ticks (utime + stime) of a process, or null
function proc_ticks(pid) {
	let stt = pid ? readfile('/proc/' + pid + '/stat') : null;
	if (!stt)
		return null;
	let f = split(trim(substr(stt, rindex(stt, ')') + 2)), ' ');
	return int(f[11]) + int(f[12]);
}

// Live CPU use since the previous call (the overview polls every few
// seconds): sing-box, the Xray sidecar and the whole router, in percent of
// all cores together (like top). The last sample is kept in /var/run.
function cpu_usage(pid) {
	let line = match(readfile('/proc/stat') ?? '', /^cpu[ \t]+([^\n]+)/);
	if (!line)
		return {};
	let v = map(split(trim(line[1]), /[ \t]+/), (x) => int(x));
	let total = 0;
	for (let i = 0; i < length(v) && i < 8; i++)
		total += v[i];
	let idle = (v[3] ?? 0) + (v[4] ?? 0);
	let xpid = int(trim(u.exec('pidof xray').out) || '0');
	let cur = { t: total, i: idle, pid: pid, p: proc_ticks(pid), xpid: xpid, x: proc_ticks(xpid) };
	let f = u.RUN_DIR + '/cpu-sample.json';
	let prev = u.readjson(f);
	u.mkdirp(u.RUN_DIR);
	u.writejson(f, cur);
	let cores = length(filter(split(readfile('/proc/cpuinfo') ?? '', '\n'), (l) => match(l, /^processor[ \t]*:/)));
	let r = { cpu_cores: cores > 0 ? cores : null };
	let dt = prev ? total - prev.t : 0;
	if (!prev || dt <= 0)
		return r;
	let pct = (d) => int(d * 1000 / dt) / 10;
	r.cpu_system = pct(dt - (idle - prev.i));
	if (cur.p != null && prev.pid == pid && prev.p != null)
		r.cpu = pct(cur.p - prev.p);
	if (cur.x != null && prev.xpid == xpid && prev.x != null)
		r.cpu_xray = pct(cur.x - prev.x);
	return r;
}

export function proc_info(pid) {
	if (!pid)
		return null;
	let s = readfile('/proc/' + pid + '/status');
	if (!s)
		return null;
	let rss = match(s, /VmRSS:[ \t]*([0-9]+)/);
	let st = stat('/proc/' + pid);
	let up = readfile('/proc/uptime');
	let stt = readfile('/proc/' + pid + '/stat');
	let uptime = null;
	if (up && stt) {
		// field 22 = starttime (clock ticks)
		let rp = rindex(stt, ')');
		let f = split(trim(substr(stt, rp + 2)), ' ');
		let start = int(f[19]);
		let sys_up = int(split(up, '.')[0]);
		if (start > 0)
			uptime = sys_up - int(start / 100);
	}
	let r = { rss_kb: rss ? int(rss[1]) : null, uptime: uptime };
	// router memory: used = total - available
	let mi = readfile('/proc/meminfo') ?? '';
	let mt = match(mi, /MemTotal:[ \t]*([0-9]+)/), ma = match(mi, /MemAvailable:[ \t]*([0-9]+)/);
	if (mt && ma) {
		r.mem_total_kb = int(mt[1]);
		r.mem_used_kb = int(mt[1]) - int(ma[1]);
	}
	let cpu = cpu_usage(pid);
	for (let k in cpu)
		r[k] = cpu[k];
	return r;
};

// ---------------------------------------------------------------------------
// HTTP downloads (curl)
// ---------------------------------------------------------------------------

function mixed_proxy(conf) {
	let st = service_status();
	if (!st.running)
		return null;
	return 'socks5h://127.0.0.1:' + u.toint(conf.main?.mixed_port, 2080);
}

function apply_mirror(conf, url) {
	let m = conf.route?.github_mirror;
	if (m == null || m == '')
		return url;
	if (substr(url, 0, 34) == gen.GITHUB_RAW || substr(url, 0, 19) == 'https://github.com/')
		return (substr(m, -1) == '/' ? m : m + '/') + url;
	return url;
}

// how: 'auto' (direct, then via proxy), 'direct', 'proxy'
export function download(conf, url, out, opts) {
	opts = opts ?? {};
	let how = opts.via ?? 'auto';
	let hdr = opts.headers_file;
	let attempts = [];
	let px = (how == 'direct') ? null : mixed_proxy(conf);
	if (how == 'proxy') {
		if (!px)
			return { ok: false, error: 'service not running, cannot download through proxy' };
		push(attempts, px);
	}
	else if (how == 'direct')
		push(attempts, null);
	else {
		push(attempts, null);
		if (px)
			push(attempts, px);
	}

	let last = '';
	for (let i = 0; i < length(attempts); i++) {
		let p = attempts[i];
		let target = p ? url : apply_mirror(conf, url);
		let cmd = 'curl -fsSL --compressed --connect-timeout 10 --retry 1 -m ' + (opts.timeout ?? 60);
		cmd += ' -A ' + u.shq(opts.ua ?? UA_DEFAULT);
		if (p)
			cmd += ' -x ' + u.shq(p);
		if (hdr)
			cmd += ' -D ' + u.shq(hdr);
		cmd += ' -o ' + u.shq(out) + ' ' + u.shq(target);
		let r = u.exec(cmd);
		if (r.code == 0 && stat(out)?.size > 0)
			return { ok: true, via: p ? 'proxy' : 'direct' };
		last = trim(r.out) || ('curl exit ' + r.code);
	}
	u.remove(out);
	return { ok: false, error: last };
};

// ---------------------------------------------------------------------------
// Nodes
// ---------------------------------------------------------------------------

function keyword_match(name, expr) {
	if (expr == null || expr == '')
		return false;
	let parts = split(lc(expr), '|');
	let n = lc(name);
	for (let i = 0; i < length(parts); i++) {
		let p = trim(parts[i]);
		if (p != '' && index(n, p) >= 0)
			return true;
	}
	return false;
}

export function sub_file(id) {
	return u.SUB_DIR + '/' + id + '.json';
};

// Returns [ { outbound, endpoint, source, source_name, error? } ] with unique tags
export function collect_nodes(conf, include_disabled) {
	let res = [];
	let taken = { direct: true, proxy: true, auto: true, block: true };

	for (let i = 0; i < length(conf.nodes); i++) {
		let n = conf.nodes[i];
		let enabled = u.bool(n.enabled, true);
		if (!enabled && !include_disabled)
			continue;
		let r = null;
		if (n.json != null && n.json != '') {
			let js = null;
			try { js = json(n.json); } catch (e) { js = null; }
			if (type(js) == 'object' && js.type != null) {
				r = { outbound: js, endpoint: js.type == 'wireguard' || js.type == 'openvpn-client' };
			}
			else
				r = { error: 'invalid JSON' };
		}
		else if (n.link != null && n.link != '')
			r = parser.parse_link_core(n.link, n.core) ?? { error: 'empty link' };
		else
			r = { error: 'empty node' };

		if (r.error) {
			if (include_disabled)
				push(res, { error: r.error, source: 'manual', id: n.id, name: n.name, enabled: enabled });
			continue;
		}
		let o = r.outbound;
		if (n.name != null && n.name != '')
			o.tag = n.name;
		o.tag = parser.unique_tag(o.tag, taken);
		push(res, { outbound: o, endpoint: !!r.endpoint, source: 'manual', id: n.id, enabled: enabled });
	}

	for (let i = 0; i < length(conf.subs); i++) {
		let s = conf.subs[i];
		if (!u.bool(s.enabled, true) && !include_disabled)
			continue;
		let data = u.readjson(sub_file(s.id));
		if (!data || type(data.nodes) != 'array')
			continue;
		let prefix = (s.prefix != null && s.prefix != '') ? s.prefix + ' ' : '';
		for (let j = 0; j < length(data.nodes); j++) {
			let e = data.nodes[j];
			let o = e.outbound;
			if (type(o) != 'object')
				continue;
			let name = o.tag ?? '';
			if (s.include != null && s.include != '' && !keyword_match(name, s.include))
				continue;
			if (keyword_match(name, s.exclude))
				continue;
			// Core set to sing-box after the last update: leave Xray nodes out
			if (s.core == 'singbox' && o.type == 'xray')
				continue;
			o.tag = parser.unique_tag(prefix + name, taken);
			push(res, {
				outbound: o,
				endpoint: !!e.endpoint,
				source: 'sub',
				id: s.id,
				source_name: s.name ?? s.id,
				enabled: u.bool(s.enabled, true)
			});
		}
	}
	return res;
};

export function node_summary(n) {
	let o = n.outbound ?? {};
	let tls = o.tls?.enabled ? (o.tls?.reality?.enabled ? 'reality' : 'tls') : '';
	let server = o.server;
	let port = o.server_port;
	if (o.type == 'openvpn-client' && server == null && length(o.servers ?? [])) {
		server = o.servers[0].server;
		port = o.servers[0].server_port;
	}
	if ((n.endpoint || o.type == 'amneziawg') && type(o.peers) == 'array' && length(o.peers)) {
		server = o.peers[0].address;
		port = o.peers[0].port;
	}
	let transport = o.transport?.type ?? '';
	if (o.type == 'xray') {
		transport = o.xray_net ?? '';
		tls = (o.xray_sec == 'none') ? '' : (o.xray_sec ?? '');
	}
	return {
		tag: o.tag,
		type: (o.type == 'xray') ? 'xray:' + (o.xray?.protocol ?? '?') : o.type,
		server: server,
		port: port,
		transport: transport,
		tls: tls,
		source: n.source,
		source_id: n.id,
		source_name: n.source_name,
		enabled: n.enabled,
		error: n.error
	};
};

// ---------------------------------------------------------------------------
// Subscriptions
// ---------------------------------------------------------------------------

function parse_userinfo(hdrs) {
	let info = {};
	let lines = split(replace(hdrs ?? '', /\r/g, ''), '\n');
	for (let i = 0; i < length(lines); i++) {
		let l = lines[i];
		let c = index(l, ':');
		if (c < 0)
			continue;
		let k = lc(trim(substr(l, 0, c)));
		let v = trim(substr(l, c + 1));
		if (k == 'subscription-userinfo') {
			let parts = split(v, ';');
			for (let j = 0; j < length(parts); j++) {
				let kv = split(trim(parts[j]), '=');
				if (length(kv) == 2 && match(trim(kv[1]), /^[0-9]+$/))
					info[trim(kv[0])] = int(trim(kv[1]));
			}
		}
		else if (k == 'profile-title') {
			if (substr(v, 0, 7) == 'base64:')
				v = u.b64d(substr(v, 7)) ?? v;
			info.title = v;
		}
		else if (k == 'profile-update-interval' && match(v, /^[0-9]+$/))
			info.update_interval = int(v);
		else if (k == 'profile-web-page-url')
			info.web = v;
	}
	return info;
}

// sing-box://import-remote-profile?url=<encoded>#name  ->  the inner URL
export function deep_link_url(url) {
	let m = match('' + (url ?? ''), /^sing-box:\/\/import-remote-profile\?(.*)$/);
	if (!m)
		return url;
	let q = split(m[1], '#')[0];
	let qs = u.parse_qs(q);
	return qs.url ?? url;
};

function sub_err_file(id) {
	return u.SUB_DIR + '/' + id + '.err.json';
}

// Remember why the last update failed so the UI can show it.
function sub_fail(id, msg, errors) {
	u.mkdirp(u.SUB_DIR);
	u.writejson(sub_err_file(id), { error: msg, errors: errors ?? [], checked: time() });
	return { ok: false, error: msg, errors: errors ?? [] };
}

export function sub_update(conf, id) {
	let s = null;
	for (let i = 0; i < length(conf.subs); i++)
		if (conf.subs[i].id == id)
			s = conf.subs[i];
	if (!s)
		return { ok: false, error: 'subscription not found: ' + id };
	u.mkdirp(u.SUB_DIR);
	u.mkdirp(u.RUN_DIR);
	let body, headers = null;
	let dl = { via: 'local' };

	if ((s.source ?? 'url') == 'paste') {
		// pasted share links / base64 / Clash YAML / sing-box JSON
		body = s.content;
		if (type(body) == 'array')
			body = join('\n', body);
		if (body == null || trim(body) == '')
			return sub_fail(id, 'no content pasted');
	}
	else {
		if (s.url == null || s.url == '')
			return sub_fail(id, 'no URL');
		let url = deep_link_url(s.url);
		let tmp = u.RUN_DIR + '/sub-' + id + '.raw';
		let hdr = u.RUN_DIR + '/sub-' + id + '.hdr';
		dl = download(conf, url, tmp, { via: s.via ?? 'auto', ua: s.user_agent ?? UA_DEFAULT, headers_file: hdr, timeout: 45 });
		if (!dl.ok) {
			u.remove(hdr);
			return sub_fail(id, 'download failed: ' + dl.error);
		}
		body = readfile(tmp);
		headers = readfile(hdr);
		u.remove(tmp);
		u.remove(hdr);
	}

	let r = parser.parse_content(body, { core: s.core });

	// "multi" subscriptions list further subscription links: fetch and merge
	let nested = r.sub_urls ?? [];
	for (let i = 0; i < length(nested) && i < 20; i++) {
		let ntmp = u.RUN_DIR + '/sub-' + id + '-' + i + '.raw';
		let ndl = download(conf, nested[i], ntmp, { via: s.via ?? 'auto', ua: s.user_agent ?? UA_DEFAULT, timeout: 45 });
		if (!ndl.ok) {
			push(r.errors, substr(nested[i], 0, 48) + '...: download failed: ' + ndl.error);
			continue;
		}
		let nr = parser.parse_content(readfile(ntmp), { core: s.core });
		u.remove(ntmp);
		for (let j = 0; j < length(nr.nodes); j++)
			push(r.nodes, nr.nodes[j]);
		for (let j = 0; j < length(nr.errors); j++)
			push(r.errors, nr.errors[j]);
		if (!length(nr.nodes) && !length(nr.errors))
			push(r.errors, substr(nested[i], 0, 48) + '...: no nodes (format: ' + (nr.format ?? '?') + ')');
		if (nr.full_config)
			r.full_config = true;
	}
	if (length(nested))
		r.format = (r.format ?? 'links') + ' + ' + length(nested) + ' linked subscription(s)';

	if (!length(r.nodes)) {
		let hint = '';
		if (length(body ?? '') > 0 && !length(r.errors) && !length(nested))
			hint = ' - the server returned: ' + substr(replace(trim(body), /[\r\n\t]+/g, ' '), 0, 120);
		return sub_fail(id, 'no usable nodes (format: ' + (r.format ?? '?') + ')' + hint, slice(r.errors, 0, 20));
	}

	let data = {
		updated: time(),
		format: r.format,
		full_config: !!r.full_config,
		via: dl.via,
		info: parse_userinfo(headers),
		errors: slice(r.errors, 0, 50),
		nodes: r.nodes
	};
	u.remove(sub_err_file(id));
	if (!u.writejson(sub_file(id), data))
		return { ok: false, error: 'cannot write ' + sub_file(id) };
	return { ok: true, count: length(r.nodes), skipped: length(r.errors), via: dl.via, format: r.format, full_config: !!r.full_config };
};

export function sub_update_all(conf, enabled_only) {
	let out = {};
	for (let i = 0; i < length(conf.subs); i++) {
		let s = conf.subs[i];
		if (enabled_only && !u.bool(s.enabled, true))
			continue;
		out[s.id] = sub_update(conf, s.id);
	}
	return out;
};

export function sub_info(id) {
	let d = u.readjson(sub_file(id));
	let e = u.readjson(sub_err_file(id));
	if (!d)
		return e ? { count: 0, error: e.error, errors: slice(e.errors ?? [], 0, 10), checked: e.checked } : null;
	return {
		updated: d.updated,
		format: d.format,
		count: length(d.nodes ?? []),
		skipped: length(d.errors ?? []),
		errors: slice(d.errors ?? [], 0, 10),
		info: d.info ?? {},
		full_config: !!d.full_config,
		error: (e && e.checked >= d.updated) ? e.error : null
	};
};

// ---------------------------------------------------------------------------
// Rule-sets
// ---------------------------------------------------------------------------

export function rs_status(conf) {
	let want = gen.required_rulesets(conf);
	let out = [];
	for (let tag in want) {
		let e = want[tag];
		let st = stat(e.file);
		push(out, { tag: tag, url: e.url, kind: e.kind, file: e.file, size: st?.size, mtime: st?.mtime });
	}
	return out;
};

function valid_ruleset_file(conf, e, path) {
	if (e.format == 'source') {
		let js = u.readjson(path);
		return type(js) == 'object' && type(js.rules) == 'array';
	}
	// binary rule-set: magic "SRS"
	let head = readfile(path, 3);
	return head == 'SRS';
}

export function rs_update(conf, only_tag) {
	let want = gen.required_rulesets(conf);
	u.mkdirp(u.RS_DIR);
	let res = {};
	for (let tag in want) {
		if (only_tag != null && only_tag != 'all' && only_tag != tag)
			continue;
		let e = want[tag];
		let tmp = e.file + '.dl';
		let dl = download(conf, e.url, tmp, { via: conf.route?.ruleset_via ?? 'auto', timeout: 120 });
		if (!dl.ok) {
			res[tag] = { ok: false, error: dl.error };
			continue;
		}
		if (!valid_ruleset_file(conf, e, tmp)) {
			u.remove(tmp);
			res[tag] = { ok: false, error: 'downloaded file is not a valid rule-set' };
			continue;
		}
		rename(tmp, e.file);
		res[tag] = { ok: true, via: dl.via, size: stat(e.file)?.size };
	}
	return res;
};

export function rs_missing(conf) {
	let want = gen.required_rulesets(conf);
	let miss = [];
	for (let tag in want)
		if (!stat(want[tag].file))
			push(miss, tag);
	return miss;
};

// ---------------------------------------------------------------------------
// Runtime context & generation
// ---------------------------------------------------------------------------

export function wan_dns() {
	let out = [];
	let files = [ '/tmp/resolv.conf.d/resolv.conf.auto', '/tmp/resolv.conf.auto' ];
	for (let f = 0; f < length(files); f++) {
		let s = readfile(files[f]);
		if (!s)
			continue;
		let lines = split(s, '\n');
		for (let i = 0; i < length(lines); i++) {
			let m = match(lines[i], /^nameserver[ \t]+([0-9A-Fa-f:.]+)/);
			if (m && index(out, m[1]) < 0)
				push(out, m[1]);
		}
		if (length(out))
			break;
	}
	return out;
};

export function lan_devices(conf) {
	let ifs = u.flatlist(conf.main?.lan_interfaces);
	if (!length(ifs))
		ifs = [ 'lan' ];
	let devs = [];
	let conn = ubus.connect();
	for (let i = 0; i < length(ifs); i++) {
		let st = conn ? conn.call('network.interface.' + ifs[i], 'status', {}) : null;
		let d = st?.l3_device ?? st?.device;
		if (d == null) {
			// fall back to UCI device / bridge name
			let c = cursor();
			c.load('network');
			d = c.get('network', ifs[i], 'device');
		}
		if (d != null && index(devs, d) < 0)
			push(devs, d);
	}
	return devs;
};

export function build_ctx(conf) {
	let bin = u.core_path(conf.main);
	let ver = u.core_version(bin);
	let nodes = collect_nodes(conf, false);
	let rs = {};
	let want = gen.required_rulesets(conf);
	for (let tag in want)
		if (stat(want[tag].file)?.size > 0)
			rs[tag] = true;
	return {
		bin: bin,
		ver: ver,
		nodes: nodes,
		resolv: wan_dns(),
		lan_devs: lan_devices(conf),
		rulesets: rs
	};
};

export function check_config(bin, path) {
	let r = u.exec(u.shq(bin) + ' check -c ' + u.shq(path) + ' -D ' + u.shq(u.WORK_DIR));
	return { ok: r.code == 0, output: replace(trim(r.out), /\x1b\[[0-9;]*m/g, '') };
};

const RESERVED_TAGS = { direct: true, proxy: true, auto: true };
const NON_NODE_TYPES = { selector: true, urltest: true, direct: true, block: true, dns: true };

// Map a "sing-box check" error to the tag of the node that caused it.
function quarantine_target(cfg, msg) {
	let m = match(msg, /outbounds?\[([0-9]+)\]/);
	let list = cfg.outbounds;
	if (!m) {
		m = match(msg, /endpoints?\[([0-9]+)\]/);
		list = cfg.endpoints;
	}
	if (!m || type(list) != 'array')
		return null;
	let o = list[int(m[1])];
	if (!o || !o.tag || RESERVED_TAGS[o.tag] || NON_NODE_TYPES[o.type])
		return null;
	return o.tag;
}

function ensure_direct(cfg) {
	for (let i = 0; i < length(cfg.outbounds); i++)
		if (cfg.outbounds[i].type == 'direct' && cfg.outbounds[i].tag != null)
			return cfg.outbounds[i].tag;
	push(cfg.outbounds, { type: 'direct', tag: 'direct' });
	return 'direct';
}

function fix_rule_refs(rules, gone, fb) {
	for (let i = 0; i < length(rules ?? []); i++) {
		if (gone[rules[i]?.outbound])
			rules[i].outbound = fb;
		if (type(rules[i]?.rules) == 'array')
			fix_rule_refs(rules[i].rules, gone, fb);
	}
}

function drop_node(cfg, tag) {
	cfg.outbounds = filter(cfg.outbounds, (o) => o.tag != tag);
	if (type(cfg.endpoints) == 'array') {
		cfg.endpoints = filter(cfg.endpoints, (o) => o.tag != tag);
		if (!length(cfg.endpoints))
			delete cfg.endpoints;
	}

	// remove from groups; drop groups that became empty (repeat for nesting)
	let gone = {};
	gone[tag] = true;
	for (let pass = 0; pass < 5; pass++) {
		let emptied = [];
		for (let i = 0; i < length(cfg.outbounds); i++) {
			let o = cfg.outbounds[i];
			if (o.type != 'selector' && o.type != 'urltest')
				continue;
			o.outbounds = filter(o.outbounds ?? [], (t) => !gone[t]);
			if (o.default != null && gone[o.default])
				delete o.default;
			if (!length(o.outbounds))
				push(emptied, o);
		}
		if (!length(emptied))
			break;
		for (let i = 0; i < length(emptied); i++) {
			let o = emptied[i];
			// the main selector must survive: point it at direct
			if (o.tag == 'proxy' || o.tag == cfg.route?.final)
				o.outbounds = [ ensure_direct(cfg) ];
			else {
				gone[o.tag] = true;
				cfg.outbounds = filter(cfg.outbounds, (x) => x.tag != o.tag);
			}
		}
	}

	// references to removed tags fall back to the final outbound
	let fb = cfg.route?.final;
	if (fb == null || gone[fb])
		fb = gen.main_group(cfg) ?? ensure_direct(cfg);
	fix_rule_refs(cfg.route?.rules, gone, fb);
	if (cfg.route && gone[cfg.route.final])
		cfg.route.final = fb;
	for (let i = 0; i < length(cfg.outbounds); i++)
		if (gone[cfg.outbounds[i].detour])
			delete cfg.outbounds[i].detour;
	for (let i = 0; i < length(cfg.dns?.servers ?? []); i++)
		if (gone[cfg.dns.servers[i].detour])
			delete cfg.dns.servers[i].detour;
	for (let i = 0; i < length(cfg.route?.rule_set ?? []); i++)
		if (gone[cfg.route.rule_set[i].download_detour])
			delete cfg.route.rule_set[i].download_detour;
}

// ---------------------------------------------------------------------------
// Xray sidecar
// ---------------------------------------------------------------------------

function build_ctx_light() {
	return { resolv: wan_dns() };
}

function xray_opts(conf, ctx) {
	let mode = u.inbound_mode(conf.main);
	let o = {
		dns: ctx.resolv ?? [],
		ipv6: u.bool(conf.main?.ipv6, false),
		loglevel: u.bool(conf.main?.log_enabled, true) ? 'warning' : 'none'
	};
	if (mode == 'tproxy')
		o.mark = u.OUT_MARK;
	else if (mode == 'tun') {
		o.mark = u.TUN_OUT_MARK;
		o.iface = xray.wan_device();
	}
	return o;
}

// Write the Xray config for the nodes gen.build() routed to the sidecar.
// Nodes Xray cannot run are removed from the sing-box config.
function xray_setup(conf, ctx, list, cfg, warnings) {
	if (!length(list)) {
		u.remove(u.XRAY_CONFIG_OUT);
		return null;
	}
	let bin = u.xray_path(conf.main);
	let drop_all = (why) => {
		for (let i = 0; i < length(list); i++)
			drop_node(cfg, list[i].outbound.tag);
		u.remove(u.XRAY_CONFIG_OUT);
		push(warnings, why);
	};
	if (!bin) {
		drop_all(length(list) + ' node(s) need the Xray core (XHTTP / mKCP / VLESS encryption / Xray config) and were skipped. Install it under Settings > Cores.');
		return { nodes: 0, skipped: length(list), installed: false };
	}
	let ver = u.xray_version(bin);
	let r = xray.prepare(bin, ver, list, xray_opts(conf, ctx), u.XRAY_CONFIG_OUT);
	for (let i = 0; i < length(r.dropped); i++) {
		drop_node(cfg, r.dropped[i].tag);
		push(warnings, 'node "' + r.dropped[i].tag + '" skipped by Xray: ' + r.dropped[i].error);
	}
	if (!r.ok || !length(r.nodes)) {
		drop_all('Xray configuration rejected: ' + u.last_line(r.output));
		return { nodes: 0, skipped: length(list), installed: true, version: ver?.string, error: r.output };
	}
	return { nodes: length(r.nodes), skipped: length(r.dropped), installed: true, version: ver?.string, bin: bin, finalmask: r.finalmask };
}

// AmneziaWG nodes: system interfaces from the optional packages
function awg_setup(conf, ctx, list, cfg, warnings) {
	if (!length(list)) {
		// remove interfaces of deleted nodes
		if (index(u.exec('uci -q show network').out, '.proto=\'amneziawg\'') >= 0)
			awg.sync([], null);
		return null;
	}
	if (!awg.installed()) {
		for (let i = 0; i < length(list); i++)
			drop_node(cfg, list[i].tag);
		push(warnings, length(list) + ' AmneziaWG node(s) skipped: install AmneziaWG on the Update tab');
		return { nodes: 0, skipped: length(list), installed: false };
	}
	let r = awg.sync(list, { mark: xray_opts(conf, ctx).mark });
	return { nodes: length(list), installed: true, interfaces: r.interfaces };
}

// ---------------------------------------------------------------------------
// Profiles (full sing-box configurations, remote or local)
// ---------------------------------------------------------------------------

export function profile_file(id) {
	return u.PROFILE_DIR + '/' + id + '.json';
};

function profile_meta_file(id) {
	return u.PROFILE_DIR + '/' + id + '.meta.json';
}

export function profile_find(conf, id) {
	for (let i = 0; i < length(conf.profiles ?? []); i++)
		if (conf.profiles[i].id == id)
			return conf.profiles[i];
	return null;
};

export function profile_info(id) {
	let meta = u.readjson(profile_meta_file(id)) ?? {};
	let st = stat(profile_file(id));
	meta.size = st?.size;
	meta.mtime = st?.mtime;
	if (st && meta.nodes == null) {
		let js = u.readjson(profile_file(id));
		let ps = gen.profile_stats(js);
		meta.nodes = ps.nodes;
		meta.groups = ps.groups;
	}
	return meta;
};

function profile_write_meta(id, patch) {
	let meta = u.readjson(profile_meta_file(id)) ?? {};
	for (let k in patch)
		meta[k] = patch[k];
	u.writejson(profile_meta_file(id), meta);
	return meta;
}

// A profile is either a complete sing-box configuration, or a node
// subscription (share links, base64, Clash YAML, Xray JSON). A subscription
// profile is stored as { _sbclient: { kind: 'subscription' }, outbounds,
// endpoints } and run as the built-in configuration with only its nodes.
export function is_sub_profile(js) {
	return type(js) == 'object' && js._sbclient?.kind == 'subscription';
};

// Returns { ok, js, text, kind: 'config' | 'subscription', error }
export function profile_parse(conf, text, opts) {
	let js = null;
	try { js = json(text); } catch (e) { js = null; }
	if (js != null && !is_sub_profile(js) && gen.profile_validate(js) == null)
		return { ok: true, js: js, text: text, kind: 'config' };
	if (is_sub_profile(js))
		return { ok: true, js: js, text: text, kind: 'subscription' };

	let r = parser.parse_content(text, { core: opts?.core });
	let nested = r.sub_urls ?? [];
	for (let i = 0; i < length(nested) && i < 20 && conf; i++) {
		let ntmp = u.RUN_DIR + '/profile-sub-' + i + '.raw';
		u.mkdirp(u.RUN_DIR);
		let ndl = download(conf, nested[i], ntmp, { via: opts?.via ?? 'auto', ua: opts?.ua ?? UA_DEFAULT, timeout: 45 });
		if (!ndl.ok) {
			push(r.errors, substr(nested[i], 0, 48) + '...: download failed: ' + ndl.error);
			continue;
		}
		let nr = parser.parse_content(readfile(ntmp), { core: opts?.core });
		u.remove(ntmp);
		for (let j = 0; j < length(nr.nodes); j++)
			push(r.nodes, nr.nodes[j]);
		for (let j = 0; j < length(nr.errors); j++)
			push(r.errors, nr.errors[j]);
	}
	if (length(r.nodes)) {
		let out = [], eps = [], taken = { direct: true, proxy: true, auto: true, block: true };
		for (let i = 0; i < length(r.nodes); i++) {
			let o = r.nodes[i].outbound;
			o.tag = parser.unique_tag(o.tag, taken);
			push(r.nodes[i].endpoint ? eps : out, o);
		}
		let sj = {
			_sbclient: { kind: 'subscription', format: r.format, skipped: length(r.errors), errors: slice(r.errors, 0, 20) },
			outbounds: out
		};
		if (length(eps))
			sj.endpoints = eps;
		return { ok: true, js: sj, text: sprintf('%.1J', sj), kind: 'subscription' };
	}
	if (js != null)
		return { ok: false, error: gen.profile_validate(js) ?? 'not a sing-box configuration' };
	let why = length(r.errors) ? ': ' + join('; ', slice(r.errors, 0, 3)) : '';
	let head = substr(replace(trim(text ?? ''), /[\r\n\t]+/g, ' '), 0, 100);
	return { ok: false, error: 'neither a sing-box configuration nor a subscription with usable nodes (format: ' + (r.format ?? '?') + ')' + why + (why == '' && head != '' ? ' - received: ' + head : '') };
};

// Store profile content (local profiles / imports / downloads).
export function profile_store(id, text, conf, opts) {
	let pr = profile_parse(conf, text, opts);
	if (!pr.ok)
		return { ok: false, error: pr.error };
	u.mkdirp(u.PROFILE_DIR);
	if (!u.writeatomic(profile_file(id), pr.text))
		return { ok: false, error: 'cannot write profile file' };
	let ps = gen.profile_stats(pr.js);
	profile_write_meta(id, { updated: time(), nodes: ps.nodes, groups: ps.groups, kind: pr.kind, format: pr.js._sbclient?.format, skipped: pr.js._sbclient?.skipped, error: null });
	return { ok: true, nodes: ps.nodes, groups: ps.groups, kind: pr.kind };
};

// ctx for a subscription profile: the built-in builder with only its nodes
function sub_profile_ctx(js, ctx) {
	let c = {};
	for (let k in ctx)
		c[k] = ctx[k];
	c.nodes = [
		...map(js.outbounds ?? [], (o) => ({ outbound: u.clone(o), endpoint: false, source: 'profile' })),
		...map(js.endpoints ?? [], (o) => ({ outbound: u.clone(o), endpoint: true, source: 'profile' }))
	];
	return c;
}

// Download a remote profile. Returns { ok, changed, error }.
export function profile_update(conf, id) {
	let p = profile_find(conf, id);
	if (!p)
		return { ok: false, error: 'profile not found: ' + id };
	if ((p.type ?? 'remote') != 'remote' || p.url == null || p.url == '')
		return { ok: false, error: 'not a remote profile' };
	u.mkdirp(u.PROFILE_DIR);
	u.mkdirp(u.RUN_DIR);
	let tmp = u.RUN_DIR + '/profile-' + id + '.dl';
	let hdr = u.RUN_DIR + '/profile-' + id + '.hdr';
	let dl = download(conf, deep_link_url(p.url), tmp, { via: p.via ?? 'auto', ua: p.user_agent ?? (p.core == 'xray' ? UA_DEFAULT : PROFILE_UA), headers_file: hdr, timeout: 45 });
	if (!dl.ok) {
		u.remove(hdr);
		profile_write_meta(id, { error: 'download failed: ' + dl.error, checked: time() });
		return { ok: false, error: 'download failed: ' + dl.error };
	}
	let text = readfile(tmp);
	let headers = readfile(hdr);
	u.remove(tmp);
	u.remove(hdr);
	let old = readfile(profile_file(id));
	let r = profile_store(id, text, conf, { via: p.via ?? 'auto', ua: p.user_agent ?? (p.core == 'xray' ? UA_DEFAULT : PROFILE_UA), core: p.core });
	if (!r.ok) {
		profile_write_meta(id, { error: r.error, checked: time() });
		return r;
	}
	profile_write_meta(id, { info: parse_userinfo(headers), via: dl.via, checked: time() });
	return { ok: true, changed: old != text, nodes: r.nodes, via: dl.via };
};

export function profile_delete_files(id) {
	u.remove(profile_file(id));
	u.remove(profile_meta_file(id));
};

// Load + adapt the active profile. Returns { config, warnings, profile } or { error }.
function load_active_profile(conf, ctx) {
	let id = conf.main?.active_profile;
	if (id == null || id == '')
		return null;
	let p = profile_find(conf, id);
	if (!p)
		return { error: 'active profile "' + id + '" no longer exists' };
	let name = p.name ?? id;
	let text = readfile(profile_file(id));
	if ((text == null || text == '') && (p.type ?? 'remote') == 'remote') {
		let r = profile_update(conf, id);
		if (!r.ok)
			return { error: 'profile "' + name + '": ' + r.error };
		text = readfile(profile_file(id));
	}
	if (text == null || text == '')
		return { error: 'profile "' + name + '" has no content' };
	let js = null;
	try { js = json(text); } catch (e) { return { error: 'profile "' + name + '" is not valid JSON' }; }
	if (is_sub_profile(js)) {
		let b = gen.build(conf, sub_profile_ctx(js, ctx));
		return {
			config: b.config, warnings: b.warnings, xray: b.xray ?? [], awg: b.awg ?? [],
			notes: [ 'subscription profile: ' + length(js.outbounds ?? []) + ' nodes with the built-in routing and DNS' ],
			profile: { id: id, name: name, integrate: true }
		};
	}
	let err = gen.profile_validate(js);
	if (err)
		return { error: 'profile "' + name + '": ' + err };
	let r = gen.adapt_profile(js, conf, p, ctx);
	r.profile = { id: id, name: name, integrate: u.bool(p.integrate, true) };
	return r;
}

// Adapt + "sing-box check" a profile without activating it.
export function profile_check(conf, id) {
	let p = profile_find(conf, id);
	if (!p)
		return { ok: false, error: 'profile not found' };
	let text = readfile(profile_file(id));
	if (!text)
		return { ok: false, error: 'profile has no content yet' };
	let js = null;
	try { js = json(text); } catch (e) { return { ok: false, error: 'not valid JSON' }; }
	let bin = u.core_path(conf.main);
	if (!bin)
		return { ok: false, error: 'sing-box binary not found' };
	let r;
	if (is_sub_profile(js)) {
		let ctx = build_ctx(conf);
		r = gen.build(conf, sub_profile_ctx(js, ctx));
		// Xray nodes are reached through local SOCKS ports; sing-box only sees those
		r.notes = length(r.xray ?? []) ? [ length(r.xray) + ' node(s) run through the Xray core' ] : [];
	}
	else {
		let err = gen.profile_validate(js);
		if (err)
			return { ok: false, error: err };
		r = gen.adapt_profile(js, conf, p, { ver: u.core_version(bin), resolv: wan_dns() });
	}
	u.mkdirp(u.RUN_DIR);
	let tmp = u.RUN_DIR + '/profile-check.json';
	u.writeatomic(tmp, sprintf('%J', r.config));
	let chk = check_config(bin, tmp);
	u.remove(tmp);
	return { ok: chk.ok, output: chk.output, warnings: [ ...r.warnings, ...(r.notes ?? []) ], stats: gen.profile_stats(js) };
};

// Plain upstream servers configured in dnsmasq (not domain-specific ones)
function dnsmasq_upstreams() {
	let out = [];
	let c = cursor();
	c.load('dhcp');
	c.foreach('dhcp', 'dnsmasq', (sec) => {
		let list = u.tolist(sec.server);
		for (let i = 0; i < length(list); i++)
			if (substr(list[i], 0, 1) != '/' && index(list[i], '127.0.0.1') != 0)
				push(out, list[i]);
	});
	return out;
}

function has_inbound(cfg, t, port) {
	let ibs = cfg?.inbounds ?? [];
	for (let i = 0; i < length(ibs); i++)
		if (ibs[i]?.type == t && ibs[i]?.listen_port == port)
			return true;
	return false;
}

export function generate(conf) {
	u.mkdirp(u.RUN_DIR);
	u.mkdirp(u.WORK_DIR);
	let ctx = build_ctx(conf);
	if (!ctx.bin)
		return { ok: false, error: 'sing-box binary not found (install the sing-box package or use "Update core")' };

	let cfg, warnings = [];
	let xray_list = [];
	let awg_list = [];
	let prof = load_active_profile(conf, ctx);
	let source = 'builtin';
	if (prof?.error) {
		// never leave the network without internet because of a broken profile
		push(warnings, prof.error + ' - falling back to the built-in configuration');
		prof = null;
	}
	if (prof) {
		cfg = prof.config;
		warnings = [ ...warnings, ...prof.warnings ];
		xray_list = prof.xray ?? [];
		awg_list = prof.awg ?? [];
		source = prof.profile.integrate ? 'profile' : 'profile-raw';
	}
	else if (u.bool(conf.main?.use_custom, false)) {
		source = 'custom';
		let txt = readfile(u.CUSTOM_CONFIG);
		if (!txt)
			return { ok: false, error: 'custom config ' + u.CUSTOM_CONFIG + ' is empty' };
		try { cfg = json(txt); } catch (e) { return { ok: false, error: 'custom config is not valid JSON' }; }
		push(warnings, 'using custom configuration file');
	}
	else {
		let r = gen.build(conf, ctx);
		cfg = r.config;
		warnings = [ ...warnings, ...r.warnings ];
		xray_list = r.xray ?? [];
		awg_list = r.awg ?? [];
	}
	let xray_state = xray_setup(conf, ctx, xray_list, cfg, warnings);
	let awg_state = awg_setup(conf, ctx, awg_list, cfg, warnings);

	if (!u.writeatomic(u.CONFIG_OUT, sprintf('%J', cfg)))
		return { ok: false, error: 'cannot write ' + u.CONFIG_OUT };
	chmod(u.CONFIG_OUT, 384);

	let mode = u.inbound_mode(conf.main);
	if (mode == 'tproxy')
		u.writeatomic(u.NFT_OUT, gen.build_nft(conf, ctx));
	else
		u.remove(u.NFT_OUT);

	if (u.bool(conf.dns?.dnsmasq_redirect, true)) {
		let extra = dnsmasq_upstreams();
		if (length(extra))
			push(warnings, 'dnsmasq has its own upstream servers (' + join(', ', extra) + '); they bypass sing-box and may leak DNS. Remove them under Network > DHCP and DNS > Forwards.');
	}

	let chk = check_config(ctx.bin, u.CONFIG_OUT);

	// A single broken node (e.g. from a sing-box JSON subscription that needs a
	// feature this core lacks) must not take the whole service down: drop the
	// offending node and check again.
	let fixable = (source == 'builtin' || source == 'profile');
	for (let tries = 0; !chk.ok && fixable && tries < 25; tries++) {
		let bad = quarantine_target(cfg, chk.output);
		if (!bad)
			break;
		drop_node(cfg, bad);
		push(warnings, 'node "' + bad + '" skipped: ' + split(chk.output, '\n')[0]);
		u.writeatomic(u.CONFIG_OUT, sprintf('%J', cfg));
		chk = check_config(ctx.bin, u.CONFIG_OUT);
	}

	let state = {
		generated: time(),
		ok: chk.ok,
		check: chk.output,
		warnings: warnings,
		nodes: length(ctx.nodes),
		version: ctx.ver?.string,
		bin: ctx.bin,
		mode: mode,
		lan_devs: ctx.lan_devs,
		resolv: ctx.resolv,
		source: source,
		notes: prof ? (prof.notes ?? []) : [],
		profile: prof ? prof.profile : null,
		main_group: (source == 'builtin') ? 'proxy' : gen.main_group(cfg),
		has_tproxy: has_inbound(cfg, 'tproxy', u.toint(conf.main?.tproxy_port, 7895)),
		has_dns_in: has_inbound(cfg, 'direct', u.toint(conf.main?.dns_port, 1053)),
		xray: xray_state,
		awg: awg_state
	};
	u.writejson(u.STATE_FILE, state);
	return { ok: chk.ok, error: chk.ok ? null : chk.output, warnings: warnings, state: state };
};

// ---------------------------------------------------------------------------
// Firewall (TPROXY) and dnsmasq integration
// ---------------------------------------------------------------------------

function ipcmd(args) {
	return u.exec('ip ' + args);
}

export function fw_down() {
	u.exec('nft delete table inet singbox');
	for (let fam = 0; fam < 2; fam++) {
		let f = fam ? '-6 ' : '-4 ';
		for (let n = 0; n < 4; n++)
			if (ipcmd(f + sprintf('rule del fwmark 0x%x/0xffffffff lookup %d', u.TPROXY_MARK, u.ROUTE_TABLE)).code != 0)
				break;
		ipcmd(f + sprintf('route flush table %d', u.ROUTE_TABLE));
	}
	return true;
};

export function fw_up(conf) {
	fw_down();
	if ((u.inbound_mode(conf.main)) != 'tproxy')
		return { ok: true };
	if (!stat(u.NFT_OUT))
		return { ok: false, error: 'nft rules not generated' };
	let st = u.readjson(u.STATE_FILE);
	if (st && st.has_tproxy === false)
		return { ok: false, error: 'the running configuration has no tproxy inbound on the TPROXY port; transparent proxy not enabled' };
	let v6 = u.bool(conf.main?.ipv6, false);
	ipcmd(sprintf('-4 rule add fwmark 0x%x/0xffffffff lookup %d pref 9100', u.TPROXY_MARK, u.ROUTE_TABLE));
	ipcmd(sprintf('-4 route replace local 0.0.0.0/0 dev lo table %d', u.ROUTE_TABLE));
	if (v6) {
		ipcmd(sprintf('-6 rule add fwmark 0x%x/0xffffffff lookup %d pref 9100', u.TPROXY_MARK, u.ROUTE_TABLE));
		ipcmd(sprintf('-6 route replace local ::/0 dev lo table %d', u.ROUTE_TABLE));
	}
	let r = u.exec('nft -f ' + u.shq(u.NFT_OUT));
	if (r.code != 0) {
		fw_down();
		return { ok: false, error: trim(r.out) };
	}
	return { ok: true };
};

export function fw_active() {
	return u.exec('nft list table inet singbox').code == 0;
};

function dnsmasq_confdirs() {
	let dirs = [];
	let c = cursor();
	c.load('dhcp');
	c.foreach('dhcp', 'dnsmasq', (s) => {
		let d = s.confdir;
		if (d == null || d == '')
			d = '/tmp/dnsmasq' + (s['.name'] ? '.' + s['.name'] : '') + '.d';
		d = split(d, ',')[0];
		if (substr(d, 0, 1) == '/')
			push(dirs, d);
	});
	return dirs;
}

const DNSMASQ_FILE = 'singbox.conf';

export function dns_down() {
	let dirs = dnsmasq_confdirs();
	let changed = false;
	for (let i = 0; i < length(dirs); i++) {
		let f = dirs[i] + '/' + DNSMASQ_FILE;
		if (stat(f)) {
			unlink(f);
			changed = true;
		}
	}
	if (changed)
		u.exec('/etc/init.d/dnsmasq restart');
	return true;
};

export function dns_up(conf) {
	let st = u.readjson(u.STATE_FILE);
	if (!u.bool(conf.dns?.dnsmasq_redirect, true) || (st && st.has_dns_in === false))
		return dns_down();
	let port = u.toint(conf.main?.dns_port, 1053);
	let body = '# generated by luci-app-singbox - removed when the service stops\n' +
		'no-resolv\n' +
		'server=127.0.0.1#' + port + '\n';
	if (u.bool(conf.dns?.fakeip, false))
		body += 'max-cache-ttl=1\n';
	let dirs = dnsmasq_confdirs();
	let changed = false;
	for (let i = 0; i < length(dirs); i++) {
		u.mkdirp(dirs[i]);
		let f = dirs[i] + '/' + DNSMASQ_FILE;
		if (readfile(f) != body) {
			writefile(f, body);
			changed = true;
		}
	}
	if (changed)
		u.exec('/etc/init.d/dnsmasq restart');
	return true;
};

export function dns_active() {
	let dirs = dnsmasq_confdirs();
	for (let i = 0; i < length(dirs); i++)
		if (stat(dirs[i] + '/' + DNSMASQ_FILE))
			return true;
	return false;
};

// ---------------------------------------------------------------------------
// Clash API client
// ---------------------------------------------------------------------------

export function api(conf, method, path, body, timeout) {
	let port = u.toint(conf.main?.api_port, 9090);
	let cmd = 'curl -s -m ' + (timeout ?? 10) + ' -X ' + method + ' -w ' + u.shq('\n%{http_code}');
	if (conf.main?.api_secret != null && conf.main.api_secret != '')
		cmd += ' -H ' + u.shq('Authorization: Bearer ' + conf.main.api_secret);
	if (body != null)
		cmd += ' -H ' + u.shq('Content-Type: application/json') + ' --data-binary ' + u.shq(sprintf('%J', body));
	cmd += ' ' + u.shq('http://127.0.0.1:' + port + path);
	let r = u.exec(cmd);
	let nl = rindex(r.out, '\n');
	let codestr = nl >= 0 ? substr(r.out, nl + 1) : r.out;
	let text = nl >= 0 ? substr(r.out, 0, nl) : '';
	let code = int(codestr);
	if (r.code != 0 || code == 0)
		return { ok: false, status: 0, error: 'clash API not reachable' };
	let data = null;
	if (text != '') {
		try { data = json(text); } catch (e) { data = text; }
	}
	return { ok: code >= 200 && code < 300, status: code, data: data };
};

export function enc(s) {
	return u.urlencode(s);
};

// ---------------------------------------------------------------------------
// Core (sing-box binary) updates
// ---------------------------------------------------------------------------

// Map the OpenWrt package architecture (DISTRIB_ARCH, e.g. mipsel_24kc,
// aarch64_cortex-a53, arm_cortex-a7_neon-vfpv4) to the official release
// asset suffix. uname -m alone cannot tell mips from mipsel on OpenWrt.
export function core_arch() {
	let rel = readfile('/etc/openwrt_release') ?? '';
	let m = match(rel, /DISTRIB_ARCH='([^']+)'/);
	let a = m ? m[1] : '';
	if (a == '')
		a = trim(u.exec('uname -m').out);

	if (a == 'x86_64')
		return 'amd64';
	if (match(a, /^i[3-6]86/))
		return '386';
	if (match(a, /^aarch64/))
		return 'arm64';
	if (match(a, /^arm/)) {
		if (match(a, /arm926|fa526|xscale|arm1136/))
			return 'armv5';
		if (match(a, /arm1176/))
			return 'armv6';
		return 'armv7';
	}
	if (match(a, /^mips64el/))
		return 'mips64le-softfloat';
	if (match(a, /^mips64/))
		return 'mips64-softfloat';
	if (match(a, /^mipsel/))
		return 'mipsle-softfloat';
	if (match(a, /^mips/))
		return 'mips-softfloat';
	if (match(a, /^riscv64/))
		return 'riscv64';
	if (match(a, /^loongarch64/))
		return 'loong64';
	if (match(a, /^powerpc64le|^ppc64le/))
		return 'ppc64le';
	return a;
};

// ---- package manager / release helpers ----

function has_apk() {
	return access('/usr/bin/apk', 'x') || access('/sbin/apk', 'x');
}

function has_opkg() {
	return access('/bin/opkg', 'x') || access('/usr/bin/opkg', 'x');
}

function pkg_install(name) {
	if (has_apk())
		return u.exec('apk add ' + name + ' || (apk update && apk add ' + name + ')');
	if (has_opkg())
		return u.exec('opkg install ' + name + ' || (opkg update && opkg install ' + name + ')');
	return { code: 127, out: 'no package manager' };
}

export function pkg_installed(name) {
	if (has_apk())
		return u.exec('apk info -e ' + name + ' >/dev/null').code == 0;
	if (has_opkg())
		return !!match(u.exec('opkg status ' + name).out, /Status:[^\n]*installed/);
	return false;
};

function pkg_remove(name) {
	if (has_apk())
		return u.exec('apk del ' + name);
	if (has_opkg())
		return u.exec('opkg remove ' + name);
	return { code: 127, out: 'no package manager' };
}

function have_unzip() {
	if (u.exec('command -v unzip').code == 0)
		return 'unzip';
	if (u.exec('busybox unzip 2>&1 | grep -qi usage').code == 0)
		return 'busybox unzip';
	return null;
}

function parse_tag(name) {
	let m = match('' + name, /^v?([0-9]+)\.([0-9]+)\.([0-9]+)(-[A-Za-z0-9.]+)?$/);
	if (!m)
		return null;
	return { version: replace(name, /^v/, ''), n: [ int(m[1]), int(m[2]), int(m[3]) ], prerelease: m[4] != null };
}

// A fixed "sing-box binary" path (Settings > Advanced) would keep using the
// old core after a switch: clear it.
// remembered so that app upgrades keep the OpenWrt package when it was chosen
function set_core_source(src) {
	let c = cursor();
	c.load('singbox');
	if (src)
		c.set('singbox', 'main', 'core_source', src);
	else
		c.delete('singbox', 'main', 'core_source');
	c.commit('singbox');
}

function clear_core_path(keep) {
	let c = cursor();
	c.load('singbox');
	let p = c.get('singbox', 'main', 'core_path');
	if (p == null || p == '' || p == keep)
		return false;
	c.delete('singbox', 'main', 'core_path');
	c.commit('singbox');
	return true;
}

// Version list from GitHub tag names (newest first). xr: Xray instead of sing-box
export function releases_from_names(names, xr) {
	let list = [];
	let seen = {};
	for (let i = 0; i < length(names); i++) {
		let t = parse_tag(names[i]);
		if (!t || seen[t.version])
			continue;
		// oldest versions this app can drive
		if (xr ? (t.n[0] < 24 || (t.n[0] == 24 && t.n[1] < 11)) : (t.n[0] == 1 && t.n[1] < 12))
			continue;
		seen[t.version] = true;
		push(list, t);
	}
	list = sort(list, (a, b) => {
		for (let k = 0; k < 3; k++)
			if (a.n[k] != b.n[k])
				return b.n[k] - a.n[k];
		if (a.prerelease != b.prerelease)
			return a.prerelease ? 1 : -1;
		return (a.version < b.version) ? 1 : ((a.version > b.version) ? -1 : 0);
	});
	let stable = [], pre = [];
	for (let i = 0; i < length(list); i++) {
		if (list[i].prerelease) {
			if (length(pre) < 15)
				push(pre, list[i].version);
		}
		else if (length(stable) < 40)
			push(stable, list[i].version);
	}
	return { ok: length(stable) + length(pre) > 0, stable: stable, prerelease: pre, latest: stable[0] };
};

// which: 'sing-box' | 'xray'. GitHub API first, the releases feed as fallback
// (the API is rate-limited per IP).
export function core_releases(conf, which) {
	let xr = (which == 'xray');
	let repo = xr ? 'XTLS/Xray-core' : 'SagerNet/sing-box';
	let tmp = u.RUN_DIR + '/tags-' + (xr ? 'xray' : 'sb') + '.tmp';
	u.mkdirp(u.RUN_DIR);
	let names = [];
	let err = null;
	let dl = download(conf, 'https://api.github.com/repos/' + repo + '/tags?per_page=100', tmp, { timeout: 20 });
	if (dl.ok) {
		let js = u.readjson(tmp);
		if (type(js) == 'array')
			names = map(js, (t) => t?.name);
	}
	else
		err = dl.error;
	if (!length(names)) {
		dl = download(conf, 'https://github.com/' + repo + '/releases.atom', tmp, { timeout: 20 });
		if (dl.ok) {
			let txt = readfile(tmp) ?? '';
			let m = match(txt, /releases\/tag\/[^"<]+/g) ?? [];
			names = map(m, (x) => replace(x[0], /^releases\/tag\//, ''));
		}
		else
			err = dl.error;
	}
	u.remove(tmp);
	let r = releases_from_names(names, xr);
	if (!r.ok)
		return { ok: false, error: err ?? 'cannot read the version list' };
	return r;
};

// Latest stable tag from the redirect of github.com/<repo>/releases/latest
// (no API, no rate limit). Returns the version or null.
function latest_by_redirect(conf, repo) {
	let px = mixed_proxy(conf);
	let tries = [ null ];
	if (px)
		push(tries, px);
	for (let i = 0; i < length(tries); i++) {
		let cmd = 'curl -sS -o /dev/null --connect-timeout 10 -m 20 -w ' + u.shq('%{redirect_url}') +
			(tries[i] ? ' -x ' + u.shq(tries[i]) : '') + ' ' + u.shq('https://github.com/' + repo + '/releases/latest');
		// stable tags only ("v1.14.4"), never "-beta" / "-rc"
		let m = match(trim(u.exec(cmd).out), /\/releases\/tag\/v?([0-9]+\.[0-9]+\.[0-9]+)$/);
		if (m)
			return m[1];
	}
	return null;
}

export function core_latest(conf, prerelease) {
	let tmp = u.RUN_DIR + '/release.json';
	u.mkdirp(u.RUN_DIR);
	let url = prerelease ? 'https://api.github.com/repos/SagerNet/sing-box/releases?per_page=5' :
		'https://api.github.com/repos/SagerNet/sing-box/releases/latest';
	let dl = download(conf, url, tmp, { timeout: 15 });
	if (!dl.ok)
		return { ok: false, error: dl.error };
	let js = u.readjson(tmp);
	u.remove(tmp);
	if (type(js) == 'array')
		js = js[0];
	let tag = js?.tag_name;
	if (!tag)
		return { ok: false, error: 'cannot read release info' };
	return { ok: true, version: replace(tag, /^v/, '') };
};

export function core_update(conf, version) {
	if (version == null || version == '' || version == 'latest' || version == 'prerelease') {
		let l = { ok: false, error: '?' };
		let rv = (version != 'prerelease') ? latest_by_redirect(conf, 'SagerNet/sing-box') : null;
		if (rv)
			l = { ok: true, version: rv };
		else
			l = core_latest(conf, version == 'prerelease');
		if (!l.ok && version != 'prerelease') {
			// the releases API is rate-limited per IP: fall back to the tag list / feed
			let r = core_releases(conf, 'sing-box');
			if (r.ok && r.latest)
				l = { ok: true, version: r.latest };
		}
		if (!l.ok)
			return { ok: false, error: 'cannot find the latest version: ' + l.error };
		version = l.version;
	}
	if (!match(version, /^[0-9]+\.[0-9]+\.[0-9]+(-[A-Za-z0-9.]+)?$/))
		return { ok: false, error: 'invalid version' };
	let arch = core_arch();
	let base = 'sing-box-' + version + '-linux-' + arch;
	// Since 1.13 the plain build is linked against glibc; OpenWrt uses musl,
	// which needs the "-musl" build (static). 1.12 and some targets only have
	// the plain (static) build, so fall back to it.
	let musl = u.exec('ls /lib/ld-musl-*.so.1').code == 0;
	let cands = musl ? [ base + '-musl', base ] : [ base, base + '-glibc' ];
	let work = '/tmp/singbox-core';
	let bin = null, v = null;
	let errors = [];
	for (let i = 0; i < length(cands) && !v; i++) {
		let name = cands[i];
		u.exec('rm -rf ' + u.shq(work));
		u.mkdirp(work);
		let url = 'https://github.com/SagerNet/sing-box/releases/download/v' + version + '/' + name + '.tar.gz';
		let dl = download(conf, url, work + '/core.tgz', { timeout: 300 });
		if (!dl.ok) {
			push(errors, name + ': download failed (' + u.last_line(dl.error) + ')');
			continue;
		}
		let x = u.exec('tar -xzf ' + u.shq(work + '/core.tgz') + ' -C ' + u.shq(work));
		let found = trim(u.exec('find ' + u.shq(work) + ' -type f -name sing-box | head -n 1').out);
		if (x.code != 0 || found == '' || !stat(found)) {
			push(errors, name + ': archive extraction failed');
			continue;
		}
		chmod(found, 493);
		v = u.core_version(found);
		if (v)
			bin = found;
		else
			push(errors, name + ': does not run here (' + (u.last_line(u.exec(u.shq(found) + ' version').out) || 'not executable') + ')');
	}
	if (!v) {
		u.exec('rm -rf ' + u.shq(work));
		return { ok: false, error: join('; ', errors) };
	}
	u.mkdirp(u.BIN_DIR);
	let dest = u.BIN_DIR + '/sing-box';
	if (stat(dest))
		rename(dest, dest + '.bak');
	let cp = u.exec('cp ' + u.shq(bin) + ' ' + u.shq(dest + '.new') + ' && mv ' + u.shq(dest + '.new') + ' ' + u.shq(dest));
	u.exec('rm -rf ' + u.shq(work));
	if (cp.code != 0) {
		if (stat(dest + '.bak'))
			rename(dest + '.bak', dest);
		return { ok: false, error: 'cannot install binary: ' + trim(cp.out) };
	}
	chmod(dest, 493);
	// the previous core is replaced: drop the backup and the OpenWrt package
	// (kept when this app itself was installed as a package that depends on it)
	u.remove(dest + '.bak');
	clear_core_path(dest);
	set_core_source(null);
	let removed = null;
	if (pkg_installed('sing-box') && !pkg_installed('luci-app-singbox')) {
		pkg_remove('sing-box');
		removed = 'sing-box package';
	}
	return { ok: true, version: v.string, path: dest, removed: removed };
};

// Switch back to the OpenWrt sing-box package (installed if missing).
export function core_use_package(conf) {
	if (!access('/usr/bin/sing-box', 'x'))
		pkg_install('sing-box');
	let v = u.core_version('/usr/bin/sing-box');
	if (!v)
		return { ok: false, error: 'could not install the sing-box package - the current core is kept' };
	u.remove(u.BIN_DIR + '/sing-box');
	u.remove(u.BIN_DIR + '/sing-box.bak');
	clear_core_path('/usr/bin/sing-box');
	set_core_source('package');
	return { ok: true, version: v.string, path: '/usr/bin/sing-box' };
};

// ---- Xray core (sidecar) ----

const XRAY_ARCH = {
	amd64: '64', '386': '32', arm64: 'arm64-v8a', armv7: 'arm32-v7a', armv6: 'arm32-v6', armv5: 'arm32-v5',
	'mips-softfloat': 'mips32', 'mipsle-softfloat': 'mips32le', 'mips64-softfloat': 'mips64', 'mips64le-softfloat': 'mips64le',
	riscv64: 'riscv64', loong64: 'loong64', ppc64le: 'ppc64le'
};

// how: 'package' (OpenWrt xray-core) or 'github' / 'latest' / 'x.y.z' (official build)
export function xray_install(conf, how) {
	if (how == 'package') {
		let r = pkg_install('xray-core');
		let bin = access('/usr/bin/xray', 'x') ? '/usr/bin/xray' : null;
		let v = u.xray_version(bin);
		if (!v)
			return { ok: false, error: 'package installation failed: ' + u.last_line(r.out) };
		u.remove(u.BIN_DIR + '/xray');
		return { ok: true, version: v.string, path: bin };
	}
	let arch = XRAY_ARCH[core_arch()];
	if (!arch)
		return { ok: false, error: 'no official Xray build for ' + core_arch() + ' - use the xray-core package' };
	let uz = have_unzip();
	if (!uz) {
		pkg_install('unzip');
		uz = have_unzip();
		if (!uz)
			return { ok: false, error: 'unzip is needed to unpack the official build (apk add unzip)' };
	}
	if (how == null || how == '' || how == 'github' || how == 'latest') {
		let rv = latest_by_redirect(conf, 'XTLS/Xray-core');
		if (rv)
			how = rv;
	}
	let url = (how == null || how == '' || how == 'github' || how == 'latest') ?
		'https://github.com/XTLS/Xray-core/releases/latest/download/Xray-linux-' + arch + '.zip' :
		'https://github.com/XTLS/Xray-core/releases/download/v' + replace(how, /^v/, '') + '/Xray-linux-' + arch + '.zip';
	if (how != null && how != '' && how != 'github' && how != 'latest' && !match(how, /^v?[0-9]+\.[0-9]+\.[0-9]+$/))
		return { ok: false, error: 'invalid version' };
	let work = '/tmp/singbox-xray';
	u.exec('rm -rf ' + u.shq(work));
	u.mkdirp(work);
	let dl = download(conf, url, work + '/xray.zip', { timeout: 300 });
	if (!dl.ok)
		return { ok: false, error: 'download failed: ' + dl.error };
	let x = u.exec('cd ' + u.shq(work) + ' && ' + uz + ' -o xray.zip xray');
	let bin = work + '/xray';
	if (!stat(bin)) {
		u.exec('rm -rf ' + u.shq(work));
		return { ok: false, error: 'archive extraction failed: ' + trim(x.out) };
	}
	chmod(bin, 493);
	let v = u.xray_version(bin);
	if (!v) {
		u.exec('rm -rf ' + u.shq(work));
		return { ok: false, error: 'downloaded binary does not run on this system' };
	}
	u.mkdirp(u.BIN_DIR);
	let dest = u.BIN_DIR + '/xray';
	let cp = u.exec('cp ' + u.shq(bin) + ' ' + u.shq(dest + '.new') + ' && mv ' + u.shq(dest + '.new') + ' ' + u.shq(dest));
	u.exec('rm -rf ' + u.shq(work));
	if (cp.code != 0)
		return { ok: false, error: 'cannot install binary: ' + trim(cp.out) };
	chmod(dest, 493);
	let removed = null;
	if (pkg_installed('xray-core')) {
		pkg_remove('xray-core');
		removed = 'xray-core package';
	}
	return { ok: true, version: v.string, path: dest, removed: removed };
};

// ---------------------------------------------------------------------------
// AmneziaWG packages (optional): kernel module + tools for this exact firmware
// ---------------------------------------------------------------------------

export function awg_status() {
	return awg.status();
};

export function awg_install(conf) {
	if (awg.installed())
		return { ok: true, already: true };
	let p = awg.packages();
	if (!p.ok)
		return { ok: false, error: p.error };
	let free = awg.free_kb();
	if (free != null && free < 1024)
		return { ok: false, error: sprintf('not enough free space: %d KB free, about 1 MB needed', free) };
	let dir = '/tmp/singbox-awg';
	u.exec('rm -rf ' + u.shq(dir));
	u.mkdirp(dir);
	let files = [];
	for (let i = 0; i < length(p.files); i++) {
		let f = dir + '/' + p.files[i].file;
		let dl = download(conf, p.files[i].url, f, { timeout: 120 });
		if (!dl.ok) {
			u.exec('rm -rf ' + u.shq(dir));
			return { ok: false, error: p.files[i].name + ': no package for this firmware (' + p.board.version + ', ' + p.board.target + '/' + p.board.subtarget + ') or download failed: ' + dl.error };
		}
		push(files, f);
	}
	let x = u.exec('apk add --allow-untrusted ' + join(' ', map(files, (f) => u.shq(f))) + ' 2>&1');
	u.exec('rm -rf ' + u.shq(dir));
	if (x.code != 0)
		return { ok: false, error: 'apk: ' + u.last_line(x.out) };
	u.exec('modprobe amneziawg 2>/dev/null; insmod amneziawg 2>/dev/null');
	if (!awg.installed())
		return { ok: false, error: 'packages installed, but the amneziawg kernel module does not load (kernel ' + p.board.kernel + ')' };
	return { ok: true };
};

export function awg_remove() {
	awg.sync([], null);
	let x = u.exec('apk del amneziawg-tools kmod-amneziawg 2>&1');
	return { ok: x.code == 0, error: x.code == 0 ? null : u.last_line(x.out) };
};

export function xray_remove() {
	u.remove(u.BIN_DIR + '/xray');
	if (pkg_installed('xray-core'))
		pkg_remove('xray-core');
	return { ok: true };
};

export function xray_latest(conf) {
	let tmp = u.RUN_DIR + '/xray-release.json';
	u.mkdirp(u.RUN_DIR);
	let dl = download(conf, 'https://api.github.com/repos/XTLS/Xray-core/releases/latest', tmp, { timeout: 15 });
	if (!dl.ok)
		return { ok: false, error: dl.error };
	let js = u.readjson(tmp);
	u.remove(tmp);
	if (!js?.tag_name)
		return { ok: false, error: 'cannot read release info' };
	return { ok: true, version: replace(js.tag_name, /^v/, '') };
};

export function core_reset() {
	u.remove(u.BIN_DIR + '/sing-box');
	u.remove(u.BIN_DIR + '/sing-box.bak');
	return { ok: true };
};

// ---------------------------------------------------------------------------
// Latency tests while the service is stopped
// ---------------------------------------------------------------------------
//
// Starts a throw-away sing-box with only the nodes and a local Clash API (no
// inbounds, so it never touches traffic), measures, saves the result and
// stops it again.

export const DELAY_FILE = '/var/run/singbox/delays.json';
const TEST_DIR = '/var/run/singbox/test';
const TEST_PORT = 39871;
const TEST_SECRET = 'sbtest';
const TEST_GROUP = 'sb-latency-test';

// Proxy nodes (outbounds + endpoints) of the active source, without groups.
export function test_nodes(conf) {
	let out = [], eps = [];
	let id = conf.main?.active_profile ?? '';
	if (id != '') {
		let js = u.readjson(profile_file(id));
		if (type(js) == 'object') {
			for (let i = 0; i < length(js.outbounds ?? []); i++)
				if ((gen.PROXY_TYPES[js.outbounds[i]?.type] || js.outbounds[i]?.type == 'xray') && js.outbounds[i].tag != null)
					push(out, js.outbounds[i]);
				else if (js.outbounds[i]?.type == 'amneziawg' && js.outbounds[i].tag != null)
					push(out, awg.as_direct(js.outbounds[i]));
			for (let i = 0; i < length(js.endpoints ?? []); i++)
				if (gen.PROXY_TYPES[js.endpoints[i]?.type] && js.endpoints[i].tag != null)
					push(eps, js.endpoints[i]);
		}
		return { outbounds: out, endpoints: eps, source: 'profile' };
	}
	let list = collect_nodes(conf, false);
	for (let i = 0; i < length(list); i++) {
		if (list[i].endpoint)
			push(eps, list[i].outbound);
		else if (list[i].outbound?.type == 'amneziawg')
			push(out, awg.as_direct(list[i].outbound));
		else
			push(out, list[i].outbound);
	}
	return { outbounds: out, endpoints: eps, source: 'builtin' };
};

function test_config(conf, nodes, tags) {
	let have = {};
	let all = [ ...nodes.outbounds, ...nodes.endpoints ];
	for (let i = 0; i < length(all); i++)
		have[all[i].tag] = true;
	let up = filter(wan_dns(), (ip) => u.is_ip(ip) && substr(ip, 0, 4) != '127.' && ip != '::1');
	let fix = (o) => {
		o = u.clone(o);
		// chains to groups/nodes that are not part of the test, or profile DNS servers
		if (o.detour != null && !have[o.detour])
			delete o.detour;
		delete o.domain_resolver;
		delete o.domain_strategy;
		return o;
	};
	let members = filter(tags ?? keys(have), (t) => have[t]);
	let cfg = {
		log: { disabled: true },
		dns: { servers: [ { type: 'udp', tag: 'sb-test-dns', server: length(up) ? up[0] : '1.1.1.1' } ] },
		outbounds: [
			...map(nodes.outbounds, fix),
			{ type: 'direct', tag: 'sb-test-direct' },
			{ type: 'urltest', tag: TEST_GROUP, outbounds: members, url: conf.main?.urltest_url ?? 'https://www.gstatic.com/generate_204', interval: u.MANUAL_TEST_INTERVAL, idle_timeout: u.MANUAL_TEST_INTERVAL }
		],
		route: { final: 'sb-test-direct', default_domain_resolver: 'sb-test-dns' },
		experimental: { clash_api: { external_controller: '127.0.0.1:' + TEST_PORT, secret: TEST_SECRET } }
	};
	if (length(nodes.endpoints))
		cfg.endpoints = map(nodes.endpoints, fix);
	return { config: cfg, members: members };
}

function test_api(path, timeout) {
	return api({ main: { api_port: TEST_PORT, api_secret: TEST_SECRET } }, 'GET', path, null, timeout);
}

// tags: array of node tags, or null for all. Returns { ok, delays, skipped }.
export function offline_test(conf, tags) {
	let bin = u.core_path(conf.main);
	if (!bin)
		return { ok: false, error: 'sing-box binary not found' };
	let nodes = test_nodes(conf);
	if (!length(nodes.outbounds) && !length(nodes.endpoints))
		return { ok: false, error: 'no nodes to test' };

	u.exec('rm -rf ' + u.shq(TEST_DIR));
	u.mkdirp(TEST_DIR);
	let skipped = [];

	// Xray nodes: temporary sidecar on its own ports
	let xlist = [];
	let plain = [];
	for (let i = 0; i < length(nodes.outbounds); i++) {
		let o = nodes.outbounds[i];
		if (o.type == 'xray' && (tags == null || index(tags, o.tag) >= 0)) {
			let port = u.XRAY_TEST_PORT_BASE + length(xlist);
			push(xlist, { outbound: o, port: port });
			push(plain, xray.socks_outbound(o.tag, port));
		}
		else if (o.type != 'xray')
			push(plain, o);
	}
	nodes.outbounds = plain;
	let xpid = 0;
	if (length(xlist)) {
		let xbin = u.xray_path(conf.main);
		let xr = null;
		if (xbin) {
			let xo = xray_opts(conf, build_ctx_light());
			xr = xray.prepare(xbin, u.xray_version(xbin), xlist, xo, TEST_DIR + '/xray.json');
		}
		let bad = {};
		if (!xbin || !xr.ok) {
			for (let i = 0; i < length(xlist); i++)
				bad[xlist[i].outbound.tag] = xbin ? ('Xray: ' + u.last_line(xr.output)) : 'Xray core not installed';
		}
		else {
			for (let i = 0; i < length(xr.dropped); i++)
				bad[xr.dropped[i].tag] = 'Xray: ' + xr.dropped[i].error;
			let xp = u.exec(u.shq(xbin) + ' run -c ' + u.shq(TEST_DIR + '/xray.json') + ' >/dev/null 2>&1 & echo $!');
			xpid = int(trim(xp.out));
		}
		for (let tag in bad)
			push(skipped, tag + ': ' + bad[tag]);
		nodes.outbounds = filter(nodes.outbounds, (o) => !bad[o.tag]);
		if (!length(nodes.outbounds) && !length(nodes.endpoints)) {
			u.exec('rm -rf ' + u.shq(TEST_DIR));
			return { ok: false, error: (skipped[0] ?? 'no nodes to test') };
		}
	}
	let t = test_config(conf, nodes, tags);
	let cfg = t.config;
	let path = TEST_DIR + '/config.json';
	u.writeatomic(path, sprintf('%J', cfg));
	let chk = check_config(bin, path);
	for (let tries = 0; !chk.ok && tries < 40; tries++) {
		let bad = quarantine_target(cfg, chk.output);
		if (!bad || bad == TEST_GROUP)
			break;
		drop_node(cfg, bad);
		push(skipped, bad + ': ' + split(chk.output, '\n')[0]);
		u.writeatomic(path, sprintf('%J', cfg));
		chk = check_config(bin, path);
	}
	if (!chk.ok) {
		if (xpid > 0)
			u.exec('kill -9 ' + xpid + ' 2>/dev/null');
		u.exec('rm -rf ' + u.shq(TEST_DIR));
		return { ok: false, error: 'test configuration rejected: ' + split(chk.output, '\n')[0] };
	}
	let members = filter(cfg.outbounds, (o) => o.tag == TEST_GROUP)[0]?.outbounds ?? [];

	let r = u.exec(u.shq(bin) + ' run -c ' + u.shq(path) + ' -D ' + u.shq(TEST_DIR) + ' --disable-color >/dev/null 2>&1 & echo $!');
	let pid = int(trim(r.out));
	let ready = false;
	for (let i = 0; i < 20 && !ready; i++) {
		if (test_api('/version', 1).ok)
			ready = true;
		else
			system('sleep 0.3');
	}
	let delays = {};
	if (ready) {
		let to = 5000;
		let url = enc(conf.main?.urltest_url ?? 'https://www.gstatic.com/generate_204');
		let res = test_api('/group/' + enc(TEST_GROUP) + '/delay?timeout=' + to + '&url=' + url, 120);
		let d = res.ok ? (res.data ?? {}) : {};
		for (let i = 0; i < length(members); i++)
			delays[members[i]] = (type(d[members[i]]) == 'int' && d[members[i]] > 0) ? d[members[i]] : 0;
	}
	if (pid > 0)
		u.exec('kill ' + pid + ' 2>/dev/null; sleep 0.2; kill -9 ' + pid + ' 2>/dev/null');
	if (xpid > 0)
		u.exec('kill ' + xpid + ' 2>/dev/null; sleep 0.2; kill -9 ' + xpid + ' 2>/dev/null');
	u.exec('rm -rf ' + u.shq(TEST_DIR));
	if (!ready)
		return { ok: false, error: 'test instance did not start' };

	// merge with earlier results (single-node tests keep the others)
	let prev = u.readjson(DELAY_FILE);
	let all = (prev && prev.source == nodes.source) ? (prev.delays ?? {}) : {};
	for (let k in delays)
		all[k] = delays[k];
	u.writejson(DELAY_FILE, { time: time(), source: nodes.source, delays: all });
	return { ok: true, delays: delays, skipped: skipped };
};

// ---------------------------------------------------------------------------
// Maximum performance (system tuning)
// ---------------------------------------------------------------------------

const PERF_SYSCTL = '/etc/sysctl.d/90-singbox-perf.conf';
const PERF_STATE = '/etc/singbox/perf-state.json';

function mem_total_mb() {
	let m = match(readfile('/proc/meminfo') ?? '', /MemTotal:[ \t]+([0-9]+)/);
	return m ? int(int(m[1]) / 1024) : 0;
}

// Go runtime settings for the cores: garbage collection only near the memory
// limit (more RAM, much less CPU spent on GC). Printed as "VAR=value" lines
// for the init script.
// Go runtime memory settings for the cores (Settings > Performance > Memory):
//   maximum  - garbage collection only near 65% of RAM: least CPU, most RAM
//   balanced - collect less often than Go's default, capped at about a
//              quarter of RAM: most of the CPU saving with moderate RAM
//   low      - Go's default (least RAM)
// Printed as VAR=value lines for the init script.
export function perf_env(conf, which) {
	let mode = conf.main?.mem_mode ?? 'balanced';
	if (mode != 'maximum' && mode != 'balanced')
		return [];
	let mb = mem_total_mb();
	// small routers keep Go's default garbage collection
	if (mb < 384)
		return [];
	let with_xray = u.xray_path(conf.main) && stat(u.XRAY_CONFIG_OUT);
	let share;
	if (mode == 'maximum')
		share = (which == 'xray') ? 0.2 : (with_xray ? 0.5 : 0.65);
	else
		share = (which == 'xray') ? 0.1 : (with_xray ? 0.2 : 0.25);
	let lim = int(mb * share);
	if (lim < 48)
		return [];
	return [ (mode == 'maximum') ? 'GOGC=off' : 'GOGC=200', 'GOMEMLIMIT=' + lim + 'MiB' ];
};

function has_bbr() {
	if (index(readfile('/proc/sys/net/ipv4/tcp_available_congestion_control') ?? '', 'bbr') >= 0)
		return true;
	u.exec('modprobe tcp_bbr');
	return index(readfile('/proc/sys/net/ipv4/tcp_available_congestion_control') ?? '', 'bbr') >= 0;
}

// Apply (or undo) system tuning. Previous values are remembered so that
// switching the option off restores them.
export function perf_apply(conf) {
	let on = u.bool(conf.main?.max_perf, true);
	let st = u.readjson(PERF_STATE) ?? {};
	let done = [];
	let c = cursor();

	if (on) {
		// bigger socket buffers (QUIC / Hysteria2 / high-latency links), BBR
		let L = [
			'# written by luci-app-singbox (Settings > Performance > Maximum performance)',
			'net.core.rmem_max=33554432',
			'net.core.wmem_max=33554432',
			'net.core.rmem_default=1048576',
			'net.core.wmem_default=1048576',
			'net.ipv4.tcp_rmem=4096 131072 33554432',
			'net.ipv4.tcp_wmem=4096 65536 33554432',
			'net.core.netdev_max_backlog=16384',
			'net.core.somaxconn=8192',
			'net.ipv4.tcp_fastopen=3',
			'net.ipv4.tcp_mtu_probing=1'
		];
		if (has_bbr()) {
			push(L, 'net.core.default_qdisc=fq_codel');
			push(L, 'net.ipv4.tcp_congestion_control=bbr');
			push(done, 'bbr');
		}
		// remember the values in effect before the first change
		if (type(st.sysctl) != 'object') {
			st.sysctl = {};
			for (let i = 1; i < length(L); i++) {
				let k = split(L[i], '=')[0];
				let v = readfile('/proc/sys/' + replace(k, /\./g, '/'));
				if (v != null)
					st.sysctl[k] = trim(replace(v, /[ \t]+/g, ' '));
			}
		}
		u.mkdirp('/etc/sysctl.d');
		u.writeatomic(PERF_SYSCTL, join('\n', L) + '\n');
		u.exec('sysctl -q -p ' + u.shq(PERF_SYSCTL));
		push(done, 'sysctl');

		// spread packet processing over all CPU cores
		c.load('network');
		let ps = c.get('network', 'globals', 'packet_steering');
		if (ps != '2') {
			if (st.packet_steering == null)
				st.packet_steering = ps ?? '';
			if (!c.get('network', 'globals'))
				c.set('network', 'globals', 'globals');
			c.set('network', 'globals', 'packet_steering', '2');
			c.commit('network');
			if (access('/etc/init.d/packet_steering', 'x'))
				u.exec('/etc/init.d/packet_steering start');
			else if (access('/usr/libexec/network/packet-steering.uc', 'x'))
				u.exec('/usr/libexec/network/packet-steering.uc 2');
			push(done, 'packet_steering');
		}

		// software flow offloading: direct (non-proxied) traffic bypasses most of the stack
		c.load('firewall');
		let def = null;
		c.foreach('firewall', 'defaults', (sec) => { if (def == null) def = sec['.name']; });
		if (def && c.get('firewall', def, 'flow_offloading') != '1') {
			if (st.flow_offloading == null)
				st.flow_offloading = c.get('firewall', def, 'flow_offloading') ?? '';
			c.set('firewall', def, 'flow_offloading', '1');
			c.commit('firewall');
			u.exec('fw4 -q reload');
			push(done, 'flow_offloading');
		}

		// interrupts over all cores (when the irqbalance package is installed)
		if (access('/etc/init.d/irqbalance', 'x')) {
			c.load('irqbalance');
			let ib = null;
			c.foreach('irqbalance', 'irqbalance', (sec) => { if (ib == null) ib = sec['.name']; });
			if (ib && c.get('irqbalance', ib, 'enabled') != '1') {
				if (st.irqbalance == null)
					st.irqbalance = c.get('irqbalance', ib, 'enabled') ?? '0';
				c.set('irqbalance', ib, 'enabled', '1');
				c.commit('irqbalance');
			}
			u.exec('/etc/init.d/irqbalance enable; /etc/init.d/irqbalance start');
			push(done, 'irqbalance');
		}
		st.active = true;
		u.writejson(PERF_STATE, st);
		return { ok: true, active: true, applied: done };
	}

	// switched off: undo what was changed
	if (stat(PERF_SYSCTL)) {
		u.remove(PERF_SYSCTL);
		for (let k in (st.sysctl ?? {}))
			u.exec('sysctl -q -w ' + u.shq(k + '=' + st.sysctl[k]));
		push(done, 'sysctl');
	}
	if (st.packet_steering != null) {
		c.load('network');
		if (st.packet_steering == '')
			c.delete('network', 'globals', 'packet_steering');
		else
			c.set('network', 'globals', 'packet_steering', st.packet_steering);
		c.commit('network');
		if (access('/etc/init.d/packet_steering', 'x'))
			u.exec('/etc/init.d/packet_steering start');
		push(done, 'packet_steering');
	}
	if (st.flow_offloading != null) {
		c.load('firewall');
		let def = null;
		c.foreach('firewall', 'defaults', (sec) => { if (def == null) def = sec['.name']; });
		if (def) {
			if (st.flow_offloading == '')
				c.delete('firewall', def, 'flow_offloading');
			else
				c.set('firewall', def, 'flow_offloading', st.flow_offloading);
			c.commit('firewall');
			u.exec('fw4 -q reload');
		}
		push(done, 'flow_offloading');
	}
	if (st.irqbalance != null && access('/etc/init.d/irqbalance', 'x')) {
		c.load('irqbalance');
		let ib = null;
		c.foreach('irqbalance', 'irqbalance', (sec) => { if (ib == null) ib = sec['.name']; });
		if (ib) {
			c.set('irqbalance', ib, 'enabled', st.irqbalance);
			c.commit('irqbalance');
		}
		push(done, 'irqbalance');
	}
	u.remove(PERF_STATE);
	return { ok: true, active: false, reverted: done };
};

export function perf_status() {
	let st = u.readjson(PERF_STATE);
	let c = cursor();
	c.load('network');
	c.load('firewall');
	let off = null;
	c.foreach('firewall', 'defaults', (sec) => { if (off == null) off = sec.flow_offloading ?? '0'; });
	return {
		active: !!st?.active,
		cpus: length(filter(split(readfile('/proc/cpuinfo') ?? '', '\n'), (l) => match(l, /^processor[ \t]*:/))),
		mem_mb: mem_total_mb(),
		bbr: trim(readfile('/proc/sys/net/ipv4/tcp_congestion_control') ?? '') == 'bbr',
		packet_steering: c.get('network', 'globals', 'packet_steering') ?? '0',
		flow_offloading: off == '1',
		irqbalance_installed: !!access('/etc/init.d/irqbalance', 'x'),
		env: perf_env(u.load_conf(), 'sing-box')
	};
};

// ---------------------------------------------------------------------------
// App self-update (from the GitHub repository)
// ---------------------------------------------------------------------------

const APP_REPO = 'Danialrostamani/Luci-app-Singbox';
const APP_FILE = 'luci-app-singbox.tar.gz';
const APP_WORK = '/tmp/singbox-app-update';
const APP_LOG = '/tmp/singbox-app-update.log';
const UPDATES_FILE = u.RUN_DIR + '/updates.json';

export function app_version() {
	let v = trim(readfile('/usr/share/singbox/VERSION') ?? '');
	return (v != '') ? v : null;
};

// a > b for dotted versions ("1.4.10" > "1.4.9")
function ver_newer(a, b) {
	let x = map(split('' + a, '.'), (n) => int(n)), y = map(split('' + b, '.'), (n) => int(n));
	for (let i = 0; i < 4; i++) {
		let p = x[i] ?? 0, q = y[i] ?? 0;
		if (p != q)
			return p > q;
	}
	return false;
}

// download + unpack the release archive; returns { ok, dir, version, error }
function app_fetch(conf) {
	u.exec('rm -rf ' + u.shq(APP_WORK));
	u.mkdirp(APP_WORK);
	let urls = [
		'https://raw.githubusercontent.com/' + APP_REPO + '/main/' + APP_FILE,
		'https://github.com/' + APP_REPO + '/raw/main/' + APP_FILE,
		'https://cdn.jsdelivr.net/gh/' + APP_REPO + '@main/' + APP_FILE
	];
	let err = null;
	for (let i = 0; i < length(urls); i++) {
		let f = APP_WORK + '/' + APP_FILE;
		let dl = download(conf, urls[i] + '?t=' + time(), f, { timeout: 120 });
		if (!dl.ok) {
			err = dl.error;
			continue;
		}
		let x = u.exec('tar -xzf ' + u.shq(f) + ' -C ' + u.shq(APP_WORK));
		let inst = trim(u.exec('ls ' + u.shq(APP_WORK) + '/*/install.sh 2>/dev/null | head -n 1').out);
		if (x.code != 0 || inst == '') {
			err = 'archive from ' + urls[i] + ' is not valid';
			continue;
		}
		let dir = replace(inst, /\/install\.sh$/, '');
		let ver = trim(readfile(dir + '/VERSION') ?? '');
		return { ok: true, dir: dir, version: ver != '' ? ver : null, via: dl.via };
	}
	u.exec('rm -rf ' + u.shq(APP_WORK));
	return { ok: false, error: u.last_line(err ?? 'download failed') };
}

export function app_check(conf) {
	let cur = app_version();
	let r = app_fetch(conf);
	u.exec('rm -rf ' + u.shq(APP_WORK));
	if (!r.ok)
		return { ok: false, current: cur, error: r.error };
	if (r.version) {
		let c = u.readjson(UPDATES_FILE) ?? {};
		c.app = r.version;
		c.installed = cur;
		u.writejson(UPDATES_FILE, c);
	}
	return { ok: true, current: cur, latest: r.version, update: r.version != null && (cur == null || r.version != cur), newer: r.version != null && cur != null && ver_newer(r.version, cur) };
};

// ---------------------------------------------------------------------------
// Update badges: latest versions of the app and both cores, cached in RAM and
// refreshed in the background (at most every 6 hours, or on demand).
// ---------------------------------------------------------------------------

const UPDATES_TTL = 3600;
const UPDATES_LOCK = u.RUN_DIR + '/updates.lock';

function app_latest(conf) {
	let tmp = u.RUN_DIR + '/app-version.txt';
	let urls = [
		'https://raw.githubusercontent.com/' + APP_REPO + '/main/VERSION',
		'https://github.com/' + APP_REPO + '/raw/main/VERSION'
	];
	for (let i = 0; i < length(urls); i++) {
		let dl = download(conf, urls[i] + '?t=' + time(), tmp, { timeout: 20 });
		let v = dl.ok ? trim(readfile(tmp) ?? '') : '';
		u.remove(tmp);
		if (match(v, /^[0-9]+(\.[0-9]+)*$/))
			return v;
	}
	return null;
}

function plain_ver(v) {
	let m = match('' + (v ?? ''), /([0-9]+\.[0-9]+(\.[0-9]+)?)/);
	return m ? m[1] : null;
}

// Query GitHub (run in the background by updates_status)
export function updates_refresh(conf) {
	u.mkdirp(u.RUN_DIR);
	let old = u.readjson(UPDATES_FILE) ?? {};
	let r = { checked: time(), installed: app_version() };
	r.app = app_latest(conf) ?? old.app;
	r.singbox = latest_by_redirect(conf, 'SagerNet/sing-box') ?? old.singbox;
	if (u.xray_version(u.xray_path(conf.main)))
		r.xray = latest_by_redirect(conf, 'XTLS/Xray-core') ?? old.xray;
	if (r.app == null && r.singbox == null)
		r.error = 'GitHub not reachable';
	u.writejson(UPDATES_FILE, r);
	u.remove(UPDATES_LOCK);
	return r;
};

// Cached result compared with what is installed right now
export function updates_status(conf, force) {
	let c = u.readjson(UPDATES_FILE) ?? {};
	let now = time();
	let lock = stat(UPDATES_LOCK);
	let checking = !!(lock && now - lock.mtime < 300);
	let app = app_version();
	// the app was updated since the last check (in the app or with the
	// script): that result is stale, check again right away
	let moved = (c.checked != null && c.installed != app);
	// failed checks are retried after 30 minutes, good ones after 1 hour
	let ttl = c.error ? 1800 : UPDATES_TTL;
	if (!checking && (force || moved || now - (c.checked ?? 0) >= ttl)) {
		u.mkdirp(u.RUN_DIR);
		writefile(UPDATES_LOCK, '' + now);
		system('( ' + CTL + ' updates-check ) >/dev/null 2>&1 &');
		checking = true;
	}
	let sb = plain_ver(u.core_version(u.core_path(conf.main))?.string);
	let xv = u.xray_version(u.xray_path(conf.main));
	let xr = xv ? plain_ver(xv.string) : null;
	let res = {
		checked: c.checked, checking: checking, error: c.error,
		app: { current: app, latest: c.app, update: !!(!moved && c.app && app && c.app != app) },
		singbox: { current: sb, latest: c.singbox, update: !!(c.singbox && sb && ver_newer(c.singbox, sb)) },
		xray: { current: xr, latest: xr ? c.xray : null, update: !!(xr && c.xray && ver_newer(c.xray, xr)) }
	};
	res.count = (res.app.update ? 1 : 0) + (res.singbox.update ? 1 : 0) + (res.xray.update ? 1 : 0);
	return res;
};

// Download the newest release and run its installer (settings and the chosen
// core are kept). The installer restarts rpcd and the service.
export function app_update(conf) {
	let cur = app_version();
	let r = app_fetch(conf);
	if (!r.ok)
		return { ok: false, error: r.error };
	let x = u.exec('umask 022; cd ' + u.shq(r.dir) + ' && sh ./install.sh </dev/null >' + u.shq(APP_LOG) + ' 2>&1; echo "rc=$?"');
	u.exec('rm -rf ' + u.shq(APP_WORK));
	let rc = match(x.out, /rc=([0-9]+)/);
	if (!rc || int(rc[1]) != 0) {
		let log = replace(readfile(APP_LOG) ?? '', /\x1b\[[0-9;]*m/g, '');
		return { ok: false, error: 'installer failed: ' + u.last_line(log), log: APP_LOG };
	}
	return { ok: true, from: cur, version: r.version ?? app_version(), log: APP_LOG };
};

// ---------------------------------------------------------------------------
// Speed test of one node (temporary instance with a local mixed port)
// ---------------------------------------------------------------------------

export const SPEED_FILE = '/var/run/singbox/speed.json';
const SPEED_DIR = '/var/run/singbox/speed';
const SPEED_PORT = 39890;
const SPEED_XRAY_PORT = 39950;
const SPEED_DOWN_URL = 'https://speed.cloudflare.com/__down?bytes=200000000';
const SPEED_UP_URL = 'https://speed.cloudflare.com/__up';

// a TCP port in LISTEN state on this machine (/proc/net/tcp, state 0A)
function port_listening(port) {
	let hex = uc(sprintf('%04x', port));
	let t = (readfile('/proc/net/tcp') ?? '') + (readfile('/proc/net/tcp6') ?? '');
	return match(t, regexp(':' + hex + ' [0-9A-F:]+ 0A')) != null;
}

function curl_speed(cmd) {
	let r = u.exec(cmd);
	let m = match(r.out, /SPEED=([0-9.]+) SIZE=([0-9.]+) TIME=([0-9.]+)/);
	if (!m)
		return null;
	return { bps: +m[1], bytes: +m[2], secs: +m[3] };
}

// Downloads (and uploads) through the node for a few seconds.
// Works whether the service runs or not; never touches the running config.
export function speed_test(conf, tag, secs) {
	secs = u.toint(secs, 10);
	if (secs < 3 || secs > 30)
		secs = 10;
	let bin = u.core_path(conf.main);
	if (!bin)
		return { ok: false, error: 'sing-box binary not found' };
	let nodes = test_nodes(conf);
	let node = null, ep = false;
	for (let i = 0; i < length(nodes.outbounds); i++)
		if (nodes.outbounds[i].tag == tag)
			node = u.clone(nodes.outbounds[i]);
	for (let i = 0; i < length(nodes.endpoints) && !node; i++)
		if (nodes.endpoints[i].tag == tag) {
			node = u.clone(nodes.endpoints[i]);
			ep = true;
		}
	if (!node)
		return { ok: false, error: 'node not found: ' + tag };
	delete node.detour;
	delete node.domain_resolver;
	delete node.domain_strategy;

	u.exec('rm -rf ' + u.shq(SPEED_DIR));
	u.mkdirp(SPEED_DIR);
	let opts = xray_opts(conf, build_ctx_light());
	let xpid = 0;
	if (node.type == 'xray') {
		let xbin = u.xray_path(conf.main);
		if (!xbin)
			return { ok: false, error: 'this node needs the Xray core' };
		let xr = xray.prepare(xbin, u.xray_version(xbin), [ { outbound: node, port: SPEED_XRAY_PORT } ], opts, SPEED_DIR + '/xray.json');
		if (!xr.ok || !length(xr.nodes))
			return { ok: false, error: 'Xray: ' + u.last_line(xr.output) };
		xpid = int(trim(u.exec(u.shq(xbin) + ' run -c ' + u.shq(SPEED_DIR + '/xray.json') + ' >/dev/null 2>&1 & echo $!').out));
		node = xray.socks_outbound(tag, SPEED_XRAY_PORT);
	}
	else
		node = gen.apply_performance(node, conf.main);

	let up = filter(wan_dns(), (ip) => u.is_ip(ip) && substr(ip, 0, 4) != '127.' && ip != '::1');
	let route = { final: tag, default_domain_resolver: 'sb-speed-dns' };
	// the temporary instance must bypass the running TPROXY / TUN setup
	if (opts.mark)
		route.default_mark = opts.mark;
	if (opts.iface)
		route.default_interface = opts.iface;
	let cfg = {
		log: { disabled: true },
		dns: { servers: [ { type: 'udp', tag: 'sb-speed-dns', server: length(up) ? up[0] : '1.1.1.1' } ] },
		inbounds: [ { type: 'mixed', tag: 'sb-speed-in', listen: '127.0.0.1', listen_port: SPEED_PORT } ],
		outbounds: ep ? [ { type: 'direct', tag: 'sb-speed-direct' } ] : [ node, { type: 'direct', tag: 'sb-speed-direct' } ],
		route: route
	};
	if (ep)
		cfg.endpoints = [ node ];
	let path = SPEED_DIR + '/config.json';
	u.writeatomic(path, sprintf('%J', cfg));
	let chk = check_config(bin, path);
	if (!chk.ok) {
		if (xpid > 0)
			u.exec('kill -9 ' + xpid + ' 2>/dev/null');
		u.exec('rm -rf ' + u.shq(SPEED_DIR));
		return { ok: false, error: 'test configuration rejected: ' + u.last_line(chk.output) };
	}
	let pid = int(trim(u.exec(u.shq(bin) + ' run -c ' + u.shq(path) + ' -D ' + u.shq(SPEED_DIR) + ' --disable-color >/dev/null 2>&1 & echo $!').out));
	let ready = false;
	for (let i = 0; i < 30 && !ready; i++) {
		if (port_listening(SPEED_PORT))
			ready = true;
		else
			system('sleep 0.3');
	}
	let px = '-x socks5h://127.0.0.1:' + SPEED_PORT;
	let wfmt = u.shq('SPEED=%{speed_download} SIZE=%{size_download} TIME=%{time_total}');
	let res = { ok: false };
	if (ready) {
		// warm-up request: connection + TLS setup should not count against the speed
		let ping = u.exec('curl -s -o /dev/null -m 8 ' + px + ' -w ' + u.shq('%{time_starttransfer}') + ' https://www.gstatic.com/generate_204');
		let down = curl_speed('curl -s -o /dev/null -m ' + secs + ' ' + px + ' -w ' + wfmt + ' ' + u.shq(conf.main?.speedtest_url ?? SPEED_DOWN_URL));
		let upr = curl_speed('head -c 100000000 /dev/zero | curl -s -o /dev/null -m ' + secs + ' ' + px +
			' -X POST -H "Content-Type: application/octet-stream" --data-binary @- -w ' +
			u.shq('SPEED=%{speed_upload} SIZE=%{size_upload} TIME=%{time_total}') + ' ' + u.shq(SPEED_UP_URL));
		let mbps = (x) => (x && x.bytes > 0) ? int(x.bps * 8 / 10000) / 100 : 0;
		res = {
			ok: (down && down.bytes > 0) ? true : false,
			down_mbps: mbps(down),
			up_mbps: mbps(upr),
			down_mb: down ? int(down.bytes / 10485.76) / 100 : 0,
			ping_ms: int(+(trim(ping.out) || 0) * 1000),
			time: time()
		};
		if (!res.ok)
			res.error = 'no data received through the node';
	}
	else
		res.error = 'test instance did not start';
	if (pid > 0)
		u.exec('kill ' + pid + ' 2>/dev/null; sleep 0.2; kill -9 ' + pid + ' 2>/dev/null');
	if (xpid > 0)
		u.exec('kill ' + xpid + ' 2>/dev/null; sleep 0.2; kill -9 ' + xpid + ' 2>/dev/null');
	u.exec('rm -rf ' + u.shq(SPEED_DIR));

	let all = u.readjson(SPEED_FILE) ?? {};
	all[tag] = res.ok ? { down_mbps: res.down_mbps, up_mbps: res.up_mbps, ping_ms: res.ping_ms, time: res.time } : { error: res.error, time: time() };
	u.writejson(SPEED_FILE, all);
	res.tag = tag;
	return res;
};

// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// Tools: Network Quality (RPM) and STUN / NAT test, like the sing-box apps.
// Runs "sing-box tools …" through one node (or direct) in a temporary
// configuration that bypasses the running TPROXY / TUN setup. sing-box 1.14+.
// ---------------------------------------------------------------------------

const TOOLS_DIR = '/var/run/singbox/tools';
const TOOLS_FILE = '/var/run/singbox/tools.json';
const TOOLS_XRAY_PORT = 39960;

function tool_line(out, label) {
	let lines = split(replace('' + out, /\r/g, '\n'), '\n');
	for (let i = length(lines) - 1; i >= 0; i--) {
		let l = trim(lines[i]);
		if (substr(l, 0, length(label)) == label)
			return trim(substr(l, length(label)));
	}
	return null;
}

export function tool_results() {
	return u.readjson(TOOLS_FILE) ?? {};
};

// opts (all optional): url, serial, http3, runtime (s) for networkquality;
// server ("host:port") for stun
export function net_tool(conf, tool, tag, topts) {
	if (tool != 'networkquality' && tool != 'stun')
		return { ok: false, error: 'unknown tool' };
	topts = (type(topts) == 'object') ? topts : {};
	let runtime = u.toint(topts.runtime, 30);
	if (runtime < 5 || runtime > 120)
		runtime = 30;
	let url = trim('' + (topts.url ?? ''));
	if (url != '' && !match(url, /^https?:\/\/[^ ]+$/))
		return { ok: false, error: 'invalid config URL' };
	let server = trim('' + (topts.server ?? ''));
	if (server != '' && !match(server, /^[A-Za-z0-9.:\[\]_-]+:[0-9]+$/))
		return { ok: false, error: 'invalid STUN server (host:port)' };
	tag = (tag == null || tag == '') ? 'direct' : tag;
	let bin = u.core_path(conf.main);
	if (!bin)
		return { ok: false, error: 'sing-box binary not found' };
	let ver = u.core_version(bin);
	if (!u.ver_ge(ver, 1, 14))
		return { ok: false, error: 'needs sing-box 1.14 or newer (installed: ' + (ver?.string ?? '?') + ') - update the core on the Update tab' };

	u.exec('rm -rf ' + u.shq(TOOLS_DIR));
	u.mkdirp(TOOLS_DIR);
	let opts = xray_opts(conf, build_ctx_light());
	let xpid = 0;
	let outbounds = [ { type: 'direct', tag: 'direct' } ];
	let endpoints = [];
	if (tag != 'direct') {
		let nodes = test_nodes(conf);
		let node = null, ep = false;
		for (let i = 0; i < length(nodes.outbounds); i++)
			if (nodes.outbounds[i].tag == tag)
				node = u.clone(nodes.outbounds[i]);
		for (let i = 0; i < length(nodes.endpoints) && !node; i++)
			if (nodes.endpoints[i].tag == tag) {
				node = u.clone(nodes.endpoints[i]);
				ep = true;
			}
		if (!node)
			return { ok: false, error: 'node not found: ' + tag };
		delete node.detour;
		delete node.domain_resolver;
		delete node.domain_strategy;
		if (node.type == 'xray') {
			let xbin = u.xray_path(conf.main);
			if (!xbin)
				return { ok: false, error: 'this node needs the Xray core' };
			let xr = xray.prepare(xbin, u.xray_version(xbin), [ { outbound: node, port: TOOLS_XRAY_PORT } ], opts, TOOLS_DIR + '/xray.json');
			if (!xr.ok || !length(xr.nodes))
				return { ok: false, error: 'Xray: ' + u.last_line(xr.output) };
			xpid = int(trim(u.exec(u.shq(xbin) + ' run -c ' + u.shq(TOOLS_DIR + '/xray.json') + ' >/dev/null 2>&1 & echo $!').out));
			system('sleep 1');
			node = xray.socks_outbound(tag, TOOLS_XRAY_PORT);
		}
		else
			node = gen.apply_performance(node, conf.main);
		if (ep)
			push(endpoints, node);
		else
			push(outbounds, node);
	}

	let up = filter(wan_dns(), (ip) => u.is_ip(ip) && substr(ip, 0, 4) != '127.' && ip != '::1');
	let route = { final: tag, default_domain_resolver: 'sb-tool-dns' };
	if (opts.mark)
		route.default_mark = opts.mark;
	if (opts.iface)
		route.default_interface = opts.iface;
	let cfg = {
		log: { disabled: true },
		dns: { servers: [ { type: 'udp', tag: 'sb-tool-dns', server: length(up) ? up[0] : '1.1.1.1' } ] },
		outbounds: outbounds,
		route: route
	};
	if (length(endpoints))
		cfg.endpoints = endpoints;
	let path = TOOLS_DIR + '/config.json';
	u.writeatomic(path, sprintf('%J', cfg));

	let cmd = u.shq(bin) + ' tools ' + tool + ' -c ' + u.shq(path) + ' -D ' + u.shq(TOOLS_DIR) + ' --disable-color -o ' + u.shq(tag);
	if (tool == 'networkquality') {
		cmd += ' --max-runtime ' + runtime;
		if (url != '')
			cmd += ' --config-url ' + u.shq(url);
		if (u.bool(topts.serial, false))
			cmd += ' --serial';
		if (u.bool(topts.http3, false))
			cmd += ' --http3';
	}
	else if (server != '')
		cmd += ' -s ' + u.shq(server);
	let limit = (tool == 'networkquality') ? runtime + 25 : 45;
	// OpenWrt has no "timeout" command: stop the test by hand
	let of = TOOLS_DIR + '/out.txt';
	let x = u.exec('( ' + cmd + ' >' + u.shq(of) + ' 2>&1 & p=$!; ( i=0; while [ $i -lt ' + limit + ' ] && kill -0 $p 2>/dev/null; do sleep 1; i=$((i+1)); done; kill -9 $p 2>/dev/null ) </dev/null >/dev/null 2>&1 & wait $p; exit $? )');
	let out = readfile(of) ?? '';
	if (xpid > 0)
		u.exec('kill -9 ' + xpid + ' 2>/dev/null');
	u.exec('rm -rf ' + u.shq(TOOLS_DIR));

	let res = { ok: false, tool: tool, node: tag, time: time(),
		opts: (tool == 'networkquality') ? { url: url, serial: u.bool(topts.serial, false), http3: u.bool(topts.http3, false), runtime: runtime } : { server: server } };
	if (tool == 'networkquality') {
		let dl = tool_line(out, 'Download Capacity:'), ul = tool_line(out, 'Upload Capacity:');
		let drpm = tool_line(out, 'Download Responsiveness:'), urpm = tool_line(out, 'Upload Responsiveness:');
		let idle = tool_line(out, 'Idle Latency:');
		let first = (v) => v ? replace(v, /[ \t]+Accuracy:.*$/, '') : null;
		let acc = (v) => { let m = v ? match(v, /Accuracy:[ \t]*(.+)$/) : null; return m ? m[1] : null; };
		if (dl != null) {
			res.ok = true;
			res.idle_latency = idle;
			res.download = first(dl);
			res.download_accuracy = acc(dl);
			res.upload = first(ul);
			res.upload_accuracy = acc(ul);
			res.download_rpm = first(drpm);
			res.upload_rpm = first(urpm);
		}
	}
	else {
		let ext = tool_line(out, 'External Address:');
		if (ext != null) {
			res.ok = true;
			res.external = ext;
			res.latency = tool_line(out, 'Latency:');
			res.mapping = tool_line(out, 'NAT Mapping:');
			res.filtering = tool_line(out, 'NAT Filtering:');
			if (index(out, 'NAT Type Detection: not supported') >= 0)
				res.nat_note = 'NAT type detection not supported by the STUN server';
		}
	}
	if (!res.ok) {
		let err = filter(map(split(replace(out, /\r/g, '\n'), '\n'), (l) => trim(l)), (l) => l != '' && substr(l, 0, 4) != '====');
		res.error = length(err) ? replace(err[length(err) - 1], /^(FATAL|ERROR)\[[0-9]+\][ \t]*/, '') : (x.code == 137 ? 'timed out after ' + limit + ' s' : 'no result');
	}
	let all = u.readjson(TOOLS_FILE) ?? {};
	all[tool] = res;
	u.writejson(TOOLS_FILE, all);
	return res;
};

// Backup / restore
// ---------------------------------------------------------------------------

// Settings (/etc/config/singbox), local profiles and the custom config.
// Subscription node lists and remote profiles are downloaded again after a
// restore, which keeps the file small.
export function backup_create(conf) {
	let cfg = u.exec('uci export singbox');
	if (cfg.code != 0)
		return { ok: false, error: 'uci export failed' };
	let files = {};
	for (let i = 0; i < length(conf.profiles ?? []); i++) {
		let p = conf.profiles[i];
		if ((p.type ?? 'remote') != 'local')
			continue;
		let t = readfile(profile_file(p.id));
		if (t != null)
			files['profiles/' + p.id + '.json'] = t;
	}
	let custom = readfile(u.CUSTOM_CONFIG);
	if (custom != null && custom != '')
		files['custom.json'] = custom;
	return {
		ok: true,
		backup: {
			app: 'luci-app-singbox',
			version: app_version(),
			created: time(),
			hostname: trim(readfile('/proc/sys/kernel/hostname') ?? ''),
			config: cfg.out,
			files: files
		}
	};
};

export function backup_restore(conf, text) {
	let b = null;
	try { b = json(text); } catch (e) { return { ok: false, error: 'not a backup file (invalid JSON)' }; }
	if (type(b) != 'object' || b.app != 'luci-app-singbox' || type(b.config) != 'string')
		return { ok: false, error: 'not a luci-app-singbox backup' };
	if (!match(b.config, /(^|\n)config singbox 'main'/))
		return { ok: false, error: 'the backup has no settings section' };
	u.mkdirp(u.RUN_DIR);
	let tmp = u.RUN_DIR + '/restore.uci';
	writefile(tmp, b.config);
	// keep the current file until the import has worked
	u.exec('cp /etc/config/singbox ' + u.shq(u.RUN_DIR + '/singbox.before-restore'));
	let r = u.exec('uci -q -f ' + u.shq(tmp) + ' import singbox && uci -q commit singbox');
	u.remove(tmp);
	if (r.code != 0) {
		u.exec('cp ' + u.shq(u.RUN_DIR + '/singbox.before-restore') + ' /etc/config/singbox');
		return { ok: false, error: 'could not import the settings: ' + u.last_line(r.out) };
	}
	let n = 0;
	for (let k in (b.files ?? {})) {
		let m = match(k, /^profiles\/([A-Za-z0-9_]+)\.json$/);
		let dest = null;
		if (m) {
			u.mkdirp(u.PROFILE_DIR);
			dest = profile_file(m[1]);
		}
		else if (k == 'custom.json')
			dest = u.CUSTOM_CONFIG;
		if (dest && type(b.files[k]) == 'string' && u.writeatomic(dest, b.files[k]))
			n++;
	}
	return { ok: true, files: n, version: b.version, created: b.created };
};

// ---------------------------------------------------------------------------
// Telegram notifications
// ---------------------------------------------------------------------------

const NOTIFY_STATE = '/etc/singbox/notify-state.json';

// Sends a message with the bot; through the proxy first (Telegram is often
// blocked), then direct. Returns { ok, error }.
export function tg_send(conf, text) {
	let m = conf.main ?? {};
	let token = trim(m.tg_token ?? ''), chat = trim(m.tg_chat ?? '');
	if (token == '' || chat == '')
		return { ok: false, error: 'bot token and chat ID are required' };
	let base = trim(m.tg_api ?? '');
	if (base == '')
		base = 'https://api.telegram.org';
	base = replace(base, /\/+$/, '');
	let host = trim(readfile('/proc/sys/kernel/hostname') ?? 'OpenWrt');
	let body = sprintf('%J', { chat_id: chat, text: '🛰 ' + host + ' · sing-box\n' + text, disable_web_page_preview: true });
	let tmp = u.RUN_DIR + '/tg-msg.json';
	u.mkdirp(u.RUN_DIR);
	writefile(tmp, body);
	let px = mixed_proxy(conf);
	let tries = px ? [ px, null ] : [ null ];
	let err = '';
	for (let i = 0; i < length(tries); i++) {
		let r = u.exec('curl -s -m 20 ' + (tries[i] ? '-x ' + u.shq(tries[i]) + ' ' : '') +
			'-H "Content-Type: application/json" --data-binary @' + u.shq(tmp) + ' ' + u.shq(base + '/bot' + token + '/sendMessage'));
		let js = null;
		try { js = json(r.out); } catch (e) { js = null; }
		if (js?.ok) {
			u.remove(tmp);
			return { ok: true };
		}
		if (js?.description)
			err = 'Telegram: ' + js.description;
		else if (r.code != 0)
			err = 'cannot reach ' + replace(base, /^https?:\/\//, '') + (tries[i] ? ' through the proxy' : ' directly') + ' (curl error ' + r.code + ')';
		else
			err = 'unexpected answer: ' + substr(u.last_line(r.out), 0, 120);
	}
	u.remove(tmp);
	return { ok: false, error: err };
};

function usage_alerts(conf, st, out) {
	let m = conf.main ?? {};
	let pct = u.toint(m.tg_quota_pct, 90);
	let days = u.toint(m.tg_expiry_days, 3);
	let items = [];
	for (let i = 0; i < length(conf.subs ?? []); i++)
		if (u.bool(conf.subs[i].enabled, true))
			push(items, { key: 'sub:' + conf.subs[i].id, name: conf.subs[i].name ?? conf.subs[i].id, info: sub_info(conf.subs[i].id)?.info });
	for (let i = 0; i < length(conf.profiles ?? []); i++)
		push(items, { key: 'prof:' + conf.profiles[i].id, name: conf.profiles[i].name ?? conf.profiles[i].id, info: profile_info(conf.profiles[i].id)?.info });
	let now = time();
	for (let i = 0; i < length(items); i++) {
		let it = items[i], inf = it.info ?? {};
		if (u.bool(m.tg_quota, true) && inf.total > 0) {
			let used = (inf.upload ?? 0) + (inf.download ?? 0);
			let p = int(used * 100 / inf.total);
			let k = it.key + ':quota';
			if (p >= pct && !st[k]) {
				st[k] = now;
				push(out, sprintf('📊 "%s": %d%% of the data used (%.1f of %.1f GB).', it.name, p, used / 1073741824, inf.total / 1073741824));
			}
			else if (p < pct && st[k])
				delete st[k];
		}
		if (u.bool(m.tg_expiry, true) && inf.expire > 0) {
			let left = inf.expire - now;
			let k = it.key + ':expire:' + inf.expire;
			if (left < days * 86400 && !st[k]) {
				st[k] = now;
				push(out, left > 0 ? sprintf('⏳ "%s" expires in %.1f days.', it.name, left / 86400) : sprintf('⛔ "%s" has expired.', it.name));
			}
		}
	}
}

// Called every minute by the watchdog.
export function notify_check(conf) {
	let m = conf.main ?? {};
	if (!u.bool(m.tg_enabled, false))
		return { ok: true, sent: 0 };
	let st = u.readjson(NOTIFY_STATE) ?? {};
	let out = [];
	let now = time();
	let svc = service_status();

	// service stopped / back
	if (u.bool(m.tg_service, true) && u.bool(m.enabled, false)) {
		if (!svc.running) {
			st.down_count = (st.down_count ?? 0) + 1;
			if (st.down_count == 2 && !st.svc_down) {
				st.svc_down = now;
				push(out, '🔴 sing-box is not running. The network uses the direct connection now. Check the Configuration page.');
			}
		}
		else {
			if (st.svc_down)
				push(out, '🟢 sing-box is running again.');
			delete st.svc_down;
			st.down_count = 0;
		}
	}

	// current node unreachable (checked every 5 minutes)
	if (u.bool(m.tg_down, true) && svc.running && now - (st.node_checked ?? 0) >= 300) {
		st.node_checked = now;
		let grp = u.readjson(u.STATE_FILE)?.main_group ?? 'proxy';
		let url = enc(m.urltest_url ?? 'https://www.gstatic.com/generate_204');
		let r = api(conf, 'GET', '/proxies/' + enc(grp) + '/delay?timeout=6000&url=' + url, null, 12);
		let ok = r.ok && type(r.data?.delay) == 'int' && r.data.delay > 0;
		if (!ok) {
			st.node_fail = (st.node_fail ?? 0) + 1;
			if (st.node_fail == 2) {
				let now_node = api(conf, 'GET', '/proxies/' + enc(grp), null, 5).data?.now ?? '?';
				push(out, '⚠️ The proxy is unreachable (node "' + now_node + '", group "' + grp + '"). Choose another node or check the server.');
			}
		}
		else {
			if ((st.node_fail ?? 0) >= 2)
				push(out, '✅ The proxy works again (' + r.data.delay + ' ms).');
			st.node_fail = 0;
		}
	}

	// data quota / expiry (checked every 30 minutes)
	if (now - (st.usage_checked ?? 0) >= 1800) {
		st.usage_checked = now;
		usage_alerts(conf, st, out);
	}

	let sent = 0;
	if (length(out)) {
		let r = tg_send(conf, join('\n', out));
		if (r.ok)
			sent = length(out);
		else
			u.log('telegram: ' + r.error);
	}
	u.mkdirp(u.CONF_DIR);
	u.writejson(NOTIFY_STATE, st);
	return { ok: true, sent: sent };
};

// ---------------------------------------------------------------------------
// Background tasks
// ---------------------------------------------------------------------------

export function task_status() {
	let t = u.readjson(u.TASK_FILE);
	if (t?.running && t.pid && !stat('/proc/' + t.pid)) {
		t.running = false;
		t.ok = false;
		t.message = 'task terminated unexpectedly';
	}
	return t ?? { running: false };
};

export function task_busy() {
	return !!task_status().running;
};

export function task_spawn(action, arg) {
	if (task_busy())
		return { ok: false, error: 'another task is running' };
	let allowed = { 'sub-update': true, 'rs-update': true, 'core-update': true, 'core-package': true, 'xray-install': true, 'app-update': true, 'speed-test': true, 'net-tool': true, 'awg-install': true, 'awg-remove': true, 'restart': true, 'profile-update': true, 'node-test': true };
	if (!allowed[action])
		return { ok: false, error: 'invalid task' };
	u.mkdirp(u.RUN_DIR);
	u.writejson(u.TASK_FILE, { running: true, action: action, arg: arg, started: time() });
	let cmd = CTL + ' task ' + u.shq(action) + (arg != null && arg != '' ? ' ' + u.shq(arg) : '');
	// the app update restarts rpcd: run in its own session so it survives that
	if (action == 'app-update' && u.exec('command -v setsid').code == 0)
		cmd = 'setsid ' + cmd;
	system('( ' + cmd + ' ) >/dev/null 2>&1 &');
	return { ok: true };
};
