// SPDX-License-Identifier: GPL-3.0-or-later
// RPC method implementations for luci-app-singbox.
// Executed by `singbox-ctl rpc <method>` (called from the rpcd shim
// /usr/share/rpcd/ucode/luci.sbclient) so a backend error never prevents the
// ubus object from registering.


import { readfile, writefile, stat, access } from 'fs';
import { cursor } from 'uci';
import * as u from 'singbox.util';
import * as core from 'singbox.core';
import * as parser from 'singbox.parser';
import * as gen from 'singbox.gen';

function conf() {
	return u.load_conf();
}

function strip_ansi(s) {
	return replace(s ?? '', /\x1b\[[0-9;]*m/g, '');
}

function service_action(action) {
	let c = cursor();
	c.load(u.PKG);
	switch (action) {
	case 'start':
		c.set(u.PKG, 'main', 'enabled', '1');
		c.commit(u.PKG);
		system('/etc/init.d/singbox enable >/dev/null 2>&1');
		system('/etc/init.d/singbox restart >/dev/null 2>&1');
		break;
	case 'stop':
		c.set(u.PKG, 'main', 'enabled', '0');
		c.commit(u.PKG);
		system('/etc/init.d/singbox stop >/dev/null 2>&1');
		system('/usr/bin/singbox-ctl cron-sync >/dev/null 2>&1');
		break;
	case 'restart':
		system('/etc/init.d/singbox restart >/dev/null 2>&1');
		break;
	default:
		return { ok: false, error: 'invalid action' };
	}
	let st = core.service_status();
	let state = u.readjson(u.STATE_FILE);
	if (action != 'stop' && !st.running)
		return { ok: false, error: (state && !state.ok) ? strip_ansi(state.check) : 'sing-box failed to start, check the log', status: st };
	return { ok: true, status: st };
}

function main_group() {
	return u.readjson(u.STATE_FILE)?.main_group ?? 'proxy';
}

// All selector / urltest groups with members, for profile mode.
function groups_summary(cf) {
	let r = core.api(cf, 'GET', '/proxies', null, 5);
	if (!r.ok)
		return { ok: false, error: r.error ?? ('HTTP ' + r.status) };
	let px = r.data?.proxies ?? {};
	let groups = [];
	let types = {};
	let delays = {};
	for (let name in px) {
		let p = px[name];
		types[name] = p?.type;
		let h = p?.history;
		if (type(h) == 'array' && length(h))
			delays[name] = h[length(h) - 1].delay;
		if (name == 'GLOBAL' || type(p?.all) != 'array')
			continue;
		push(groups, { name: name, type: p.type, now: p.now, all: p.all });
	}
	// keep the configuration order: GLOBAL lists every outbound in config order
	let order = px.GLOBAL?.all ?? [];
	groups = sort(groups, (a, b) => {
		let ia = index(order, a.name), ib = index(order, b.name);
		return (ia < 0 ? 9999 : ia) - (ib < 0 ? 9999 : ib);
	});
	return { ok: true, groups: groups, types: types, delays: delays, main: main_group() };
}

function proxies_summary(cf) {
	let r = core.api(cf, 'GET', '/proxies', null, 5);
	if (!r.ok)
		return { ok: false, error: r.error ?? ('HTTP ' + r.status) };
	let px = r.data?.proxies ?? {};
	let delays = {};
	for (let name in px) {
		let h = px[name]?.history;
		if (type(h) == 'array' && length(h))
			delays[name] = h[length(h) - 1].delay;
	}
	let g = main_group();
	let sel = px[g]?.now;
	return {
		ok: true,
		group: g,
		selected: sel,
		members: px[g]?.all ?? [],
		// what the selection resolves to when it is itself a group
		auto: (sel != null && type(px[sel]?.all) == 'array') ? px[sel].now : px.auto?.now,
		delays: delays
	};
}

export const methods = {
	status: {
		call: function() {
			let cf = conf();
			let st = core.service_status();
			let state = u.readjson(u.STATE_FILE);
			let bin = u.core_path(cf.main);
			let ver = u.core_version(bin);
			let res = {
				running: st.running,
				enabled: st.enabled,
				pid: st.pid,
				proc: core.proc_info(st.pid),
				core: { path: bin, version: ver?.string },
				state: state,
				fw: st.running ? core.fw_active() : false,
				dns: st.running ? core.dns_active() : false,
				mode: u.inbound_mode(cf.main),
				active_profile: cf.main?.active_profile ?? '',
				// the profile actually in use (a broken profile falls back to built-in)
				profile: st.running
					? ((state?.source == 'profile' || state?.source == 'profile-raw') ? state?.profile?.name : null)
					: ((cf.main?.active_profile ?? '') != '' ? (core.profile_find(cf, cf.main.active_profile)?.name ?? cf.main.active_profile) : null),
				task: core.task_status()
			};
			if (st.running) {
				let m = core.api(cf, 'GET', '/configs', null, 2);
				if (m.ok)
					res.clash_mode = m.data?.mode;
			}
			return res;
		}
	},

	nodes: {
		call: function() {
			let cf = conf();
			let list = map(core.collect_nodes(cf, true), (n) => core.node_summary(n));
			let subs = [];
			for (let i = 0; i < length(cf.subs); i++) {
				let s = cf.subs[i];
				push(subs, { id: s.id, name: s.name ?? s.id, enabled: u.bool(s.enabled, true), info: core.sub_info(s.id) });
			}
			return { nodes: list, subs: subs, selected: cf.main?.selected };
		}
	},

	node_detail: {
		args: { tag: '' },
		call: function(req) {
			let list = core.collect_nodes(conf(), true);
			for (let i = 0; i < length(list); i++)
				if (list[i].outbound?.tag == req.args.tag)
					return { ok: true, outbound: list[i].outbound, endpoint: list[i].endpoint };
			return { ok: false, error: 'not found' };
		}
	},

	subs: {
		call: function() {
			let cf = conf();
			let out = {};
			for (let i = 0; i < length(cf.subs); i++)
				out[cf.subs[i].id] = core.sub_info(cf.subs[i].id);
			return { subs: out, task: core.task_status() };
		}
	},

	// Validate/convert pasted links, subscription text, Clash YAML or sing-box JSON.
	parse: {
		args: { text: '' },
		call: function(req) {
			let text = req.args.text ?? '';
			if (length(text) > 2097152)
				return { ok: false, error: 'input too large' };
			let res = parser.parse_content(text);
			let nodes = [];
			// For plain link input keep the original link so it stays editable.
			let lines = filter(map(split(replace(trim(text), /\r/g, ''), '\n'), (l) => trim(l)), (l) => l != '');
			let link_mode = (res.format == 'links');
			for (let i = 0; i < length(res.nodes); i++) {
				let o = res.nodes[i].outbound;
				let e = { tag: o.tag, type: o.type, server: o.server ?? o.peers?.[0]?.address, port: o.server_port ?? o.peers?.[0]?.port };
				if (link_mode) {
					// find the source line by re-parsing (cheap, inputs are small)
					for (let j = 0; j < length(lines); j++) {
						let p = parser.parse_link(lines[j]);
						if (p?.outbound && p.outbound.tag == o.tag && p.outbound.server == o.server) {
							e.link = lines[j];
							lines[j] = '';
							break;
						}
					}
				}
				if (!e.link)
					e.json = sprintf('%J', o);
				push(nodes, e);
			}
			return { ok: length(nodes) > 0, format: res.format, nodes: nodes, errors: res.errors };
		}
	},

	service: {
		args: { action: '' },
		call: function(req) {
			return service_action(req.args.action);
		}
	},

	clash: {
		args: { action: '', name: '', id: '', mode: '', url: '', timeout: 0 },
		call: function(req) {
			let cf = conf();
			let a = req.args;
			let url = (a.url != null && a.url != '') ? a.url : (cf.main?.urltest_url ?? 'https://www.gstatic.com/generate_204');
			let to = (a.timeout > 0 && a.timeout <= 30000) ? a.timeout : 5000;
			switch (a.action) {
			case 'proxies':
				return proxies_summary(cf);
			case 'groups':
				return groups_summary(cf);
			case 'select': {
				let grp = (a.id != null && a.id != '') ? a.id : main_group();
				let r = core.api(cf, 'PUT', '/proxies/' + core.enc(grp), { name: a.name });
				return { ok: r.ok, status: r.status, error: r.ok ? null : (r.data?.message ?? r.error) };
			}
			case 'delay': {
				let r = core.api(cf, 'GET', '/proxies/' + core.enc(a.name) + '/delay?timeout=' + to + '&url=' + core.enc(url), null, to / 1000 + 3);
				return { ok: r.ok, delay: r.data?.delay, error: r.ok ? null : (r.data?.message ?? r.error) };
			}
			case 'group_delay': {
				let grp = (a.name != null && a.name != '') ? a.name : (main_group() == 'proxy' ? 'auto' : main_group());
				let r = core.api(cf, 'GET', '/group/' + core.enc(grp) + '/delay?timeout=' + to + '&url=' + core.enc(url), null, to / 1000 + 25);
				return { ok: r.ok, delays: r.ok ? r.data : null, error: r.ok ? null : (r.data?.message ?? r.error) };
			}
			case 'connections': {
				let r = core.api(cf, 'GET', '/connections', null, 5);
				if (!r.ok)
					return { ok: false, error: r.error };
				return { ok: true, uploadTotal: r.data?.uploadTotal, downloadTotal: r.data?.downloadTotal, memory: r.data?.memory, connections: r.data?.connections ?? [] };
			}
			case 'traffic': {
				let r = core.api(cf, 'GET', '/connections', null, 3);
				if (!r.ok)
					return { ok: false, error: r.error };
				return { ok: true, up: r.data?.uploadTotal, down: r.data?.downloadTotal, count: length(r.data?.connections ?? []), memory: r.data?.memory };
			}
			case 'close': {
				let path = (a.id != null && a.id != '') ? '/connections/' + core.enc(a.id) : '/connections';
				let r = core.api(cf, 'DELETE', path);
				return { ok: r.ok };
			}
			case 'get_mode': {
				let r = core.api(cf, 'GET', '/configs', null, 3);
				return { ok: r.ok, mode: r.data?.mode };
			}
			case 'set_mode': {
				let modes = { rule: 'Rule', global: 'Global', direct: 'Direct' };
				let m = modes[lc(a.mode ?? '')];
				if (!m)
					return { ok: false, error: 'invalid mode' };
				let r = core.api(cf, 'PATCH', '/configs', { mode: m });
				return { ok: r.ok };
			}
			case 'flush_dns': {
				let r = core.api(cf, 'DELETE', '/cache/dns/flush');
				let f = core.api(cf, 'DELETE', '/cache/fakeip/flush');
				return { ok: r.ok || f.ok };
			}
			default:
				return { ok: false, error: 'invalid action' };
			}
		}
	},

	profiles: {
		call: function() {
			let cf = conf();
			let list = [];
			for (let i = 0; i < length(cf.profiles); i++) {
				let p = cf.profiles[i];
				push(list, {
					id: p.id,
					name: p.name ?? p.id,
					type: p.type ?? 'remote',
					url: p.url,
					update_hours: p.update_hours ?? '24',
					via: p.via ?? 'auto',
					user_agent: p.user_agent ?? '',
					integrate: u.bool(p.integrate, true),
					info: core.profile_info(p.id)
				});
			}
			let state = u.readjson(u.STATE_FILE);
			return {
				profiles: list,
				active: cf.main?.active_profile ?? '',
				running_source: state?.source,
				running_profile: state?.profile?.id,
				task: core.task_status()
			};
		}
	},

	// Create or update a profile. Empty id creates a new one.
	profile_save: {
		args: { id: '', name: '', type: '', url: '', update_hours: '', via: '', user_agent: '', integrate: true, content: '' },
		call: function(req) {
			let a = req.args;
			let name = trim(a.name ?? '');
			if (name == '')
				return { ok: false, error: 'name is required' };
			let t = (a.type == 'local') ? 'local' : 'remote';
			if (t == 'remote' && !match(a.url ?? '', /^(https?|sing-box):\/\/[^ \t]+$/))
				return { ok: false, error: 'enter a valid http(s) URL' };
			if (length(a.content ?? '') > 4194304)
				return { ok: false, error: 'profile too large' };
			let has_content = trim(a.content ?? '') != '';
			if (t == 'local' && !has_content && (a.id == null || a.id == ''))
				return { ok: false, error: 'paste or upload a sing-box configuration' };
			if (has_content) {
				let js = null;
				try { js = json(a.content); } catch (e) { return { ok: false, error: 'not valid JSON: ' + e }; }
				let verr = gen.profile_validate(js);
				if (verr)
					return { ok: false, error: verr };
			}

			let c = cursor();
			c.load(u.PKG);
			let id = a.id;
			let is_new = (id == null || id == '');
			if (is_new)
				id = c.add(u.PKG, 'profile');
			else if (c.get(u.PKG, id) != 'profile')
				return { ok: false, error: 'profile not found' };

			// validate content first so a bad paste does not create a broken entry
			if (t == 'local' || (a.content ?? '') != '') {
				// a new section is only persisted by commit(), so returning drops it
				if (trim(a.content ?? '') == '' && is_new)
					return { ok: false, error: 'paste or upload a sing-box configuration' };
				if (trim(a.content ?? '') != '') {
					let r = core.profile_store(id, a.content);
					if (!r.ok) {
						if (is_new)
							core.profile_delete_files(id);
						return r;
					}
				}
			}

			c.set(u.PKG, id, 'name', name);
			c.set(u.PKG, id, 'type', t);
			if (t == 'remote') {
				c.set(u.PKG, id, 'url', a.url);
				c.set(u.PKG, id, 'update_hours', match(a.update_hours ?? '', /^[0-9]+$/) ? a.update_hours : '24');
				c.set(u.PKG, id, 'via', (a.via == 'direct' || a.via == 'proxy') ? a.via : 'auto');
				if (trim(a.user_agent ?? '') != '')
					c.set(u.PKG, id, 'user_agent', trim(a.user_agent));
				else
					c.delete(u.PKG, id, 'user_agent');
			}
			else {
				c.delete(u.PKG, id, 'url');
				c.delete(u.PKG, id, 'update_hours');
			}
			c.set(u.PKG, id, 'integrate', (a.integrate === false) ? '0' : '1');
			c.commit(u.PKG);

			// a changed active profile takes effect right away
			let cf = conf();
			if (!is_new && cf.main?.active_profile == id && core.service_status().running && (trim(a.content ?? '') != '' || t == 'local'))
				system('/etc/init.d/singbox restart >/dev/null 2>&1');
			return { ok: true, id: id, created: is_new };
		}
	},

	profile_delete: {
		args: { id: '' },
		call: function(req) {
			let id = req.args.id;
			let c = cursor();
			c.load(u.PKG);
			if (c.get(u.PKG, id) != 'profile')
				return { ok: false, error: 'profile not found' };
			let was_active = c.get(u.PKG, 'main', 'active_profile') == id;
			c.delete(u.PKG, id);
			if (was_active)
				c.delete(u.PKG, 'main', 'active_profile');
			c.commit(u.PKG);
			core.profile_delete_files(id);
			if (was_active && core.service_status().running)
				system('/etc/init.d/singbox restart >/dev/null 2>&1');
			return { ok: true };
		}
	},

	// Switch the running configuration ('' = built-in configuration).
	profile_activate: {
		args: { id: '' },
		call: function(req) {
			let id = req.args.id ?? '';
			let cf = conf();
			if (id != '') {
				let p = core.profile_find(cf, id);
				if (!p)
					return { ok: false, error: 'profile not found' };
				if (!stat(core.profile_file(id))) {
					if ((p.type ?? 'remote') == 'remote') {
						let r = core.profile_update(cf, id);
						if (!r.ok)
							return { ok: false, error: r.error };
					}
					else
						return { ok: false, error: 'profile has no content' };
				}
				let chk = core.profile_check(cf, id);
				if (!chk.ok)
					return { ok: false, error: 'profile does not pass "sing-box check": ' + (chk.error ?? chk.output) };
			}
			let c = cursor();
			c.load(u.PKG);
			if (id == '')
				c.delete(u.PKG, 'main', 'active_profile');
			else
				c.set(u.PKG, 'main', 'active_profile', id);
			c.commit(u.PKG);
			if (core.service_status().running || u.bool(cf.main?.enabled, false)) {
				system('/etc/init.d/singbox restart >/dev/null 2>&1');
				let st = core.service_status();
				let state = u.readjson(u.STATE_FILE);
				if (!st.running)
					return { ok: false, error: (state && !state.ok) ? strip_ansi(state.check) : 'sing-box failed to start, check the log' };
				return { ok: true, running: true, warnings: state?.warnings ?? [] };
			}
			return { ok: true, running: false };
		}
	},

	profile_content: {
		args: { id: '' },
		call: function(req) {
			if (!match(req.args.id ?? '', /^[A-Za-z0-9_]+$/))
				return { ok: false, error: 'invalid id' };
			return { ok: true, text: readfile(core.profile_file(req.args.id)) ?? '' };
		}
	},

	profile_check: {
		args: { id: '' },
		call: function(req) {
			let r = core.profile_check(conf(), req.args.id);
			if (r.output)
				r.output = strip_ansi(r.output);
			return r;
		}
	},

	// Nodes of the active source that carry a bandwidth limit or multiplex.
	speed_caps: {
		call: function() {
			let cf = conf();
			let n = core.test_nodes(cf);
			let out = [];
			let all = [ ...n.outbounds, ...n.endpoints ];
			for (let i = 0; i < length(all); i++) {
				let o = all[i];
				let e = { tag: o.tag, type: o.type };
				let has = false;
				if (o.up_mbps != null || o.down_mbps != null) {
					e.up = o.up_mbps;
					e.down = o.down_mbps;
					has = true;
				}
				if (type(o.multiplex) == 'object' && o.multiplex.enabled) {
					e.mux = (o.multiplex.protocol ?? 'h2mux') + (o.multiplex.max_connections ? ' x' + o.multiplex.max_connections : '');
					if (type(o.multiplex.brutal) == 'object' && o.multiplex.brutal.enabled) {
						e.brutal_up = o.multiplex.brutal.up_mbps;
						e.brutal_down = o.multiplex.brutal.down_mbps;
					}
					has = true;
				}
				if (has)
					push(out, e);
			}
			return { source: n.source, total: length(all), nodes: out };
		}
	},

	// Results of the last latency test made while the service was stopped.
	test_results: {
		call: function() {
			let d = u.readjson(core.DELAY_FILE);
			let cf = conf();
			let src = ((cf.main?.active_profile ?? '') != '') ? 'profile' : 'builtin';
			if (!d || d.source != src)
				return { delays: {}, time: 0 };
			return { delays: d.delays ?? {}, time: d.time };
		}
	},

	// Groups of the active profile read from its file (service stopped).
	profile_groups: {
		call: function() {
			let cf = conf();
			let id = cf.main?.active_profile ?? '';
			if (id == '')
				return { ok: false, error: 'no active profile' };
			let js = u.readjson(core.profile_file(id));
			if (type(js) != 'object')
				return { ok: false, error: 'profile has no content' };
			let groups = [], types = {};
			let lists = [ js.outbounds ?? [], js.endpoints ?? [] ];
			for (let l = 0; l < 2; l++)
				for (let i = 0; i < length(lists[l]); i++) {
					let o = lists[l][i];
					if (type(o) != 'object' || o.tag == null)
						continue;
					types[o.tag] = o.type;
					if ((o.type == 'selector' || o.type == 'urltest') && type(o.outbounds) == 'array')
						push(groups, { name: o.tag, type: o.type, now: o.default ?? o.outbounds[0], all: o.outbounds });
				}
			return { ok: true, groups: groups, types: types, main: gen.main_group(js), offline: true };
		}
	},

	// Remember the chosen node as default for the next start (no service reload).
	set_selected: {
		args: { name: '' },
		call: function(req) {
			let c = cursor();
			c.load(u.PKG);
			c.set(u.PKG, 'main', 'selected', req.args.name ?? '');
			c.commit(u.PKG);
			return { ok: true };
		}
	},

	task: {
		args: { action: '', arg: '' },
		call: function(req) {
			return core.task_spawn(req.args.action, req.args.arg);
		}
	},

	task_status: {
		call: function() {
			return core.task_status();
		}
	},

	rulesets: {
		call: function() {
			return { rulesets: core.rs_status(conf()), task: core.task_status() };
		}
	},

	core_info: {
		call: function() {
			let cf = conf();
			let bin = u.core_path(cf.main);
			let ver = u.core_version(bin);
			let pkg = stat('/usr/bin/sing-box') ? u.core_version('/usr/bin/sing-box') : null;
			let dl = stat(u.BIN_DIR + '/sing-box') ? u.core_version(u.BIN_DIR + '/sing-box') : null;
			let xb = u.xray_path(cf.main);
			let xv = u.xray_version(xb);
			let st = u.readjson(u.STATE_FILE);
			let xinfo = {
				path: xb,
				version: xv?.string,
				package: access('/usr/bin/xray', 'x') ? true : false,
				downloaded: access(u.BIN_DIR + '/xray', 'x') ? true : false,
				nodes: st?.xray?.nodes ?? 0,
				skipped: st?.xray?.skipped ?? 0
			};
			return {
				path: bin,
				version: ver?.string,
				tags: ver?.tags ?? [],
				arch: core.core_arch(),
				package_version: pkg?.string,
				downloaded_version: dl?.string,
				app_is_package: core.pkg_installed('luci-app-singbox'),
				xray: xinfo
			};
		}
	},

	core_latest: {
		args: { prerelease: false },
		call: function(req) {
			return core.core_latest(conf(), !!req.args.prerelease);
		}
	},

	core_releases: {
		args: { core: '' },
		call: function(req) {
			return core.core_releases(conf(), req.args.core == 'xray' ? 'xray' : 'sing-box');
		}
	},

	xray_latest: {
		call: function() {
			return core.xray_latest(conf());
		}
	},

	xray_remove: {
		call: function() {
			let r = core.xray_remove();
			if (core.service_status().running)
				system('/etc/init.d/singbox restart >/dev/null 2>&1');
			return r;
		}
	},

	core_reset: {
		call: function() {
			let r = core.core_reset();
			if (core.service_status().running)
				system('/etc/init.d/singbox restart >/dev/null 2>&1');
			return r;
		}
	},

	logs: {
		args: { lines: 0 },
		call: function(req) {
			let n = (req.args.lines > 0 && req.args.lines <= 5000) ? req.args.lines : 300;
			let r = u.exec("logread | grep -E 'sing-box|singbox' | tail -n " + n);
			return { log: strip_ansi(r.out) };
		}
	},

	config: {
		call: function() {
			let state = u.readjson(u.STATE_FILE);
			return { config: readfile(u.CONFIG_OUT) ?? '', nft: readfile(u.NFT_OUT) ?? '', state: state };
		}
	},

	regenerate: {
		call: function() {
			let r = core.generate(conf());
			return { ok: r.ok, error: r.error, warnings: r.warnings ?? [], state: r.state };
		}
	},

	custom_get: {
		call: function() {
			return { text: readfile(u.CUSTOM_CONFIG) ?? '' };
		}
	},

	custom_set: {
		args: { text: '' },
		call: function(req) {
			let t = req.args.text ?? '';
			if (trim(t) != '') {
				try { json(t); } catch (e) { return { ok: false, error: 'not valid JSON' }; }
			}
			u.mkdirp(u.CONF_DIR);
			if (!u.writeatomic(u.CUSTOM_CONFIG, t))
				return { ok: false, error: 'write failed' };
			// validate with the installed core
			let bin = u.core_path(conf().main);
			if (bin && trim(t) != '') {
				let r = core.check_config(bin, u.CUSTOM_CONFIG);
				return { ok: true, check_ok: r.ok, check: r.output };
			}
			return { ok: true };
		}
	},

	ruleset_presets: {
		call: function() {
			return {
				iran: gen.IRAN_RULES,
				geosite: gen.GEOSITE_BASE,
				geoip: gen.GEOIP_BASE
			};
		}
	}
};

